import java.util.Scanner;
import java.util.Arrays;
public class Knapsack{

	public static int _fillKnapsack(int wt[],int val[], int W, int n){
		int dp[][] = new int[n+1][W+1];
		for(int i = 0; i <= n; i++)
			dp[i][0] = 0;
		for(int i = 0; i <= W; i++)
			dp[0][i] = 0;
		for(int i=1; i <=n; i++){

			for(int w = 1; w <=W; w++){
				if(wt[i-1] <= w)
					dp[i][w] = Math.max(val[i-1] +dp[i-1][w-wt[i-1]], dp[i-1][w]);
				else
					dp[i][w] = dp[i-1][w];
			}
		}
		return dp[n][W];
	}
	public static int _fillKnapsack2(int wt[], int val[], int W){
		int n = wt.length;
		int dp[] = new int[W+1];
		Arrays.fill(dp,0);
		for(int i = 0; i < n; i++){
			for(int w = W; w>=wt[i]; w--)
				dp[w] = Math.max(dp[w], val[i]+dp[w-wt[i]]);
		}
		return dp[W];

	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int wt[] = new int[n];
		int val[] = new int[n];
		for(int i = 0; i < n; i++)
			wt[i] = input.nextInt();
		for(int i = 0; i < n; i++)
			val[i] = input.nextInt();
		int W = input.nextInt();
		int ans = _fillKnapsack2(wt,val,W);
		System.out.println(ans);
	}
}