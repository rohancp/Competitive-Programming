import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Template1{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		}catch(Exception e){

			return ;
		}
	}
}