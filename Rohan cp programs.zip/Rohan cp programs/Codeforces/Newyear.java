import java.util.*;
import java.io.*;
import java.lang.*;

class Newyear{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				String s[] = br.readLine().split(" ");
				int H = Integer.parseInt(s[0]);
				int M = Integer.parseInt(s[1]);
				int a = (23-H)*60;
				int b = 60 - M;
				sb.append(a+b).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}