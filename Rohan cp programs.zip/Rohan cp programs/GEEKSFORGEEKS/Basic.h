#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <stdexcept>

class Basic
{

private:
	static int x;
	static int y;
	static int binaryExp(int A, int B, int M);

	static void extended_Euclid_Algo(int A, int B);
	static int Inverse(int C, int M);

	static int getAns(int A, int B, int C, int M);
	static void main(std::vector<std::wstring> &args);
};
