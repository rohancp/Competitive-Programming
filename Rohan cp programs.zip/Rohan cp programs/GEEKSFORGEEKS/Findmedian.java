import java.util.Scanner;
import java.util.PriorityQueue;
import java.util.Vector;
import java.util.Collections;
public class Findmedian{
	public static Vector<Integer> _findMedian(int stream[]){

		Vector<Integer> ans = new Vector<>();
		int size = stream.length;
		ans.add(stream[0]);
		if(size == 1)
			return ans;
		ans.add((stream[1]+stream[0])/2);
		if(size == 2)
			return ans;
		PriorityQueue<Integer> minheap = new PriorityQueue<>();
		PriorityQueue<Integer> maxheap = new PriorityQueue<>(Collections.reverseOrder());
		int i=2;
		minheap.add(Math.max(stream[0], stream[1]));
		maxheap.add(Math.min(stream[1], stream[0]));
		while(i < size){


			if(maxheap.peek()<stream[i]){
				minheap.add(stream[i]);
			}
			else{
				maxheap.add(stream[i]);
			}
			int minheap_size = minheap.size();
			int maxheap_size = maxheap.size();
			if(Math.abs(minheap_size-maxheap_size) > 1){
				if(minheap_size > maxheap_size)
					maxheap.add(minheap.poll());
				else
					minheap.add(maxheap.poll());
			}
			int result = 0;
			minheap_size = minheap.size();
			maxheap_size = maxheap.size();
			if(minheap_size == maxheap_size){
				int a = maxheap.peek();
				int b = minheap.peek();
				int c = (a+b)/2;
				result = c;
			}
			else{

				if(minheap_size > maxheap_size){

					result= minheap.peek();
					
				}
				else{
					result = maxheap.peek();
				}
			}
			ans.add(result);
			// System.out.println("Min - "+minheap+"\nMax - "+maxheap);
			i++;
		}
		return ans;
	}
	public static void _helper(int stream[]){

		Vector<Integer> alist = _findMedian(stream);
		for(int a : alist)
			System.out.println(a);
	}

	public static void main(String []args){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int stream[] = new int[n];
		for(int i = 0; i < n; i++)
			stream[i] = input.nextInt();
		_helper(stream);
	}
}