import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;
import java.util.Stack;
public class Nextlarger{

	public static int[] _getResult(Vector<Integer> arr){

		int []ans = new int[arr.size()];
		Stack<Integer> stack = new Stack<>();
		for(int i = arr.size()-1; i >= 0; i--){
			while(!stack.isEmpty() && arr.get(i) >= stack.peek())
				stack.pop();
			int ele = (stack.isEmpty())? -1 : stack.peek();
			ans[i] = ele;
			stack.push(arr.get(i));
		}
		return ans;
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			int n = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			Vector<Integer> arr = new Vector<Integer>();
			for(String a : ss)
				arr.add(Integer.parseInt(a));
			int aarr[] = _getResult(arr);
			for(int dd : aarr)
				System.out.print(dd+" ");
			System.out.println();

		}
}}