import java.util.PriorityQueue;
import java.util.Iterator;
import java.util.Collections;
public class PriorityQ{

	public static void main(String []args){

		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
		pq.add(5);
		pq.add(15);
		pq.add(1);
		pq.add(3);
		System.out.println("Min heap\n");
		Iterator<Integer> it = pq.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		System.out.println("\nMax heap\n");
		PriorityQueue<Integer> pq2 = new PriorityQueue<Integer>(Collections.reverseOrder());
		pq2.add(5);
		pq2.add(15);
		pq2.add(1);
		pq2.add(3);
		 it = pq2.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
	}
}