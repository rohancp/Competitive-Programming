#pragma once

#include <string>
#include <vector>
#include <iostream>

class Sieve
{

private:
	static int makeSieve(int n);

	static void main(std::vector<std::wstring> &args);
};
