#include "Mystery.h"

int Mystery::getResult(int num)
{

	/*int iter = num/2;
	int count = 0;
	while(iter != 0){
		if(num % iter == 0)	count++;
		iter--;
	}
	return count+1;*/

	// optimize version is...
	int count = 0;
	int n = static_cast<int>(std::sqrt(num));
	for (int i = 1; i <= n; i++)
	{

		if (num % i == 0)
		{

			if (num / i == i)
			{
				count += 1;
				continue;
			}
			count += 2;
		}
	}
	return count;
}

void Mystery::main(std::vector<std::wstring> &args)
{

	try
	{

		InputStreamReader tempVar(System::in);
		BufferedReader *br = new BufferedReader(&tempVar);
		int Quer = static_cast<Integer>(br->readLine());
		StringBuilder *sb = new StringBuilder();
		while (Quer-- > 0)
		{

			int num = static_cast<Integer>(br->readLine());
			sb->append(std::to_wstring(getResult(num)) + L"\n");
		}
		std::wcout << sb->toString() << std::endl;

		delete sb;
		delete br;
	}
	catch (const std::runtime_error &e)
	{
		return;
	}
}
