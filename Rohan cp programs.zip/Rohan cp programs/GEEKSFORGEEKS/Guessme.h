#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <stdexcept>
#include "stringbuilder.h"

class Guessme
{

		static void main(std::vector<std::wstring> &a);
};
