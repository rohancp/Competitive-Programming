#include "Guessme.h"

void Guessme::main(std::vector<std::wstring> &a)
{
	try
	{

		InputStreamReader tempVar(System::in);
		BufferedReader *br = new BufferedReader(&tempVar);
		int Quer = static_cast<Integer>(br->readLine());
		StringBuilder *sb = new StringBuilder();
		while (Quer-- > 0)
		{

			int num = static_cast<Integer>(br->readLine());
			int iter = num / 2;
			int count = 0;
			for (; iter >= 1; iter--)
			{
				if (num % iter == 0)
				{
					count += iter;
				}
			}
			sb->append(std::to_wstring(count) + L"\n");
		}
		std::wcout << sb->toString() << std::endl;

		delete sb;
		delete br;
	}
	catch (const std::runtime_error &e)
	{
		return;
	}
}
