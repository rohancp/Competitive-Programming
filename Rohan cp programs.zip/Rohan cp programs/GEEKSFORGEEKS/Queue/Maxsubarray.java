import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Deque;
import java.util.LinkedList;
import java.util.ArrayList;
public class Maxsubarray{

	public static ArrayList<Integer> _findMaxsubarray(int arr[], int n, int k){
		Deque<Integer> queue = new LinkedList<Integer>();
		ArrayList<Integer> ans = new ArrayList<Integer>();
		int i;
		for(i = 0; i < k; i++){

			while((queue.size() != 0) && arr[i] >= arr[queue.peekLast()])
				queue.removeLast();
			queue.addLast(i);

		}

		for(; i < n; i++){
			ans.add(arr[queue.peekFirst()]);

			while(queue.size() != 0 && queue.peekFirst() <= i-k)
				queue.removeFirst();
			while(queue.size() != 0 && arr[i] >= arr[queue.peekLast()])
				queue.removeLast();
			queue.addLast(i);
		}
		ans.add(arr[queue.peekFirst()]);
		return ans;
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			String s = br.readLine();
			String ss[] = s.split(" ");
			int n = Integer.parseInt(ss[0]);
			int k = Integer.parseInt(ss[1]);
			int arr[] = new int[n];
			s = br.readLine();
			ss = s.split(" ");
			for(int i = 0; i < n; i++)
				arr[i] = Integer.parseInt(ss[i]);
		 ArrayList<Integer> alist = _findMaxsubarray(arr, n, k);
			for(int a : alist){
				sb.append(a+" ");}
			if(tc != 0)
			sb.append("\n");
		}
		System.out.println(sb);
	}
}