import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Queue;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
public class Nonrepeat{

	public static ArrayList<String> _findNonrepeat(char ch[]){

		int count[] = new int[256];
		Arrays.fill(count, 0);
		ArrayList<String> alist = new ArrayList<String>();
		Queue<Character> queue = new LinkedList<Character>();
		count[ch[0]] += 1;
		queue.add(ch[0]);
		alist.add(String.valueOf(ch[0]));
		for(int i = 1; i < ch.length; i++){
			count[ch[i]] += 1;
			while(queue.size() != 0 && count[queue.peek()] > 1)
				queue.remove();
			if(count[ch[i]] == 1)
				queue.add(ch[i]);
			if(queue.size() == 0)
				alist.add("-1");
			else
				alist.add(String.valueOf(queue.peek()));
		}
		return alist;
	}
	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			int n = Integer.parseInt(br.readLine());
			char sarr[] = new char[n];
			String s = br.readLine();
			String ss[] = s.split(" ");
			int i = 0;
			for(String a : ss)
				sarr[i++] = a.charAt(0);
			ArrayList<String> alist = _findNonrepeat(sarr);
			for(String a : alist)
				System.out.print(a+" ");
			System.out.println();
		}
	}
}
