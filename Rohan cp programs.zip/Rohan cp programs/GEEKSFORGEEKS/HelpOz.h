#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <stdexcept>

class HelpOz
{

private:
	static void get_k_value(std::vector<int> &arr, int size);
		static void main(std::vector<std::wstring> &args);

};
