#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <stdexcept>
#include "stringhelper.h"
#include "stringbuilder.h"

class LoveTraingle
{

private:
	static long long getSeriesNumber(long long num);

		static void main(std::vector<std::wstring> &args);
};
