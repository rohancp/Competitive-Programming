#include "HelpOz.h"

void HelpOz::get_k_value(std::vector<int> &arr, int size)
{


	int first_min, second_min;
	first_min = std::min(arr[0], arr[1]);
	second_min = std::max(arr[0], arr[1]);
	std::wstring s = L"";
	for (int i = 2; i < size; i++)
	{

		if (first_min > arr[i])
		{
			second_min = first_min;
			first_min = arr[i];
		}
		if (first_min < arr[i] && arr[i] < second_min)
		{
			second_min = arr[i];
		}
	}

	int k = 2;
	while (k < second_min)
	{

		bool flag = true;

		for (int i = 1; i < size; i++)
		{

			if ((arr[i - 1] % k) != (arr[i] % k))
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
		s += std::to_wstring(k) + L" ";
		}
		k++;
	}
	std::wcout << s << std::endl;
}

void HelpOz::main(std::vector<std::wstring> &args)
{

	try
	{

			InputStreamReader tempVar(System::in);
			BufferedReader *br = new BufferedReader(&tempVar);
			int m = static_cast<Integer>(br->readLine());
			std::vector<int> arr(m);
			for (int i = 0; i < m; i++)
			{
				arr[i] = static_cast<Integer>(br->readLine());
			}
			get_k_value(arr, m);

		delete br;
	}
	catch (const std::runtime_error &e)
	{
		return;
	}
}
