import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
public class Permutation2{

	public static String _swap(String s, int i, int j){

		// System.out.println(i+" "+j);
		char ch[] = s.toCharArray();
		char temp = ch[i];
		ch[i] = ch[j];
		ch[j] = temp;
		return new String(ch);
	}

	public static void _allPermutation(ArrayList<String> al, int l, int r, String s){

		if( l == r){
			al.add(s);
			// System.out.println(s);
			return ;
		}
		for(int i = l; i <=r; i++){
			s = _swap(s, l, i);
			_allPermutation(al, l+1, r, s);
			s = _swap(s, l, i);
		}
	}
	public static void _toPrint(ArrayList<String> al){
		for(String s : al)
			System.out.print(s+" ");
		System.out.println();
	}
	public static void main(String []args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			ArrayList<String> alist = new ArrayList<String>();
			_allPermutation(alist, 0, s.length()-1, s);
			Collections.sort(alist);
			_toPrint(alist);
		}
	}
}