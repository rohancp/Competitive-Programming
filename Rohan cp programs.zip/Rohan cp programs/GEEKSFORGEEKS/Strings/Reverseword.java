import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Reverseword{


	public static void _reverseArray(String sa[]){
		int n = sa.length;
		for(int i = 0; i < n/2; i++){
			String s = sa[i];
			sa[i] = sa[n-1-i];
			sa[n-1-i] = s;
		}
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			String sa[] = s.split("\\.");
			_reverseArray(sa);
			StringBuffer sb = new StringBuffer();
			int n = sa.length;
			for(int i = 0; i < n; i++){
				sb.append(sa[i]);
				if( i != n-1)
					sb.append(".");
			}
			System.out.println(sb);
		}
	}
}