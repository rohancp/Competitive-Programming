import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
public class LargestPalindrome{
	public static int[] _longest_Palindrome(String s){
		char ch[] = s.toCharArray();
		int arr[] = new int[3];
		arr[0] = 1;
		arr[2] = 1; arr[1] = 0;
		for(int i = 0; i <s.length(); i++){
			int li = s.lastIndexOf(ch[i]);
			String sub = s.substring(i, li+1);
			StringBuffer sb = new StringBuffer(sub);
			sb.reverse();
			String _sb = sb.toString();
			if(sub.equals(_sb)){
				if(_sb.length() > arr[0]){

					arr[0] = _sb.length();
					arr[1] = i;
					arr[2] = li+1;
				}
			}
		}
		return arr;
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			int arr1[] = _longest_Palindrome(s);
			StringBuffer sb = new StringBuffer(s);
			sb.reverse();
			String s2 = sb.toString();
			int arr2[] = _longest_Palindrome(s2);
			if(arr1[0] >= arr2[0]){
				System.out.println(s.substring(arr1[1], arr1[2]));
			}
			else
				System.out.println(s2.substring(arr2[1], arr2[2]));
		}
	}
}