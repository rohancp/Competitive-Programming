import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Amazon{

	public static int _tomake(String s1, String s2){

		String s3 = s2+s2;
		int index = s3.indexOf(s1);
		if((index == 2) || s2.length()-index == 2)
			return 1;
		return 0;
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s1 = br.readLine();
			String s2 = br.readLine();
			int result = _tomake(s1, s2);
			System.out.println(result);

		}
	}
}