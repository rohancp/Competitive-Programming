import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Anagram{

	public static void main(String[] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			String ss[] = s.split(" ");
			String a = ss[0];
			String b = ss[1];
			if(a.length() != b.length()){
				System.out.println("NO");
				continue;
			}
			else{
				int a_sum = 0, b_sum = 0;
				for(int i = 0; i < a.length(); i++){
					a_sum += a.charAt(i);
					b_sum += b.charAt(i);
				}
				if( a_sum != b_sum){
					System.out.println("NO");
				}
				else
					System.out.println("YES");
			}
		}
	}
}