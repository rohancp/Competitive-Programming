import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
public class Longestcommonsubstring{

	public static int _longestcommon_Substring(int X, int Y, String s1, String s2){

		int dp[][] = new int[X][Y];
		for(int i = 0; i < X; i++)
			Arrays.fill(dp[i], 0);
		int max = 0;
		for(int i = 0; i < X; i++){
			for(int j = 0; j < Y; j++){
				if(s1.charAt(i) == s2.charAt(j)){
					if(i == 0 || j == 0)
						dp[i][j] = 1;
					else
						dp[i][j] = dp[i-1][j-1]+1;
					max = Math.max(max, dp[i][j]);
			}
		}
	}
	return max;
}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			String s = br.readLine();
			String ss[] = s.split(" ");
			int X = Integer.parseInt(ss[0]);
			int Y = Integer.parseInt(ss[1]);
			String m = br.readLine();
			String n = br.readLine();
			int result = _longestcommon_Substring(X, Y, m, n);
			sb.append(result);
			if(tc != 0)
				sb.append("\n");
		}
		System.out.println(sb.toString());
}
}