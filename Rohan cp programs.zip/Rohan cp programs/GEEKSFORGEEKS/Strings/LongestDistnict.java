import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
public class LongestDistnict{

	public static int _longestdistnict(String s){
		char ch[] = s.toCharArray();
		int arr[] = new int[256];
		Arrays.fill(arr, -1);
		int st = 0;
		arr[ch[0]] = 0;
		int max = 1;
		for(int j = 1; ch.length - st >max && j < ch.length;j++){
			 int index = arr[ch[j]];
			 if(arr[ch[j]] == -1 || st > index)
			 	max = Math.max(max, j-st+1);	 
			 else
			 	st = index + 1;
			 arr[ch[j]] = j;
		}
		return max;
	}
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			int result = _longestdistnict(s);
			System.out.println(result);
		}
	}
}