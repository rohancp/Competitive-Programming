import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
public class Formpalindrome{

	public static int _form(String s, int i, int j, int dp[][]){
		if( i >= j)
			return 0;
		if(dp[i][j] != -1)
			return dp[i][j];
		if(s.charAt(i) == s.charAt(j)){
			return _form(s, i+1, j-1, dp);
		}
		int a = _form(s, i+1, j-1, dp)+2;
		int b = _form(s, i+1,j, dp)+1;
		int c = _form(s, i, j-1, dp)+1;
		return dp[i][j] = Math.min(a, Math.min(b,c));
	}
	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			int dp[][] = new int[s.length()][s.length()];
			for(int i = 0; i <s.length(); i++)
				Arrays.fill(dp[i],-1);
			int result = _form(s, 0, s.length()-1, dp);
			System.out.println(result);
		}
	}
}