import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class LongestPalindrome{

	public static String _p(String s, int i){
		char ch[] = s.toCharArray();
		int li = s.lastIndexOf(ch[i]);
		if(li == i)
			return ""+ch[i];
		String s1 = s.substring(i, li+1);
		String s2 = ""+ch[i];
		// System.out.println(li+"");
		while(!(s2.length()>=s1.length())){
			StringBuilder sb = new StringBuilder(s1);
			sb.reverse();
			String s3 = sb.toString();
			if(s3.equals(s1)){
				if(s2.length() < s1.length())
					s2 = s1;
			}
			
			li = s1.lastIndexOf(ch[i], li-1);
			s1 = s1.substring(i, li + 1);
		}
		return s2;
	}

	public static void main(String[]args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			// char ch[] = s.toCharArray();
			String max1,max2;
			max1 = ""+s.charAt(0);
			for(int i = 0; s.length()-i > max1.length();i++){
				max2 = _p(s.substring(i,s.length()),0);
				if(max2.length() > max1.length())
					max1 = max2;
			}
			System.out.println(max1);
		}
	}
}