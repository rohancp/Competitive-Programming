import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
public class Solution{

	static Vector<Vector<Integer>> res = new Vector<>();
	public static void _printSets(Vector<Integer> sets){

		res.add(sets);
		System.out.println(res);
	}

	public static void _findSets(Vector<Integer> vec, int arr[], int index){

		if(index>=arr.length)
	  		return ;

	  	vec.add(arr[index]);
	  	_printSets(vec);
	  	_findSets(vec, arr, index + 1);
	  	vec.remove(vec.size()-1);
	  	_findSets(vec,arr,index + 1 );
	  	return ;
	}
	public static void printSubsets(int input[]){

		Vector<Integer> vec = new Vector<>();
		_findSets(vec, input, 0);
		
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		int arr[] = new int[n];
		String s[] = br.readLine().split(" ");
		for(int i = 0; i < n; i++)
			arr[i] = Integer.parseInt(s[i]);
		printSubsets(arr);
		
	}
}