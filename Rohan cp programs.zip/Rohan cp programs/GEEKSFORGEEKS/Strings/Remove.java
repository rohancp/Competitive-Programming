import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Remove{

	public static String _remove(String str, char pc){

		if(str.length() <= 1)
			return str;

		if(str.charAt(0) == str.charAt(1)){
			int i = 0;
			for(; i < str.length(); i++){
				if(str.charAt(0) != str.charAt(i))                          
					break;
			}
			str = str.substring(i,str.length());
			return _remove(str, pc);
		}

		String str2 = _remove(str.substring(1, str.length()), str.charAt(0));
		if(str2.length() == 0) 
			return ""+str.charAt(0);
 
		if(str.charAt(0) != str2.charAt(0))
			return (str.charAt(0) + str2);

		if(str.charAt(0) == str2.charAt(0) && pc == str2.charAt(0))
			return str2;

		return str2.substring(1, str2.length());
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			String result = _remove(s,' ');
			System.out.println(result);
		}
}
}