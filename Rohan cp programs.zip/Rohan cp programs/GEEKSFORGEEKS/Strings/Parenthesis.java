import java.util.HashMap;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
public class Parenthesis{
	public static boolean _isbalanced(String s){

		HashMap<Character,Character> map = new HashMap<>();
		map.put('{','}');
		map.put('(',')');
		map.put('[',']');
		Stack<Character> stack = new Stack<>();
		for(char ch : s){
			if(map.containsKey(ch))
				stack.push(ch);
			else if(!stack.isEmpty() &&  map.get(stack.peek()) == ch)
					stack.pop();

			else
				break;
		}
		if(stack.isEmpty())
			return true;
		return false;
	}
	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuilder sb = new StringBuilder();
		while(tc-- > 0){
			String s = br.readLine();
			boolean result = _isbalanced(s);
			if(result)
				sb.append("balanced");
			else
				sb.append("not balanced");
			if(tc != 0)
				sb.append("\n");
		}
	}
}