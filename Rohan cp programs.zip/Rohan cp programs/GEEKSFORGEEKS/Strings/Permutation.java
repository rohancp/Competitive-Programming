import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
public class Permutation{

	public static String _swap(String s, int i){
		char ch[] = s.toCharArray();
		char temp = ch[0];
		ch[0] = ch[i];
		ch[i] = temp;
		return new String(ch);
	}	
	public static String _swap2(String s, int i, int j){
		char ch[] = s.toCharArray();
		char temp = ch[i];
		ch[i] = ch[j];
		ch[j] = temp;
		return new String(ch);
	}
	public static void _allpermutations(String s){
		int m = s.length();
		ArrayList<String> alist = new ArrayList<>();
		for(int i = 0; i < m; i++){
			String p = _swap(s, i);
			alist.add(p);
			int n = m;
			if( n-1 != 1){
				n--;
				while(true){
					p = _swap2(p, n, n-1);
					if(alist.contains(p))
						break;
					alist.add(p);
					n--;
					if(n == 1)
						n = m-1;
				}
			}
		} 
		Collections.sort(alist);
		for(String ss : alist)
			System.out.print(ss+" ");
		System.out.println();
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			if(s.length() != 1)
			_allpermutations(s);
			else
				System.out.println(s);
		}
	}
}