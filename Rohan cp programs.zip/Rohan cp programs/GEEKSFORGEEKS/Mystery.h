#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <cmath>
#include <stdexcept>
#include "stringbuilder.h"

class Mystery
{


private:
	static int getResult(int num);
	static void main(std::vector<std::wstring> &args);
};
