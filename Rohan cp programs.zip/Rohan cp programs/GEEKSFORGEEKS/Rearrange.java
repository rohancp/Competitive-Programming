import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.PriorityQueue;
import java.util.Comparator;
 class Pair implements Comparator<Rearrange>{
	
	public int compare(Rearrange ob1, Rearrange ob2){
		if(ob1.freq < ob2.freq)
				return 1;
		if(ob1.freq > ob2.freq)
				return -1;
		return 0;
	}
}
public class Rearrange{

	int freq;char ch;
	Rearrange(int freq, char ch){
		this.freq = freq;
		this.ch = ch;
	}

	public static boolean _helper(String s){

		PriorityQueue<Rearrange> Pq = new PriorityQueue<Rearrange>(new Pair());
		int count[] = new int[26];
		for(int i = 0; i < s.length(); i++){
			count[s.charAt(i) - 97] +=1;
		}
		for(int i = 97; i <= 122; i++){
			int index = i-97;
			if(count[index] > 0){
				Rearrange p = new Rearrange(count[index],(char) i);
				Pq.add(p);
			}
		}
		String ans = "";
		Rearrange prev = null;
		while(Pq.size() != 0){

			Rearrange p = Pq.poll();	
			ans +=p.ch;
			p.freq -=1;
			if(prev == null)
				prev = p;
			else if(prev.freq > 0)
					Pq.add(prev);
			prev = p;
		}
		if(s.length() != ans.length())
			return false;
		return true;
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			boolean ans = _helper(s);
			if(ans)
				System.out.println("1");
			else
				System.out.println("0");
		}
	}
}