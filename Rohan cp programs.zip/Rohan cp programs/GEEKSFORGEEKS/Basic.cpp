#include "Basic.h"

int Basic::x = 0;
int Basic::y = 0;

int Basic::binaryExp(int A, int B, int M)
{

	if (B == 0)
	{
		return 1;
	}

	else if (B % 2 == 0)
	{
		long long a = (A % M) * (A % M);
		A = static_cast<int>(a % M);
		return binaryExp(A, B / 2, M) % M;
	}

	long long aa = (A % M) * (A % M);
	int g = static_cast<int>(aa % M);
	int ans = binaryExp(g, (B - 1) / 2, M);
	aa = (A % M) * (ans % M);
	g = static_cast<int>(aa % M);
	return g;
}

void Basic::extended_Euclid_Algo(int A, int B)
{

	if (B == 0)
	{

		x = 1;
		y = 0;
		return;
	}
	extended_Euclid_Algo(B,A % B);
	int temp = x;
	x = y;
	y = temp - (y * (A / B));
}

int Basic::Inverse(int C, int M)
{

	extended_Euclid_Algo(C, M);
	return (x % M + M) % M;
}

int Basic::getAns(int A, int B, int C, int M)
{

	int ans1 = binaryExp(A, B, 1000000000 + 7);
	// System.out.println(ans1);
	// System.exit(0);
	int ans2 = Inverse(C, M);
	// System.out.println(ans2);
	// System.exit(0);
	long long a = ans1 * ans2;
	int result = static_cast<int>(a % M);
	return result;
}

void Basic::main(std::vector<std::wstring> &args)
{

	try
	{
		InputStreamReader tempVar(System::in);
		BufferedReader *br = new BufferedReader(&tempVar);
		std::vector<std::wstring> inp = br->readLine()->split(L" ");
		int ans = getAns(std::stoi(inp[0]), std::stoi(inp[1]), std::stoi(inp[2]), std::stoi(inp[3]));
		std::wcout << ans << std::endl;

		delete br;
	}
	catch (const std::runtime_error &e)
	{
		return;
	}
}
