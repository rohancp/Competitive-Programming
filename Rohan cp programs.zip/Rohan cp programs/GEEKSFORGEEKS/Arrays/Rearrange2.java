import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Rearrange2{

	public static void _toPrint(long arr[], int n){

		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < n; i++)
			sb.append(arr[i]+" ");
		System.out.println(sb);
	}
	
	public static void _rearrange(long arr[], int N){

		int max_index = N-1;
		int min_index = 0;
		long max_ele = arr[N-1]+1;
		for(int i = 0; i < N; i++){
			if((i&1) == 0){

				arr[i] = arr[i] + (arr[max_index]%max_ele)*max_ele;
				max_index--;
			}
			else
			{
				arr[i] = arr[i] + (arr[min_index]%max_ele)*max_ele;
				min_index++;
			}
		}
		for(int i = 0; i < N; i++)
			arr[i] /= max_ele;
		_toPrint(arr, N);
	}

	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- >0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			long arr[] = new long[N];
			for(int i = 0; i < N;i++)
				arr[i] = Long.parseLong(ss[i]);
			_rearrange(arr, N);
		}
	}
}