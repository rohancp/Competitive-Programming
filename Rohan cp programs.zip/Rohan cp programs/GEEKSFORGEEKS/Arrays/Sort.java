import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Sort{


	public static void _swap(int arr[], int i, int j){

		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	public static void _show(int arr[],int n){

		for(int i = 0; i < n; i++)
			System.out.print(arr[i]+" ");
		System.out.println();
	}

	public static void _toSort(int arr[], int n){

		int low = 0, high, mid = 0;
		high = n-1;
		while(mid <= high){

			switch(arr[mid]){

				case 0 : 
						_swap(arr, low, mid);
						low++;mid++;
						break;
				case 1 : mid++;
						break;
				case 2 : _swap(arr, high, mid);
							high--;
						break;
			}
		}
		_show(arr, n);
	}

	public static void main(String [] args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			int n = Integer.parseInt(br.readLine());
			int arr[] = new int[n];
			String s = br.readLine();
			String ss[] = s.split(" ");
			for(int i = 0; i < n; i++)
				arr[i] = Integer.parseInt(ss[i]);
			_toSort(arr, n);
		}
		
	}
}