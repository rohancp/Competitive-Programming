import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class MergeArray1{

	public static int _gap(int n){

		if(n <= 1)
			return 0;
		return n/2 + (n%2);
	}

	public static void _swap(int arr[], int l, int r){

		int temp = arr[l];
		arr[l] = arr[r];
		arr[r] = temp;
	}

	public static void _swap_2(int arr1[], int arr2[], int l, int r){

		int temp = arr1[l];
		arr1[l] = arr2[r];
		arr2[r] = temp;
	}

	public static void _toPrint(int arr[],int n){
		for(int i = 0 ; i < n ; i++)
			System.out.print(arr[i]+" ");

	}
	
	public static void _arrange_Array(int arr1[], int arr2[], int n, int m){
		int merarray[] = new int[n+m];
		int i = 0, j = 0;
		int k = 0;
		while( i < n && j < m){
			if(arr1[i] > arr2[j]){
				merarray[k++] = arr2[j++];
				continue;
			}
			merarray[k++] = arr1[i++];
		}
		while( i < n){
			merarray[k++] = arr1[i++];
		}
		while(j < m){
			merarray[k++] = arr2[j++];
		}

		_toPrint(merarray, n+m);
		System.out.println();
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());

		while(tc-- > 0){
			String h = br.readLine();
			String jj[] = h.split(" ");
			int n = Integer.parseInt(jj[0]);
			int m = Integer.parseInt(jj[1]);
			int arr1[] = new int[n];
			int arr2[] = new int[m];
			String s = br.readLine();
			String ss[] = s.split(" ");
			s = "";
			s = br.readLine();
			String ss1[] = s.split(" ");
			for(int i = 0 ; i < n; i++)
				arr1[i] = Integer.parseInt(ss[i]);
			for(int i = 0; i < m; i++)
				arr2[i] = Integer.parseInt(ss1[i]);
			_arrange_Array(arr1, arr2, n, m);
		}
	}
}