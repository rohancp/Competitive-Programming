import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Subarraysum{
	public static void _subarray(int arr[], int temp[], int N, int S){

		int i = 0, sum = 0, l = -1;
		int j = 0;
		for(j = 0; j < N;){
			 if(temp[j]-sum == S){
				l = j;
				break;
			}
			else if(arr[j] == S){
				i = l = j;
				break;
			}
			
			else if(temp[j]-sum > S){
				sum = temp[i];
				i++;
			}
			else{
				j++;
			}
		}
		if(l != -1){
			System.out.println((i+1)+" "+(j+1));
		}
		else
			System.out.println("-1");
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			String ss[] = s.split(" ");
			int N = Integer.parseInt(ss[0]);
			int arr[] = new int[N];
			int temp[] = new int[N];
			int S = Integer.parseInt(ss[1]);
			s = br.readLine();
			String sss[] = s.split(" ");
			for(int i = 0; i < N; i++){
				arr[i] = Integer.parseInt(sss[i]);
				if(i == 0)
					temp[i] = arr[i];
				else
					temp[i] = arr[i] + temp[i-1];
			}
			_subarray(arr, temp, N, S);
		}
	}
}