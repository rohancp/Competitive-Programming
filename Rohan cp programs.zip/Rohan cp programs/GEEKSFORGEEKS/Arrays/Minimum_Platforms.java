import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.ArrayList;
class A_D implements Comparable<A_D>{

	int arrv;
	int dept;
	public A_D(int a,int d){
		arrv = a;
		dept = d;
	}

	public int compareTo(A_D ob){

		if(this.arrv == ob.arrv)
			return 0;
		else if(this.arrv >  ob.arrv)
			return 1;
		return -1;
	}
}
public class Minimum_Platforms{

	public static int _minimum_Platforms(A_D arr[], int N){

		ArrayList<A_D> alist = new ArrayList<A_D>();
		alist.add(arr[0]);
		for(int i = 1; i < N; i++){
			A_D ob = arr[i];
			boolean flag = true;
			for(int j = 0; j < alist.size();j++){
				A_D trv = alist.get(j);
				if(ob.arrv > trv.dept){
					alist.get(j).arrv = ob.arrv;
					alist.get(j).dept = ob.dept;
					flag = false;
					break;
				}
			}
			if(flag){
				alist.add(ob);
			}
		}
		return alist.size();
	}

	public static void main(String []args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String arrival[] = s.split(" ");
			s = "";
			s = br.readLine();
			String depature[] = s.split(" ");
			A_D arr[] = new A_D[N];
			for(int i = 0; i < N; i++){
				int a,d;
				a = Integer.parseInt(arrival[i]);
				d = Integer.parseInt(depature[i]);
				arr[i] = new A_D(a, d);
			}
			Arrays.sort(arr);
			int result = _minimum_Platforms(arr, N);
			System.out.println(result);
		}
	}
}