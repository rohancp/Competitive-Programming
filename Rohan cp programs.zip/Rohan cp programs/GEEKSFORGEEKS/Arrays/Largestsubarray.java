import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Largestsubarray{

	public static int _largestSubArray(int arr[], int n){

		int max = 0;
		for(int i = 0; i < n; i++){
			int count_zero = 0;
			int count_one = 0;
			if(arr[i] == 0)
				count_zero++;
			else 
				count_one++;
			for(int j = i+1; j < n; j++){
				if(arr[j] == 0)
					count_zero++;
				else 
					count_one++;
				if(count_zero == count_one && (count_one+count_zero) > max)
					max = count_zero + count_one;
			}
		}
		return max;
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			int arr[] = new int[N];
			for(int i = 0; i < N; i++)
				arr[i] = Integer.parseInt(ss[i]);
			int result = _largestSubArray(arr, N);
			sb.append(result);
			if(tc != 0)
				sb.append("\n");
		}
		System.out.println(sb);
	}
}