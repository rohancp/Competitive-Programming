import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class MergeArray{

	public static int _gap(int n){

		if(n <= 1)
			return 0;
		return n/2 + (n%2);
	}

	public static void _swap(int arr[], int l, int r){

		int temp = arr[l];
		arr[l] = arr[r];
		arr[r] = temp;
	}

	public static void _swap_2(int arr1[], int arr2[], int l, int r){

		int temp = arr1[l];
		arr1[l] = arr2[r];
		arr2[r] = temp;
	}

	
	public static void _show_Array(int arr1[],int arr2[],int n, int m){

		StringBuffer sb = new StringBuffer();
		for(int i = 0 ; i < n; i++)
			sb.append(arr1[i]+" ");
		for(int i = 0 ; i < m; i++)
			sb.append(arr2[i]+" ");
		
		System.out.println(sb);
	}
	public static void _arrange_Array(int arr1[], int arr2[], int n, int m){
		/*
		here : n is length of arr1;
		and m is length of arr2;
		*/
		int dif = n+m;
		while((dif = _gap(dif)) > 0){

			int i,j;
			/*this is for first array*/
			for(i = 0; i+dif < n; i++){
				if(arr1[i] > arr1[i+dif])
					_swap(arr1, i, i+dif);
			}

			/* this is for both two array*/
			for(j = dif+i-n; i < n &&  j < m; ){

				if(arr1[i] > arr2[j])
					_swap_2(arr1, arr2, i, j);
				i++;j++;
			}

			/*this is for second array*/
			if( j < m){

				for(; j< m; j++){
					if(arr2[j-dif] > arr2[j])
						_swap(arr2, j, j-dif);
				}
			}			
		}
		_show_Array(arr1, arr2, n, m);
	}
	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());

		while(tc-- > 0){
			String h = br.readLine();
			String jj[] = h.split(" ");
			int n = Integer.parseInt(jj[0]);
			int m = Integer.parseInt(jj[1]);
			int arr1[] = new int[n];
			int arr2[] = new int[m];
			String s = br.readLine();
			String ss[] = s.split(" ");
			s = "";
			s = br.readLine();
			String ss1[] = s.split(" ");
			for(int i = 0 ; i < n; i++)
				arr1[i] = Integer.parseInt(ss[i]);
			for(int i = 0; i < m; i++)
				arr2[i] = Integer.parseInt(ss1[i]);
			_arrange_Array(arr1, arr2, n, m);
		}
	}
}