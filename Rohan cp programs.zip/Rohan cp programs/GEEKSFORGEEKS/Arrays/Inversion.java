import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Inversion{

	public static int _merge_sort(int arr[], int s, int l){

		if(s != l){
			int mid = (s+l)/2;
			int a = _merge_sort(arr, s, mid);
			int b = _merge_sort(arr, mid+1, l);
			int c = _merging(arr, s, l, mid);
			return (a+b+c);
		}
		return 0;
	}

	public static int _merging(int arr[], int s, int l,int mid){

		int i  = s;
		int j = mid+1;
		int B[] = new int[10000001];
		int k = s;
		int count = 0;
		while( i <= mid && j <= l){

			if(arr[i] > arr[j]){
				count += (mid - i) + 1;
				B[k++] = arr[j++];
				continue;
			}
			B[k++] = arr[i++];
		}

		while( i <= mid)
			B[k++] = arr[i++];
		while( j <= l)
			B[k++] = arr[j++];
		for(k = s; k <= l; k++)
			arr[k] = B[k];
		return count;
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			int arr[] = new int[N];
			String s = br.readLine();
			String ss[] = s.split(" ");
			for(int i = 0; i < N; i++)
				arr[i] = Integer.parseInt(ss[i]);
			int result = _merge_sort(arr, 0, N-1);
			if(tc != 0)
			sb.append(result+"\n");
		}
		System.out.println(sb);
	}
}