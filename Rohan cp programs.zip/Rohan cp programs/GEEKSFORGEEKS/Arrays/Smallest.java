import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Smallest{
	public static int _smallest(int arr[], int max, int N, int K){
		int temp[] = new int[max+1];
		for(int i = 0; i < N; i++){
			temp[arr[i]] += 1;
		}

		for(int i = 0; i <= max; i++){
			if( temp[i] == 1){
				K--;
			}
			if( K == 0){
				return i;
			}
		}
		return max;
	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){

			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			int arr[] = new int[N];
			int max = 0;
			for(int i = 0; i < N; i++){
				arr[i] = Integer.parseInt(ss[i]);
				if(arr[i] > max)
					max = arr[i];
			}
			int K = Integer.parseInt(br.readLine());
			int result = _smallest(arr, max, N, K);
			sb.append(result);
			if(tc !=0)
				sb.append("\n");
		}
		System.out.println(sb);
	}
}