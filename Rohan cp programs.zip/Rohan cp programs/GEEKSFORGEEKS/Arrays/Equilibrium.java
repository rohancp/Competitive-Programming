import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Equilibrium{

	public static boolean __toPoint(int sum, int l_sum, int i, int arr[]){

		int temp = sum -l_sum;
		temp -= arr[i];
		if(temp == l_sum)
			return true;
		return false;
	}
	public static int _find_midPoint(int arr[], int n, int sum){

		if(n == 1)
			return 1;

		int l_sum = 0;
		for(int i = 0; i < n; i++){
			boolean b = false;
			if(sum %2 == 0 && arr[i] %2 ==0){

				 b = __toPoint(sum, l_sum, i, arr);
			}
			else if(sum %2 != 0 && arr[i]%2 !=0){
				 b = __toPoint(sum, l_sum, i, arr);
			}
			if(b){
				return i+1;
			}
			l_sum += arr[i];
		}
		return -1;
	}

	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			int arr[] = new int[N];
			int sum = 0;
			for(int i = 0; i < N; i++){
				arr[i] = Integer.parseInt(ss[i]);
				sum += arr[i];
			}
			int result = _find_midPoint(arr, N, sum);
			sb.append(result);
			if(tc !=0)
				sb.append("\n");
		}
		System.out.println(sb);
	}
}