import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Node{

	int count_zero, count_one;
	public Node(int a, int b){
		count_zero = a;
		count_one = b;
	}
}
public class Largestsubarray2{

	public static int _largestSubArray(Node arr[], int n){

		int max = 0;
		for(int i = 0; i < n; i++){
			if(arr[i].count_zero != 0 && arr[i].count_one !=0){
				int min = Math.min(arr[i].count_zero, arr[i].count_one)*2;
				if(min > max)
					max = min;
			}
		}
			return max;
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuffer sb = new StringBuffer();
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			Node arr[] = new Node[N];
			for(int i = 0; i < N; i++){
				int zero,one;
				if(i == 0){
					if(Integer.parseInt(ss[i]) == 0){
						arr[i] = new Node(1,0);
					}
					else
						arr[i] = new Node(0,1);

				}
				else{
					zero = arr[i-1].count_zero;
					one = arr[i-1].count_one;
					if(Integer.parseInt(ss[i]) == 0){
						arr[i] = new Node(zero+1, one);
					}
					else{
						arr[i] = new Node(zero, one+1);
					}
				}
			}
			int result = _largestSubArray(arr, N);
			sb.append(result);
			if(tc != 0)
				sb.append("\n");
		}
		System.out.println(sb);
	}
}