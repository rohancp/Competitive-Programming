import java.util.Scanner;
class Kadane{

	public static int _max_SubArraySum(int arr[],int n){
		int curr_Sum,sup_Sum;
		curr_Sum = 0;
		sup_Sum = Integer.MIN_VALUE;
		for(int i = 0; i < n; i++){
			curr_Sum += arr[i];
			if(curr_Sum > sup_Sum)
				sup_Sum = curr_Sum;
			if(curr_Sum < 0)
				curr_Sum = 0;
			
		}
		return sup_Sum;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int arr[] = new int[n];
			for(int i = 0; i < n; i++)
				arr[i] = input.nextInt();
			int result = _max_SubArraySum(arr, n);
			System.out.println(result);
		}
	}
}