import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Rearrange{

	public static void _toPrint(int arr[], int n){

		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < n; i++)
			sb.append(arr[i]+" ");
		System.out.println(sb);
	}
	public static void _toReverse(int arr[], int N, int i){

	int c = 0;
	for(int j = i; j <= ((i+N)/2) - 1;j++){
		int temp = arr[j];
		arr[j] = arr[N-1-c];
		arr[N-1-c] = temp;
		c++;
		}
	}
	public static void _rearrange(int arr[], int N){

		for(int i = 0; i < N-1; i++){

			_toReverse(arr, N, i);
		}
		_toPrint(arr, N);
	}

	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- >0){
			int N = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String ss[] = s.split(" ");
			int arr[] = new int[N];
			for(int i = 0; i < N;i++)
				arr[i] = Integer.parseInt(ss[i]);
			_rearrange(arr, N);
		}
	}
}