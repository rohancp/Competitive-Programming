import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class BooleanMatrix{

	public static void _boolean_Matrix(int r, int c, int row[], int col[]){

		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < r; i++){
			if(row[i] == 1){
				for(int j = 0; j < c; j++)
					sb.append(1+" ");
			}
			else{
				for(int j = 0; j < c; j++)
					sb.append(col[j]+" ");
			}
			if(i != r-1)
			sb.append("\n");
		}
		System.out.println(sb);
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			String s = br.readLine();
			String ss[] = s.split(" ");
			int r = Integer.parseInt(ss[0]);
			int c = Integer.parseInt(ss[1]);
			int mat[][] = new int[r][c];
			int row[] = new int[r];
			int col[] = new int[c];
			for(int i = 0; i < r; i++){
				s = br.readLine();
				String sss[] = s.split(" ");
				for(int j = 0; j < c; j++){
					mat[i][j] = Integer.parseInt(sss[j]);
					if(mat[i][j] == 1){
						row[i] = 1;
						col[j] = 1;
					}
				}
			}
			_boolean_Matrix(r, c, row, col);
		}
	}
}