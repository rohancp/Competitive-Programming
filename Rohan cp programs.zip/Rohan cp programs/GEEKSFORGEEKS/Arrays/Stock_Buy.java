import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Stock_Buy{


	public static void _stock_Buy(int Arr[], int n){

		int i,j;
		StringBuffer sb = new StringBuffer();
		for( i = 0; i < n-1;){

			if(Arr[i] >= Arr[i+1]){
				i++;
				continue;
			}
			int b_ind = i;
			int s_ind = i+1;
			for(j = i +2; j < n; j++){

				if(!(Arr[j-1] <= Arr[j])){

					s_ind = j-1;
					break;
				}
				s_ind = j;
			}
			i = j;
			String a,b,c;
			a = Integer.toString(b_ind);
			b = Integer.toString(s_ind);
			c = "("+a+" "+b+")";
			sb.append(c+" ");
		}
		if(sb.length() == 0){
			System.out.println("No Profit");
			return ;
		}
		System.out.println(sb);
	}

	public static void main(String [] args)throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){
			int N = Integer.parseInt(br.readLine());
			int ARR[] = new int[N];
			String s = br.readLine();
			String ssr[] = s.split(" ");
			for(int i = 0; i < N; i++)
				ARR[i] = Integer.parseInt(ssr[i]);
			_stock_Buy(ARR, N);
		}
	}
}