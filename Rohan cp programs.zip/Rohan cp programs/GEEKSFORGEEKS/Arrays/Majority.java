import java.util.Scanner;
import java.util.LinkedHashMap;
class Majority{

	public static int _check(LinkedHashMap<Integer, Integer> map, int arr[], int n){

		for(int i = 0; i < n; i++){
			if(map.get(arr[i]) > n/2)
				return arr[i];
		}
		return -1;

	}

	public static int _find_Majority_Element(int arr[], int n){

		LinkedHashMap<Integer, Integer> map = new LinkedHashMap<>();
		for(int i = 0; i < n; i++){
			if(map.containsKey(arr[i])){
				map.put(arr[i], map.get(arr[i]) + 1);
				continue;
			}
			map.put(arr[i], 1);
		}
		int result = _check(map, arr, n);
		return result;

	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int arr[] = new int[n];
			for(int i = 0; i < n; i++)
				arr[i] = input.nextInt();

			System.out.println(_find_Majority_Element(arr, n));
		}
	}
}