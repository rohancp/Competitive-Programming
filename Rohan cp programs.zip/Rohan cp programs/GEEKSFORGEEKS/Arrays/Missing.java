import java.util.Scanner;
import java.util.Arrays;
class Missing{

	public static int _missingNumber(int arr[], int n){

		int i = 0;
		Arrays.sort(arr);
		for(;i < n-1; i++){
			if(i+1 != arr[i])
				return i+1;
		}
		return n;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int arr[] = new int[n-1];
			for(int i = 0; i < n-1; i++)
				arr[i] = input.nextInt();
			int result = _missingNumber(arr, n);
			System.out.println(result);
		}
	}
}