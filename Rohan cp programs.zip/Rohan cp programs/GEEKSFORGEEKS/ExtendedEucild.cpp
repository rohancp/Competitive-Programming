#include "ExtendedEucild.h"

Triplet *ExtendedEucild::extendedEuclid(int a, int b)
{

	if (b == 0)
	{
		Triplet *ans = new Triplet();
		ans->gcd = a;
		ans->x = 1;
		ans->y = 0;

//JAVA TO C++ CONVERTER TODO TASK: A 'delete ans' statement was not added since ans was used in a 'return' or 'throw' statement.
		return ans;
	}
	Triplet *ans = new Triplet();
	Triplet *smallans = extendedEuclid(b, a % b);
	ans->x = smallans->y;
	ans->y = smallans->x - (a / b) * smallans->y;
	ans->gcd = smallans->gcd;

//JAVA TO C++ CONVERTER TODO TASK: A 'delete ans' statement was not added since ans was used in a 'return' or 'throw' statement.
	return ans;
}

void ExtendedEucild::main(std::vector<std::wstring> &args)
{

	Scanner *input = new Scanner(System::in);
	int a = input->nextInt();
	int b = input->nextInt();
	Triplet *ans = extendedEuclid(a, b);
	std::wcout << ans->gcd << std::endl;
	std::wcout << ans->x << L" " << ans->y << std::endl;

	delete input;
}
