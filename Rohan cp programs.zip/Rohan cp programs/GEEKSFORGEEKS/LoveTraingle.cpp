#include "LoveTraingle.h"

long long LoveTraingle::getSeriesNumber(long long num)
{


	StringBuilder *sb = new StringBuilder();
	while (num > 9)
	{
		sb->append(num % 9);
		num /= 9;
	}
	long long sum;
	sum = num;
	std::wstring ss = sb->toString();
	// System.out.println(ss);
	// int i = 0;
	while (ss.length() != 0)
	{

		num = StringHelper::fromString<long long>(L"" + StringHelper::toString(ss[ss.length() - 1]));
		sum = num + (10 * sum);
		ss = ss.substr(0,ss.length() - 1);
		// System.out.println(sum+" "+ss);
	// 	if(i == 1)
	// 	System.exit(0);
	// i++;
	}

	delete sb;
	return sum;
}

void LoveTraingle::main(std::vector<std::wstring> &args)
{

	try
	{
		Scanner *input = new Scanner(System::in);
		// String test_input = input.nextLine();
		StringBuilder *sb = new StringBuilder();
		// System.out.println(test_input);
		while (input->hasNext() == true)
		{
			std::wstring ss = input->nextLine();
			long long num = StringHelper::fromString<long long>(ss);
			std::wcout << getSeriesNumber(num) << std::endl;
		}
		// System.out.println(sb.toString());
		input->close();

		delete sb;
		delete input;
	}
	catch (const std::runtime_error &e)
	{
		return;
	}
}
