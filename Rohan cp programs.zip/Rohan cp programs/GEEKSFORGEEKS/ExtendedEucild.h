#pragma once

#include <string>
#include <vector>
#include <iostream>

class Triplet
{

public:
	int x = 0;
	int y = 0;
	int gcd = 0;
};
class ExtendedEucild
{

private:
	static Triplet *extendedEuclid(int a, int b);

	static void main(std::vector<std::wstring> &args);
};
