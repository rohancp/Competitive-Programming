import java.util.Scanner;
import java.util.Arrays;
class DfsAdjancyMatrix{

	private static void printGraphHepler(int edges[][], int srcv, boolean visited[]){

		System.out.println(srcv);
		visited[srcv] = true;
		for(int i = 0; i < edges.length; i++){

			if(edges[srcv][i] == 1 && !visited[i])
				printGraphHepler(edges, i, visited);
		}
	}

	private static void printGraph(int edges[][], int srcv){
		boolean visited[] = new boolean[edges.length];
		Arrays.fill(visited, false);
		for(int i = 0; i < edges.length; i++){
			if(!visited[i])
			printGraphHepler(edges, i, visited);
		}
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int e  = input.nextInt();
		int edges[][] = new int[n][n];
		for(int i = 0; i < e; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			edges[fv][sv] = 1;
			edges[sv][fv] = 1;
		}
		printGraph(edges, 0);

	}
}