import java.util.Scanner;
class Peice{
	 static int temp[][] = {{-1,0},{0,-1},{0,1},{1,0}};
    
    static boolean visited[][];
    
    private static int helper(String cake[], int row, int col){
        
        if(row < 0 || col < 0 || row >= cake.length || col >= cake[0].length() ||visited[row][col]
           || cake[row].charAt(col) == '0')return 0;
        int ans = 1;
        visited[row][col] = true;
        for(int i = 0; i < temp.length; i++){
            
            int r,c;
            r = row+temp[i][0];
            c = col+temp[i][1];
            ans += helper(cake,r,c);
        }
        visited[row][col] = false;
        return ans;
    }
    public static int solve(int n,String cake[]) {
        //write your code here
        visited = new boolean[n][n];
        int maxE = 0;
        for(int i = 0; i < n; i++){
            
            for(int j = 0; j < n; j++){
                if(cake[i].charAt(j) == '1'){
                    int ans = helper(cake,i,j);
                    maxE = Math.max(maxE,ans);
                }
            }
        }
        return maxE;
    }

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		String cake[] = new String[n];
		for(int i = 0; i < n; i++)
			cake[i] = input.next();
		System.out.print(solve(n,cake));
	}
}