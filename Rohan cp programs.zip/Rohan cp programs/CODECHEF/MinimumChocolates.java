import java.util.Scanner;
import java.util.Arrays;
class MinimumChocolates{

	private static int find_Min_chocolates(int arr[], int n){

			if(n == 1)
				return 1;

			int dp[] = new int[n];
			Arrays.fill(dp,1);
			if(arr[1] != arr[0])
			{

				if(arr[1] > arr[0])
					dp[1] = dp[0] + 1;
				else
					dp[0] = dp[1] + 1;
			}

			for(int i =2; i < n; i++){

				if(arr[i] != arr[i-1]){

					if(arr[i-1] > arr[i]){
						dp[i-1] = Math.max(dp[i]+1, dp[i-1]);
						while((i >= 2) && (arr[i-2] > arr[i-1] && dp[i-2] == dp[i-1])){

							dp[i-2] = dp[i-1] + 1;
							 i--;
						}

					}
					else
						dp[i] = dp[i-1]+1;
				}
			}
				int sum = 0;
				for(int i = 0; i < n; i++)
					sum += dp[i];
				return sum;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = find_Min_chocolates(arr, n);
		System.out.println(result);

	}
}