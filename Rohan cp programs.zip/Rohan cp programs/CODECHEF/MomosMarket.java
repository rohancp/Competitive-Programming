import java.util.Scanner;

class MomosMarket{

	private static int Find_Index(int arr[], int low, int high, int value){

		while(low < high){

			int mid = (low+high)/2;
			
			if((arr[mid] <= value) && (arr[mid+1] >= value))
				return mid;
			if(arr[mid] > value)
				high = mid -1;
			else
				low = mid + 1;
		}
		return low;

	}


	public static void main(String []a ){

		Scanner input = new Scanner(System.in);
		int shop = input.nextInt();
		int price[] = new int[shop];
		for(int i = 0; i< shop;i++)
			price[i] = input.nextInt();

		int q = input.nextInt();
		
		for(int i = 1; i < shop; i++)
			price[i] = price[i] + price[i-1];
		
		while(q-- > 0)
		{
		
			int X = input.nextInt();
		

			int index = Find_Index(price, 0, shop-1, X);
			System.out.println((index+1)+" "+ (X - price[index]));	
		}	
		
	}
}