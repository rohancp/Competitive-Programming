import java.util.*;
import java.lang.*;
import java.io.*;

class Coinsandgame{
	public static void main (String[] args) {
		//code
		Scanner a = new Scanner(System.in);
		int T= a.nextInt();
		for(int z=0;z<T;z++)
		{
		 int n = a.nextInt();
		 int k= a.nextInt();
		 
		 int count= 0;
		   if(k%2!=0) count=k/2;
        else count=k/2-1;
		 // System.out.println(count);
		 System.out.print(n-count+" ");

		 for(int y=1;y<k;y++)
		 {
		     if(y%2==0)
		     System.out.print(1+" ");
		     else
		     System.out.print(0+" ");
		 }
		 
		 System.out.println();
		}
	}
}