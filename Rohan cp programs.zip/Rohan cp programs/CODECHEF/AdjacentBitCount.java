import java.util.Scanner;
class AdjacentBitCount{

    
    static  int MOD = (int)Math.pow(10,9)+7;
	private static int find_bit_count(int n, int k, int bit, int dp_1[][],int dp_0[][]){

		if( k < 0)
			return 0;
		if( n == 1){

			if( k == 0)
				return 1;
			return 0;
		}
		// System.out.println(n+" "+k);
		if(bit == 1 && dp_1[n][k] != -1)
			return dp_1[n][k];
		if(bit == 0 && dp_0[n][k] != -1)
			return dp_0[n][k];
		int ans = 0;
		if(bit == 1){

			ans = (find_bit_count(n-1, k-1, 1,dp_1, dp_0) + find_bit_count(n-1, k, 0,dp_1, dp_0))%MOD;
		}
		if(bit == 0){

			ans = (find_bit_count(n-1, k, 1,dp_1, dp_0) + find_bit_count(n-1, k, 0,dp_1, dp_0))%MOD;
		}

		if(bit == 1)
			dp_1[n][k] = ans;
		if(bit == 0)
			dp_0[n][k] = ans;

		return ans;

	}


	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
       
		while(tc-- > 0){

			int i = input.nextInt();
			int n = input.nextInt();
			int k = input.nextInt();
			int dp_1[][] = new int [n+1][k+1];
			int dp_0[][] = new int [n+1][k+1];
			for(int j = 0 ; j <= n; j++){

				for(int l = 0; l <= k; l++)
				{

					dp_1[j][l] = -1;
					dp_0[j][l] = -1;
				}
			}
			int result = (find_bit_count(n, k, 1, dp_1, dp_0) + find_bit_count(n, k, 0, dp_1, dp_0))%MOD;
			System.out.println(i+" "+ result);

		}
	}
}