import java.util.Scanner;
class NumberOfBalanced{

	private static int Height(int h){

		if(h == 0 || h == 1)
			return 1;
		int m = (int) Math.pow(10,9)+7;
		int x = Height(h-1);
		int y = Height(h-2);
		long x1 = (long)x*x;
		long y1 = (long)x*y*2;
		int x2 = (int)(x1%m);
		int y2 = (int)(y1%m);
		return (x2+y2)%m;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int h = input.nextInt();
		int result = Height(h);
		System.out.println(result);

	}
}