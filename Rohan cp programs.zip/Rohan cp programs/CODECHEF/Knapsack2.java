import java.util.Scanner;
import java.util.Arrays;
class Knapsack2{

	private static int fill_knapsack(int v[], int wt[], int n, int W, int dp[][]){

		if(n == 0 || W == 0)
			return 0;
		if(dp[n][W] != -1)
			return dp[n][W];

		if(wt[n-1] <= W){

			int result = Math.max(v[n-1] + fill_knapsack(v, wt, n-1, W - wt[n-1], dp), fill_knapsack(v, wt, n-1, W, dp));
			dp[n][W] = result;
			return dp[n][W];
		}

		int result =  fill_knapsack(v, wt, n-1, W, dp);
		dp[n][W] = result;
		return dp[n][W];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int wt[] = new int[n];
		int value[] = new int[n];
		for(int i = 0; i < n; i++)
			wt[i] = input.nextInt();
		for(int i = 0; i < n; i++)
			value[i] = input.nextInt();
		int W = input.nextInt();
		int dp[][] = new int [n+1][W+1];
		for(int i = 0; i <= n; i++)
			Arrays.fill(dp[i],-1);
		int ans = fill_knapsack(value, wt, n, W, dp);
		System.out.println(ans);
		
	}
}