import java.util.Scanner;
import java.util.Arrays;
class Codingninja{

		static int N,M;
		static boolean visited[][];
		static char ch[][];
	private static boolean find_path(int row, int col, String s){

		if(s.isEmpty())
			return true;
		if(row < 0 || row >= N || col < 0 || col >= M || visited[row][col])
			return false;
		if(ch[row][col] == s.charAt(0)){

			visited[row][col] = true;
			String sg = s.substring(1, s.length());
			if(find_path(row, col-1, sg))
				return true;
			if(find_path(row-1, col-1, sg))
				return true;
			if(find_path(row-1, col, sg))
				return true;
			if(find_path(row-1, col+1, sg))
				return true;
			if(find_path(row, col+1, sg))
				return true;
			if(find_path(row+1, col-1, sg))
				return true;
			if(find_path(row+1, col, sg))
				return true;
			if(find_path(row+1, col+1, sg))
				return true;
			//Backtrack..
			visited[row][col] = false;
		}
		return false;
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		N = input.nextInt();
		M = input.nextInt();
		ch = new char[N][M];
		for(int i = 0; i < N; i++){
			String s = input.next();
			ch[i] = s.toCharArray();
		}
		visited = new boolean[N][M];
		for(int i = 0; i < N; i++)
			Arrays.fill(visited[i], false);
		for(int i = 0; i < N; i++){
			for(int j = 0; j < M; j++){
				if(ch[i][j] == 'C'){
					boolean result = find_path(i, j, "CODINGNINJA");
					if(result){
						System.out.println(1);
						System.exit(0);
					}
				}
			}
		}
		System.out.println(0);
	}
}