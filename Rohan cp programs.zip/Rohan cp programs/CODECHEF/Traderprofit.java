import java.util.Scanner;
class Traderprofit{

	private static int maximize_Profit(int arr[], int in, int k, int n){
		if( k == 0 || in > n)
			return 0;
		int ans = 0;
		for(int i = in; i < n; i++){
			int value = 0;
		for(int j = i+1; j <= n; j++){

				if(arr[i] < arr[j])
					value = (arr[j] - arr[i]) + maximize_Profit(arr, j+1, k-1, n);
				ans = Math.max(ans, value);
			}
		}
		return ans;
	}

	public static void main(String [] a){
		Scanner input = new Scanner(System.in);
		int queries = input.nextInt();
		while(queries-- > 0){
			int k = input.nextInt();
			int n = input.nextInt();
			int arr[] = new int[n+1];
			for(int i = 1; i <= n; i++)
				arr[i] = input.nextInt();
			int ans = maximize_Profit(arr, 1, k, n);
			System.out.println(ans);
			
		}
	}
}