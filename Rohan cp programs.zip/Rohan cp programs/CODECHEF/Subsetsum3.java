import java.util.Scanner;
class Subsetsum3{

	private static boolean subset_sum(int arr[], int n, int K){

		boolean dp[][] = new boolean[2][K+1];
		for(int i = 0; i <= K; i++)
			dp[0][i] = false;
		dp[0][0] = true;
		dp[1][0] = true;
		int flag = 1;
		for(int i = 1; i <= n ; i++){

			for(int s = 1; s <= K; s++){

				dp[flag][s] = dp[flag ^ 1][s];
				if(s >= arr[i-1])
					dp[flag][s] = dp[flag][s] || dp[flag ^ 1][s-arr[i-1]];
			}
			flag ^= 1;
		}
		return dp[flag ^ 1][K];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int K = input.nextInt();
		boolean ans = subset_sum(arr, n, K);
		if(ans)
			System.out.println("Yes");
		else
			System.out.println("No");
	}
}