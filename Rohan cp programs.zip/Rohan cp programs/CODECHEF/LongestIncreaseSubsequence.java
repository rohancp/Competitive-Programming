import java.util.Scanner;
class LongestIncreaseSubsequence{

	private static int LIS(int input[], int n){

		int output[] = new int[n];
		output[0] = 1;
		for(int i = 1; i < n; i++){

			output[i] = 1;

			for(int j = i-1; j >= 0; j--){

				if((input[i] >= input[j]) && (1+output[j] > output[i]))
					output[i]  = 1+output[j];
			}
		}
		int max = Integer.MIN_VALUE;
		for(int i = 0; i < n; i++)
		{
			if(max < output[i])
				max = output[i];
		}
		return max;
	}

	public static void main(String [] args){

		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int input[] = new int[n];
		for(int i = 0 ;i < n; i++)
			input[i] = in.nextInt();
		int result = LIS(input, n);
		System.out.println(result);

	}
}