t=int(input())
while(t>0):
    t-=1
    n=int(input())
    li=[]
    for i in range(0,n):
        li.append([int(a) for a in input().split()])
    for i in range(n-1,0,-1):
        for j in range(0,i):
            li[i-1][j]=max(li[i-1][j]+li[i][j],li[i-1][j]+li[i][j+1])
    print(li[0][0])
    
