import java.util.Scanner;
import java.util.Arrays;
class Editdistance{

	private static int make_equal(String s1, String s2, int dp[][], int m, int n){

		if(m == 0 || n == 0)
			return Math.max(m, n);

		if(s1.charAt(0) == s2.charAt(0))
			return make_equal(s1.substring(1, s1.length()), s2.substring(1, s2.length()), dp, m-1, n-1);
		if(dp[m][n] != -1)
			return dp[m][n];

		int op1 = make_equal(s1.substring(1, s1.length()), s2, dp, m-1, n) + 1;

		int op2 = make_equal(s1, s2.substring(1, s2.length()), dp, m, n-1) + 1;

		int op3 = make_equal(s1.substring(1, s1.length()), s2.substring(1, s2.length()), dp,  m-1, n-1) + 1;

		dp[m][n] = Math.min(op1, Math.min(op2, op3));

		return dp[m][n];
		
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		String s1 = input.next();
		String s2 = input.next();
		int m = s1.length();
		int n = s2.length();
		int dp[][] = new int[m+1][n+1];
		for(int i = 0; i <= m; i++)
			Arrays.fill(dp[i], -1);
		int ans = make_equal(s1, s2, dp, m, n);
		System.out.println(ans);
	}
}