import java.util.Scanner;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Arrays;
class Domino{

	public static void dfs(LinkedList<Integer> edges[], int start, boolean visited[], Stack<Integer> stack){

		visited[start] = true;
		for(int u : edges[start]){
			if(!visited[u])
				dfs(edges, u, visited, stack);
		}
		stack.push(start);
	}

	public static void dfs2(LinkedList<Integer> edges[], int start, boolean visited[]){

		visited[start] = true;
		for(int u : edges[start]){
			if(!visited[u])
				dfs2(edges, u, visited);
		}
	}
	public static int get_ans(LinkedList<Integer> edges[], int n){
		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		Stack<Integer> stack = new Stack<>();
		for(int i = 1; i <= n; i++){
			if(!visited[i]){
				dfs(edges, i, visited, stack);
			}
		}
		Arrays.fill(visited, false);
		int count = 0;
		while(!stack.isEmpty()){
			int val = stack.peek();
			stack.pop();
			if(!visited[val]){
				count += 1;
				dfs2(edges, val, visited);
			}
		}
		return count;
	}
	 public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int m = input.nextInt();
			LinkedList<Integer> edges[] = new LinkedList[n+1];
			for(int i = 0; i <= n; i++)
				edges[i] = new LinkedList<>();
			for(int i = 0; i < m; i++){
				int fv = input.nextInt();
				int sv = input.nextInt();
				edges[fv].add(sv);
			}
			int ans = get_ans(edges, n);
			System.out.println(ans);
		}
	} 
}