import java.util.Scanner;
class WinningLottery{


	private static String Generate(int num, int D){

		int arr[] = new int[D];
		int i = 0;
		for(i = D-1; i >= 0; i--){

			if( i == 0 || num < 10)
					break;
				arr[i] = 9;
				num -= 9;
		}

		if(i == 0)
			arr[i] = num;
		if( i != 0)
		{
			arr[i] = num -1;
			arr[0] = 1;
		}
		String ans = "";
		for(i = 0; i < D; i++){

			ans+=Integer.toString(arr[i]);

		}
		return ans;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int S = input.nextInt();
		int D = input.nextInt();
		String result = Generate(S, D);
		System.out.println(result);
	}
}