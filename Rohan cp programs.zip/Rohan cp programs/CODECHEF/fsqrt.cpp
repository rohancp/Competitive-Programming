#include<stdio.h>
#include<math.h>
int main(){
	int tc,num;
	scanf("%d",&tc);
	while(tc--){
		scanf("%d",&num);
		num=sqrt(num);
		printf("%d\n",num);
	}
	return 0;
}
