import java.util.Scanner;
import java.util.Arrays;
class DistributeCandies{


	private static boolean isSatisfy(long arr[], long students, long candies, int N){

		long arr2[] = arr.clone();
		long get = 0;
		for(int i = 0; i < N; i++){
			

			if(arr2[i] >= candies){
					
				get = get + (arr2[i]/candies);
			}
			if(students <= get)
				return true;
			
		}
		return false;

	}

	private static long Distribute(long arr[], long K, int N){

		Arrays.sort(arr);
		long low, high;
		low = 0;
		high = arr[N-1];
		long prev = 0;
		while(low <= high){

			long candies = (low+high)/2;
			// System.out.println(candies);
			if(isSatisfy(arr, K, candies, N)){
				// System.out.println(candies);
				low = candies+1;
				prev = Math.max(prev, candies);
			}
			else
				high = candies - 1;
		}
		return prev;


	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int N = input.nextInt();
			long S = input.nextLong();
			long arr[] = new long[N];
			for(int i = 0; i < N; i++)
				arr[i] = input.nextLong();
			long result = Distribute(arr, S, N);
			System.out.println(result);

		}
	}
}