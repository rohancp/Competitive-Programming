import java.util.Scanner;
class Subsetsum{

	static boolean subset_sum(int arr[], int n, int sum){

		if(sum == 0)
            return true;
        if(n == 0)
            return false;
		if(sum >= arr[n-1]){

			boolean a = subset_sum(arr, n-1, sum - arr[n-1]);
			if(a)
				return a;
		}
		boolean a = subset_sum(arr, n-1, sum);
		if(a)
			return true;
		return false;
	}

	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int K = input.nextInt();
		boolean ans  = subset_sum(arr, n, K);
		System.out.println(ans);
	}
}