import java.util.Scanner;
class Advancedgcd{


	public static int _gcd(int a, int b){

		if(b == 0)
			return a;
		return _gcd(b, a % b);
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int A = input.nextInt();
		String B = input.next();
		char ch[] = B.toCharArray();
		int number = 0;
		for(int i = 0; i < ch.length; i++){
			int a = ((number % A) * (10%A))%A;
			int b = Character.getNumericValue(ch[i]);
			number = ((a%A) + (b%A))%A;
		}
		int ans = _gcd(A, number);
		System.out.println(ans);
	}
}