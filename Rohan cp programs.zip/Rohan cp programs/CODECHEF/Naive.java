import java.util.Scanner;
class Naive{

	public static boolean isMatching(String t, String p){
		int n = t.length();
		int m = p.length();
		for(int i = 0; i <= n-m; i++){
			boolean b = true;
			for(int j = 0; j < m; j++){
				if(t.charAt(i+j) != p.charAt(j)){
					b = false;
					break;
				}
			}
			if(b)
				return true;
		}
		return false;
	}
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		String t = input.next();
		String p = input.next();
		boolean result = isMatching(t, p);
		System.out.println(result);
	}
}