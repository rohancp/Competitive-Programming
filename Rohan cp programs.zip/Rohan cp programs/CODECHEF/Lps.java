import java.util.Scanner;
class Lps{

	public static void createlps(String pattern){
		int lps[] = new int[pattern.length()];
		int i = 1,j = 0;
		lps[0] = 0;
		while(i < pattern.length()){

			if(pattern.charAt(j) != pattern.charAt(i)){
				if(j == 0){
					lps[i] = 0;
					i++;
				}
				else
					j = lps[j-1];
			}
			else{
				lps[i] = j+1;
				i++;j++;
			}
		}
		for(i = 0; i < pattern.length();i++)
			System.out.print(lps[i]);
	}
	
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		// String t = input.next();
		String p = input.next();
		createlps(p);
	}
}