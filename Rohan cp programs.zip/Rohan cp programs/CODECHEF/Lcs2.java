import java.util.Scanner;
import java.util.Arrays;
class Lcs2{

	private static int find_lcs(String s1, String s2, int DP[][], int m, int n){

		if(m == 0 || n == 0)
			return 0;
		if(s1.charAt(0) == s2.charAt(0))
			return 1 + find_lcs(s1.substring(1, s1.length()), s2.substring(1, s2.length()), DP, m-1, n-1);
		if(DP[m][n] != -1)
			return DP[m][n];

		int op1 = find_lcs(s1, s2.substring(1, s2.length()), DP, m, n-1);
		int op2 = find_lcs(s1.substring(1, s1.length()), s2, DP, m-1, n);
		DP[m][n] = Math.max(op1, op2);
		return DP[m][n];

	}

	public static void main(String []a){
		Scanner input = new Scanner(System.in);
		String s1 = input.next();
		String s2 = input.next();
		int m = s1.length();
		int n = s2.length();
		int DP[][] = new int[m+1][n+1];
		for(int i = 0; i <= m ;i++)
			Arrays.fill(DP[i], -1);
		int ans = find_lcs(s1, s2,DP, m, n);
		System.out.println(ans);
	}
}