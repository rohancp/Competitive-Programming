import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedList;
class Graph{

	LinkedList<Integer> adlist[];
	public Graph(int V){
		adlist = new LinkedList[V+1];
		for(int i = 1; i <= V; i++)
			adlist[i] = new LinkedList<Integer>();
	}
	public void add_Edge(int fv, int sv){
		adlist[fv].add(sv);
		adlist[sv].add(fv);
	}

	public void __helper_count_groups(int src, boolean visited[]){

		visited[src] = true;
		for(int u : adlist[src]){
			if(!visited[u])
				__helper_count_groups(u, visited);
		}
	}
	public int  count_groups(int n){
		boolean visited[] = new boolean [n+1];
		Arrays.fill(visited, false);
		int count = 0;
		for(int  i = 1; i <= n; i++){
			if(!visited[i]){
				__helper_count_groups(i, visited);
				count++;
			}
		}
		return count;
	}
}

class Islands{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int Ver = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(Ver);
		int U[] = new int[E+1];
		int V[] = new int[E+1];
		for(int i = 1; i <=E; i++){
			int fv = input.nextInt();
			U[i] = fv;
		}
		for(int i = 1; i <= E; i++){
			int sv = input.nextInt();
			V[i] = sv;
		}
		for(int i = 1; i <= E; i++){
			g.add_Edge(U[i], V[i]);
		}
		int result = g.count_groups(Ver);
		System.out.println(result);
	}
}