import java.util.Scanner;
class CoinChange{


	private static int Coin_change(int arr[], int dp[][], int V, int i){

		if( V == 0)
			return 1;

		if( i >= arr.length || V < 0)
			return 0;

		if(dp[V][i] != -1)
			return dp[V][i];
		
		int f = Coin_change(arr, dp, V - arr[i], i);
		int s = Coin_change(arr, dp, V, i + 1);

		dp[V][i] = f+s;
		return dp[V][i];

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int value = input.nextInt();
		int dp_matrix[][] = new int[value+1][n];

		for(int i = 0; i < value+1; i++){

			for(int j = 0; j < n; j++)
				dp_matrix[i][j] = -1;
		}

		int result = Coin_change(arr, dp_matrix, value, 0);
		System.out.println(result);
	}
}