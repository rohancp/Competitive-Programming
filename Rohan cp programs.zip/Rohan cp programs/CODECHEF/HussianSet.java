import java.util.Scanner;
import java.util.Vector;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Arrays;
class HussianSet{

	public static Vector<Integer> Hussian_Set(int arr[], int queries[]){
		Arrays.sort(arr);
		Queue<Integer> queue = new LinkedList<Integer>();
		Vector<Integer> vec = new Vector<Integer>();
		int i = 0,count = 1;
		int a = arr.length-1;
		while(i != queries.length){

				if(!queue.isEmpty() && queue.peek() >= arr[a]){

					int pop = queue.peek();
					queue.poll();
					if(count == queries[i]){
						vec.add(pop);
						i++;
					}
					if(pop/2 != 0){
						queue.add(pop/2);
					}
				}	

			else if(queries[i] == count){

				vec.add(arr[a]);
				if(arr[a]/2 != 0){
					queue.add(arr[a]/2);
				}
				a--;
				i++;
			}
			count++;
		}
		return vec;

	}

		public static void main(String [] args){
			Scanner input = new Scanner(System.in);
			int size  = input.nextInt();
			int q = input.nextInt();
			int arr[] = new int[size];
			for(int i = 0; i < size; i++){

				arr[i] = input.nextInt();

			}
			int querie[] = new int[q];
			for(int i = 0; i < q; i++)
			{
				querie[i] = input.nextInt();
			}
			Vector<Integer> V = Hussian_Set(arr, querie);
			for(int a : V)
				System.out.println(a);

		}
}