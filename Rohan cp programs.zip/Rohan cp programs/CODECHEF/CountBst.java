import java.util.Scanner;
class CountBst{

	public static int countTrees(int n) {

		int dp[] = new int[n+1];
		dp[0] = 1;
		dp[1] = 1;

		int MOD = (int)Math.pow(10,9)+7;
		for(int i = 2; i <= n; i++){

			for(int j = 1; j <= i; j++){

				dp[i] = (dp[i] + (dp[i-j] * dp[j-1])%MOD)%MOD;
			}
		}
		return dp[n];

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int result = countTrees(n);
		System.out.println(result);
	}
}