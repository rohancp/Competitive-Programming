import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;
class Maxtriangle{

	private static void MaxPerimeter(ArrayList<Integer> al, int n){

		boolean b = false;
		int max = Integer.MIN_VALUE;
		int a[] = new int[3];
		Collections.sort(al, Collections.reverseOrder());
		for(int i = 0; i < n-2; i++){

			if(al.get(i) < al.get(i+1) + al.get(i+2)){
				b = true;
				int s = al.get(i) + al.get(i+1) + al.get(i+2);
				if(max < s){

					a[0] = al.get(i);
					a[1] = al.get(i+1);
					a[2] = al.get(i+2);
					max = s;
				}
			}
		}
		if(b){
			Arrays.sort(a);
			System.out.println(a[0]+" "+a[1]+" "+a[2]);
		}
		else
			System.out.println("-1");

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		ArrayList<Integer> al = new ArrayList<Integer>();
		for(int i = 0; i < n; i++)
		{
			int ele = input.nextInt();
			al.add(ele);
		}

		MaxPerimeter(al, n);

	}
}