import java.util.Scanner;
class Boredom{

	private static int find_max_Points(int arr[], int n){


		int freq[] = new int[1001];
		for(int i = 0; i < n; i++){

		freq[arr[i]] = freq[arr[i]] + 1;  		
		}
		int dp[] = new int[1001];
		dp[0] = 0;
		dp[1] = freq[1];
		for(int i = 2; i < 1001; i++){

			dp[i] = Math.max(dp[i-2] + (i*freq[i]), dp[i-1]);
		}

	return dp[1000];

	}

	public static void main(String[]a){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = find_max_Points(arr, n);
		System.out.println(result);
	}
}