import java.util.*;
import java.lang.*;
import java.io.*;
class LongestPalindrome{

	public static String _p(String s, int i){
		char ch[] = s.toCharArray();
		int li = s.lastIndexOf(ch[i]);
		if(li == i)
			return ""+ch[i];
		String s1 = s.substring(i, li+1);
		String s2 = ""+ch[i];
		while(!(s2.length()>=s1.length())){
			StringBuilder sb = new StringBuilder(s1);
			sb.reverse();
			String s3 = sb.toString();
			if(s3.equals(s1)){
				if(s2.length() < s1.length())
					s2 = s1;
			}
			
			li = s1.lastIndexOf(ch[i], li-1);
			s1 = s1.substring(i, li + 1);
		}
		return s2;
	}

	public static void main(String [] args)throws IOException{
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s = br.readLine();
			String max1,max2;
			max1 = ""+s.charAt(0);
			for(int i = 0; s.length()-i > max1.length();i++){
				max2 = _p(s.substring(i,s.length()),0);
				if(max2.length() > max1.length())
					max1 = max2;
			}
			System.out.println(max1.length()+"\n"+max1);

		}catch(Exception e){
			return ;
		}
	}
}