import java.util.Scanner;
// import java.util.Vector;

class Life{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		while(true){



			int num = input.nextInt();
			if(num == 42){
				System.exit(0);
			}
			System.out.println(num);
		}



	}


}