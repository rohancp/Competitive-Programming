import java.util.Scanner;
class PrintSubsequence2{

	private static void Find2(String input, String output){

		if(input.length() == 0)
		{
			System.out.println(output);
			return ;
		}
		Find(input.substring(1), output);
		Find(input.substring(1), output + input.substring(0,1));

	}

	private static void Find(String input, String output){

		if(input.isEmpty()){
			System.out.println(output);
			return ;
		}
		Find(input.substring(1), output+input.substring(0,1));
		Find(input.substring(1), output);
	}


		public static void main(String [] args){

			Scanner input = new Scanner(System.in);
			String s = input.next();
			// Find(s, "");
			// System.out.println("Next::");
			Find2(s,"");


		}

}