import java.util.*;
import java.io.*;
import java.lang.*;
class TripleSort2{


	private static StringBuilder sortthePermutation(int per[], int pos[], PriorityQueue<Integer> pQ, int N, int K){
		// System.out.println("hii");
		// String numberofOp = "";
		StringBuilder numberofOp = new StringBuilder();
		int orgK = K;
		while(K > 0 && pQ.size() >= 3){
			int index_first = pQ.peek();
			int i = index_first;
			int a,b,c;
			a = pos[i];
			pQ.remove(a);
			i = a;
			b = pos[i];
			pQ.remove(b);
			i = b;
			if(i == index_first){
				i = pQ.peek();
			}
			c = pos[i];
			pQ.remove(c);
			int min_index,mid_index, max_index;
			min_index = Math.min(a, Math.min(b, c));
			max_index = Math.max(a, Math.max(b, c));
			if(min_index < a && a < max_index)
				mid_index = a;
			else if(min_index < b && b < max_index)
				mid_index = b;
			else
				mid_index = c;

			a = per[min_index];
			b = per[mid_index];
			c = per[max_index];

			per[min_index] = c;
			pos[c] = min_index;

			per[mid_index] = a;
			pos[a] = mid_index;

			per[max_index] = b;
			pos[b] = max_index;

			if(per[min_index] != min_index)
				pQ.add(min_index);
			if(per[mid_index] != mid_index)
				pQ.add(mid_index);
			if(per[max_index] != max_index)
				pQ.add(max_index);

				numberofOp.append(min_index).append(" ").append(mid_index).append(" ").append(max_index).append("\n");
				K--;

		}

		if(pQ.size() == 0){
			int M = orgK - K;
			StringBuilder sb = new StringBuilder();
			sb.append(M).append("\n").append(numberofOp);
			
			return sb;
		}
			StringBuilder ss = new StringBuilder();
		ss.append("-1").append("\n");
		return ss;

	}

	public static void main(String []args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int N = Integer.parseInt(s[0]);
				int K = Integer.parseInt(s[1]);
				s = br.readLine().split(" ");
				PriorityQueue<Integer> pQ = new PriorityQueue<Integer>();
				int per[] = new int[N+1];
				int pos[] = new int[N+1];
				for(int i =1; i <= N; i++){

					int val = Integer.parseInt(s[i-1]);
					per[i] = val;
					pos[val] = i;
					if(val != i){
						pQ.add(i);
					}
				}
				
				if(pQ.size() <= 2){
					// if permutation already sorted...	
					if(pQ.size() == 0)
					sb.append("0").append("\n");
					else
						sb.append("-1").append("\n");
					continue;
				}
				StringBuilder result = sortthePermutation(per, pos, pQ, N, K);
				sb.append(result);
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}