#include<stdio.h>
int main(){
	int a[1000],testcases;
	scanf("%d",&testcases);
	int i,j,tmep;
	for(i=0;i<testcases;i++)
	scanf("%d",&a[i]);
	for(i=0;i<testcases-1;i++){
		for(j=0;j<testcases-1-i;j++){
			if(a[j]>a[j+1]){
				tmep=a[j];
				a[j]=a[j+1];
				a[j+1]=tmep;
			}
		}
	}
	printf("\n");
	for(i=0;i<testcases;i++){
		printf("%d\n",a[i]);
	}
	return 0;
}
