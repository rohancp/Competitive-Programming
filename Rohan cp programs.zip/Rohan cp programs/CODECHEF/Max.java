import java.util.*;
import java.io.*;
import java.lang.*;
class Max{


	private static void helper(Deque<Integer> dQ, int n){
	
		// int dp[] = new int[n];
		StringBuilder sb = new StringBuilder();
		while(n-->0){
			Iterator it = dQ.iterator();
			long bestmax = Long.MIN_VALUE;
			long currentmax = 0;
			while(it.hasNext()){
				int ele = (int)it.next();
				currentmax = currentmax + ele;
				if(currentmax > bestmax){
					bestmax = currentmax;
				}
				if(currentmax < 0)
					currentmax = 0;
			}
			sb.append(bestmax);
			if(n != 0)
				sb.append(" ");
			dQ.addLast(dQ.pollFirst());
		}
		System.out.println(sb.toString());
	}

	public static void main(String [] args)throws IOException{
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){
				int n = Integer.parseInt(br.readLine());
				Deque<Integer> dQ = new LinkedList<Integer>();
				String s[] = br.readLine().split(" ");
				for(int i = 0; i < n; i++)
					dQ.add(Integer.parseInt(s[i]));
				helper(dQ, n);
			}
		}
		catch(Exception e){
			return;
		}
	}
}