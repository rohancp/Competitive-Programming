t=int(input())
li=[]
for i in range(0,t):
    li.append(int(input()))
li.sort()
for i in li:
    print(i)
    
