import java.util.Scanner;

class TajMahalEntry2{

		public static void main(String [] args){

			Scanner input = new Scanner(System.in);
			int N = input.nextInt();
			int arr[] = new int[N];
			for(int i = 0; i < N; i++)
				arr[i] = input.nextInt();
			
			for(int i = 0; i < N ;i++)
			{

				int t = (arr[i]-i) / N;
				if((arr[i]-i) % N !=0 )
					t += 1;
				arr[i] = i+(t*N);

			}		
			int index = 0;
			int min = arr[0];
			for(int i = 1; i < N; i++)
			{
				if(min > arr[i])
				{
					min = arr[i];
					index =  i;
				}
			}
			System.out.println(index+1);
		}
}