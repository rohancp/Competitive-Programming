import java.io.*;
import java.util.*;


class RacingHourse{



	private static int Minimum_Differenc(int arr[], int N){

		Arrays.sort(arr);
		int Min = Integer.MAX_VALUE;
		for(int i = 0; i < N-1; i++){

			int differ = Math.abs(arr[i] - arr[i+1]);

			if(Min > differ)
				Min = differ;
		}
		return Min;
	}


	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			int N = Integer.parseInt(br.readLine());
			String s[] = br.readLine().trim().split("\\s+");
			int arr[] = new int[N];
			int i = 0;
			for(String a : s)
				arr[i++] = Integer.parseInt(a);
			int result = Minimum_Differenc(arr, N);
			System.out.println(result);

		}



	}




}