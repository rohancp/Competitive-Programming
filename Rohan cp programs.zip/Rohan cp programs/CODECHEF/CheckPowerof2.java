import java.util.Scanner;
class CheckPowerof2{

	public static void main(String []a){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		if((N&(N-1)) == 0)
			System.out.println("Yes, Power of 2");
		else 
			System.out.println("No,Power of 2");
	}
}