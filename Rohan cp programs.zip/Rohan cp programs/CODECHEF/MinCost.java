import java.util.Scanner;
class MinCost{

	private static int Find_Min_Cost(int arr[][], int r, int c, int i, int j, int Sum){

		if( i == r || j == c)
			return -1;

		if( i == r-1 && j == c-1)
		{
			Sum += arr[i][j];
			return Sum;
		}

		int max1, max2, max3;
		max1 = max2 = max3	= Integer.MAX_VALUE;

		//for right..
		int v = Find_Min_Cost(arr, r, c, i, j+1, Sum+arr[i][j]);
		
		if(v != -1)
			max1 = v;
		//for diagonal..
		v = Find_Min_Cost(arr, r, c, i+1, j+1, Sum+arr[i][j]);

		if(v != -1)
			max2 = v;
		//for Down..

		v = Find_Min_Cost(arr, r, c, i+1, j, Sum+arr[i][j]);

		if(v != -1)
			max3 = v;
		return Math.min(max3, Math.min(max1, max2));
	}


	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int m = input.nextInt();
		int n = input.nextInt();
		int arr[][] = new int[m][n];
		for(int i = 0; i < m; i++){

			for(int j = 0; j < n; j++)
				arr[i][j] = input.nextInt();
		}

		int result = Find_Min_Cost(arr, m, n, 0, 0, 0);
		System.out.println(result);
	}
}