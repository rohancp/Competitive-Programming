import java.util.Scanner;
import java.util.Arrays;
class AngryChildren{

	private static long  candies(long arr[], int n, int k){

		Arrays.sort(arr);
			long result = 0;
			long prev_sum = arr[0];
			int i = 1;
			for(; i < k; i++){

				result = result + ((i*arr[i] )- prev_sum);
				prev_sum += arr[i];
			}
			i--;
			long jps = arr[0];
			long jpv = arr[0];
			long prev_result = result;

			for(int j = 1; j <= n-k; j++){

				long s = prev_sum - jps;
				long current_result = (i* arr[k+j-1]) - s;
				current_result += (prev_result - (s-(i*jpv)));
				result = Math.min(current_result, result);
				prev_result = current_result;
				prev_sum += arr[k+j-1];
				jps += arr[j];
				jpv = arr[j];
			}

			return result;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int k = input.nextInt();
		long arr[] = new long[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextLong();
		long result = candies(arr, n, k);
		System.out.println(result);
		
	}
}