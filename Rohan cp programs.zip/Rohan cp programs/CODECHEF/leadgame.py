tc=int(input())
p1=[]
p2=[]
while tc>0:
    a,b=map(int,input().split(" "))
    p1.append(a)
    p2.append(b)
    tc-=1
for i in range(1,len(p1)):
    p1[i]=p1[i]+p1[i-1]
    p2[i]=p2[i]+p2[i-1]
p1score=[]
p2score=[]
for i in range(0,len(p1)):
    if p1[i]-p2[i]>=0:
        p1score.append(p1[i]-p2[i])
    else:
        p2score.append(-1*(p1[i]-p2[i]))
a=max(p1score)
b=max(p2score)
if a>b:
    print(1,a)
else:
    print(2,b)