import java.util.Scanner;
class Triplet{

	public int x,y, gcd;
}
class Euclid{

	public static Triplet extended_euclid_algo(int a, int b){

		if(b == 0){

			Triplet ans = new Triplet();
			ans.gcd = a;
			ans.x = 1;
			ans.y = 0;
			return ans;

		}
		Triplet smallans = extended_euclid_algo(b, a%b);
		Triplet ans = new Triplet();
		ans.gcd = smallans.gcd;
		ans.x = smallans.y;
		ans.y = smallans.x-(a/b)*smallans.y;
		return ans;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		Triplet ans = extended_euclid_algo(a, b);
		System.out.println(ans.gcd+" "+ans.x+" "+ans.y);
	}
}