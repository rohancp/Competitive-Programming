import java.util.Scanner;
class Setithbit{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int i = input.nextInt();
		System.out.println(n|(1<<i));
	}

}