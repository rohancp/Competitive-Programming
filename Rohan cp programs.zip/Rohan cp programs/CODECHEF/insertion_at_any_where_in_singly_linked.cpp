#include<stdio.h>
#include<stdlib.h>
typedef struct node{
	
	int data;
	struct node *next;
	
}NODE;
	void clear(){
		system("cls");
	}
	
	//Display
	
	NODE *Display_Node(NODE *start){
		NODE *n;
		clear();
		printf("\nAll Elements are\n");
		n=start;
		while(n!=NULL)
		{
			printf("%d\n",n->data);
			n=n->next;
		}
		return start;
	}
	
	//Insert any where
	
	
	NODE *Insert_Any_Where(NODE *start){
		NODE *a,*newnode,*n;
		int user,pos=1;
		clear();
		printf("\nEnter the position\n");
		scanf("%d",&user);
		clear();
		if(user!=0){
			n=start;
			while(user>pos){
				a=n;
				n=n->next;
				if(n==NULL)
					break;
				pos++;
			}
			if(n!=NULL){
				newnode=(NODE*)malloc(sizeof(NODE));
				printf("\nEnter the data\n");
				scanf("%d",&newnode->data);
				newnode->next=n;
				start=newnode;
			}
			else if(user-1==pos && n==NULL){
				newnode=(NODE*)malloc(sizeof(NODE));
				a->next=newnode;
				printf("\nEnter the data\n");
				scanf("%d",&newnode->data);
				newnode->next=NULL;
			}
			else{
				printf("\nInvalid Position!!...");
			}
			
		}else
			printf("\nInvalid Position!!...");
		
		return start;
	}
		int main(){
			NODE *start,*a,*n;
			start=NULL;
			int con;
			printf("Press 1.For Create Node\nPress 2.For Exist\n");
			scanf("%d",&con);
			do{clear();
				if(con==2)
					break;
				n=(NODE*)malloc(sizeof(NODE));
				printf("\nEnter any Value\n");
				scanf("%d",&n->data);
				clear();
				if(start==NULL)
					start=n;
				else
					a->next=n;
				a=n;
				n->next=NULL;
				printf("Press 1.For Create Node\nPress 2.For Exist\n");
			scanf("%d",&con);
			}while(con!=2);
			
			if(start!=NULL){
				clear();
//				a=NULL;
//				n=NULL;
				con=0;
				do{
					printf("\nPress 1.Insert Node any where \nPress 2.For Display\nPress 3.For Exist\n");
					scanf("%d",&con);
					switch(con){
						
						case 1: start=Insert_Any_Where(start);
								break;
						case 2:start=Display_Node(start);
								break;
							
					}
				}while(con!=3);
			}
			else{
				printf("\nSorry, Node not Exist!!..");
			}
		}
