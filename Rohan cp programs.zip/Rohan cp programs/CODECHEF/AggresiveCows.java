import java.util.Scanner;
import java.util.Arrays;
class AggresiveCows{



	private static int LargestMinimumDifference(int arr[],int cow)
	{

		Arrays.sort(arr);
		int N = arr.length;
		int prev_distance = 0;
		int current_distance = 0;
		int d = arr[N-1] - arr[0];
		while(current_distance <= d){

			int c1 = cow-1;
			prev_distance = current_distance;
			current_distance += 1;
			int prev_pos = 0;
			for(int i = 1; i < N; i++){

				if(Math.abs(arr[prev_pos] - arr[i]) >= current_distance){
					c1--;
					prev_pos = i;
				}
				if(c1 == 0)
					break;

			}
			if(c1 != 0)
				break;
		}
		return prev_distance;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int N = input.nextInt();
			int Cows = input.nextInt();
			int position[] = new int[N];
			for(int i = 0; i < N; i++)
				position[i] = input.nextInt();
			int result = LargestMinimumDifference(position, Cows);
			System.out.println(result);
		}
	}
}