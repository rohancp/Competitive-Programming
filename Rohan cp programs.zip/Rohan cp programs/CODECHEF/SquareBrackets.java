import java.util.Scanner;
import java.util.Arrays;
class SquareBrackets{

	private static int proper_brackets(int o, int c, int n, int dp[], int dp2[][]){

		if(o == n && c == n){
			return 1;
		}
		if(dp2[o][c] != -1)
			return dp2[o][c];
		int a,b;
		a = b = 0;
		if( o < n)
			a = proper_brackets(o+1, c, n, dp, dp2);
		if( o > c && dp[o+c] == 0)
			b = proper_brackets(o, c+1, n, dp, dp2);
		dp2[o][c] = a+b;
		return dp2[o][c];
	}
	public static void main(String [] ar){

		Scanner input = new Scanner(System.in);
		int ds = input.nextInt();
		while(ds-- > 0){
			int n = input.nextInt();
			int k = input.nextInt();
			int dp[] = new int[2*n];
			for(int i = 0; i < k; i++){
				int in = input.nextInt()-1;
				dp[in] = 1;
			}
			int dp2[][] = new int[n+1][n+1];
			for(int i = 0; i <= n; i++)
				Arrays.fill(dp2[i], -1);
			int ans = proper_brackets(0, 0, n, dp, dp2);
			System.out.println(ans);
		}
	}
}