#include<stdio.h>
int main()
{
	int testcases,A,B;
	scanf("%d",&testcases);
	while(testcases-->0){
		scanf("%d %d",&A,&B);
		printf("%d\n",A+B);
		
	}
	return 0;
}

