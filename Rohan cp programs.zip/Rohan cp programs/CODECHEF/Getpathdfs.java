import java.util.Scanner;
import java.util.Arrays;
import java.util.Vector;
class Graph{

	int adjmat[][];
	public Graph(int V){
		adjmat = new int[V][V];
	}
	public void add_Edge(int fv, int sv){
		adjmat[fv][sv] = 1;
		adjmat[sv][fv] = 1;
	}

	public Vector<Integer> get_path_dfs(int src, int end, boolean visited[], int n, Vector<Integer> vec){
		visited[src] = true;
		for(int i = 0; i < n; i++){
			if(adjmat[src][i] == 1 && !visited[i]){
				if(i == end){
					vec.add(i);
					return vec;
				}
				else{
					if(get_path_dfs(i, end, visited, n, vec) != null){
						vec.add(i);
						return vec;
					}
						return null;
				}
			}
		}
		return null;
	}
}
class Getpathdfs{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		int src = input.nextInt();
		int end = input.nextInt();
		if(src == end){
			System.out.println(src);
			System.exit(0);
		}
		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		Vector<Integer> vec = new Vector<>();
		vec	= g.get_path_dfs(src, end, visited, V, vec);
		if(vec != null){
			vec.add(src);
			for(int a : vec)
				System.out.print(a+" ");
				
			}
	}
}