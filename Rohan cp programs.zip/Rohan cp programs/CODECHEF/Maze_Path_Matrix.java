import java.util.Scanner;
class Maze_Path_Matrix{

	private static void PrintPath(int sol[][], int N)
	{
		System.out.println("\n");
		for(int i = 0;i<N;i++)
		{
			for(int j = 0; j<N;j++)
				System.out.print(sol[i][j]+" ");
			System.out.println();
		}
	}


	private static void Rats_Possible_Path(int mat[][], int path[][], int r, int c, int N)
	{
		// System.out.println("D");
		if(r == N-1 && c == N-1)
		{
			path[r][c] = 1;
			PrintPath(path,N);
			return ;
		}
		if(r>=N || r<0 || c>=N || c<0 || path[r][c] == 1 || mat[r][c] == 0)
			return ;
		
		path[r][c] = 1;
		//Up

		Rats_Possible_Path(mat, path, r-1,c,N);

		//Down

		Rats_Possible_Path(mat, path, r+1, c, N);

		//Left

		Rats_Possible_Path(mat, path, r,c-1,N);

		//Right

		Rats_Possible_Path(mat, path,r, c+1,N);

		path[r][c] = 0;
		return ;

	}

		public static void main(String[] args)
		{
			Scanner input = new Scanner(System.in);
			int tc = input.nextInt();
			while(tc-->0)
			{
				int N = input.nextInt();
				int Mat[][] = new int[N][N];

				for(int i = 0 ;i<N;i++)
				{
					for(int j = 0;j<N;j++)
						Mat[i][j] = input.nextInt();
				}
				int Path[][] = new int[N][N];
				for(int i = 0 ;i<N;i++)
				{
					for(int j = 0;j<N;j++)
						Path[i][j] = 0;
				}
				Rats_Possible_Path(Mat, Path, 0, 0, N);
			}
		}
}