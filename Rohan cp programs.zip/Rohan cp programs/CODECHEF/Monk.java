import java.util.Scanner;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Queue;
class Graph{
	LinkedList<Integer> edges[];
	public Graph(int V){
		edges = new LinkedList[V+1];
		for(int i = 0 ; i <= V; i++)
			edges[i] = new LinkedList<>();
	}

	public void add_edge(int fv, int sv){
		edges[fv].add(sv);
		edges[sv].add(fv);
	}

	public int bfs(int start, int n){
		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		Queue<Integer> queue = new LinkedList<>();
		queue.add(start);
		int distance[] = new int[n+1];
		distance[start] = 0;
		visited[start] = true;
		while(!queue.isEmpty()){
			int val = queue.peek();
			queue.poll();
			for(int u : edges[val]){
				if(!visited[u]){
					distance[u] = distance[val]+1;
					queue.add(u);
					visited[u] = true;
				}
			}
		}
		return distance[n];
	}
}
class Monk{

	public static void main(String[] arhs){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int m = input.nextInt();
			Graph g = new Graph(n);
			for(int i = 0; i < m; i++){
				int fv = input.nextInt();
				int sv = input.nextInt();
				g.add_edge(fv, sv);
			}
			int ans = g.bfs(1, n);
			System.out.println(ans);
		}
	}
}