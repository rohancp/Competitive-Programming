import java.util.Scanner;
class Unsetithbit{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int i = input.nextInt();
		int a = N&(1<<i);
		if( a == 0)
			System.out.println(N);
		else 
			System.out.println(N^a);

	}
}