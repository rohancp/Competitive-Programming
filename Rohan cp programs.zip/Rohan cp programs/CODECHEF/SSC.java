import java.util.Scanner;
import java.util.Arrays;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Stack;
import java.util.LinkedList;
class SSC{

	public static void dfs(LinkedList<Integer> edges[], int start, Stack<Integer> stack, boolean visited[]){

		visited[start] = true;
		for(int u : edges[start]){
			if(!visited[u]){
				dfs(edges, u, stack, visited);
			}
		}
		stack.push(start);
	}

	public static void dfs2(HashSet<Integer> component,  int start, LinkedList<Integer> edgesT[], boolean visited[]){

		visited[start] = true;
		component.add(start);
		for(int u : edgesT[start]){
			if(!visited[u])
				dfs2(component, u, edgesT, visited);
		}
	}
	public static HashSet<HashSet<Integer>> get_component(LinkedList<Integer> edges[], LinkedList<Integer> edgesT[], int n){

		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		Stack<Integer> stack = new Stack<>();
		for(int i = 1; i <= n; i++){
			if(!visited[i]){
				dfs(edges, i, stack, visited);
			}
		}

		HashSet<HashSet<Integer>> output = new HashSet<>();
		Arrays.fill(visited, false);
		while(!stack.isEmpty()){

			int ele = stack.peek();
			stack.pop();
			if(!visited[ele]){
				HashSet<Integer> comp = new HashSet<>();
				dfs2(comp, ele, edgesT, visited);
				output.add(comp);
			}
		}
		return output;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		LinkedList<Integer> edges[] = new LinkedList[V+1];
		LinkedList<Integer> edgesT[] = new LinkedList[V+1];
		for(int i = 0; i <= V; i++){
			edges[i] = new LinkedList<>();
			edgesT[i] = new LinkedList<>();
		}
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			edges[fv].add(sv);
			edgesT[sv].add(fv);
		}

		HashSet<HashSet<Integer>> components = get_component(edges, edgesT, V);
		Iterator<HashSet<Integer>> it = components.iterator();
		while(it.hasNext()){
			HashSet<Integer> comp = it.next();
			Iterator<Integer> it2 = comp.iterator();
			while(it2.hasNext()){
				System.out.print(it2.next()+ " ");
			}
			System.out.println();
		}
	}
}