import java.util.Scanner;
class Segmenttree{

	private static void build_tree(int arr[], int tree[], int start, int end, int treenode){

		if(start == end){
			tree[treenode] = arr[start];
			return ;
		}
		 int mid = (start+end)/2;
		 build_tree(arr, tree, start, mid, 2*treenode);
		 build_tree(arr, tree, mid+1, end, (2*treenode)+1);
		 tree[treenode] = tree[2*treenode] + tree[(2*treenode)+1];
	}

	private static void update_tree(int arr[], int tree[], int treenode, int s, int e, int idx, int value){

		if(s == e){
			arr[idx] = value;
			tree[treenode] = value;
			return ;
		}
		int mid = (s+e)/2;
		if(idx <= mid)
			update_tree(arr, tree, 2*treenode, s, mid, idx, value);
		else
			update_tree(arr, tree, (2*treenode)+1, mid+1, e, idx, value);

		tree[treenode] = tree[2*treenode] + tree[(2*treenode)+1];
	}

	private static int Query(int tree[], int treenode, int s,int e, int l, int r){

		if( e < l || r < s)
			return 0;
		if(s >= l && r >= e)
			return tree[treenode];
		int mid = (s+e)/2;
		int ans1 = Query(tree, (2*treenode), s, mid, l,r);
		int ans2 = Query(tree, (2*treenode)+1,mid+1, e,l,r);
		return (ans1+ans2);
	}
	
	public static void main(String [] args){

		int arr[] = {1,2,3,4,5};
		int tree[] = new int[10];
		build_tree(arr, tree, 0, 4, 1);
		// update_tree(arr, tree, 1, 0, 4, 2, 10);
		for(int i =1; i < 10; i++)
			System.out.println(tree[i]);
		System.out.println();
		int ans = Query(tree, 1, 0, 4, 1, 3);
		System.out.println(ans);

	}
}