#include<stdio.h>
int main(){
	int tc,n,r=0;
	scanf("%d",&tc);
	while(tc-->0){
		scanf("%d",&n);
		r=0;
		while(n>0){
			r=r*10+n%10;
			n=n/10;
		}
		printf("%d\n",r);
	}
	return 0;
}
