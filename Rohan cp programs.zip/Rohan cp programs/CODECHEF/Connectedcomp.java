import java.util.Scanner;
import java.util.Arrays;
import java.util.Vector;
import java.util.Collections;
import java.util.LinkedList;
class Graph{

	LinkedList<Integer> adlist[];
	public Graph(int V){
		adlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adlist[i] = new LinkedList<Integer>();
	}

	public void add_Edge(int fv, int sv){
		adlist[fv].add(sv);
		adlist[sv].add(fv);
	}
	public void _connected_comp(int src, boolean visited[], Vector<Integer> vec){
		visited[src] = true;
		vec.add(src);
		for(int u : adlist[src]){
			if(!visited[u])
				_connected_comp(u, visited, vec);
		}
	}
	public void all_con_comp(int n){
		boolean visited[] = new boolean [n];
		Arrays.fill(visited, false);
		Vector<Vector<Integer>> compn = new Vector<>();
		for(int i = 0 ; i < n; i++){
			if(!visited[i]){
				Vector<Integer> vec = new Vector<>();
				_connected_comp(i, visited, vec);
				compn.add(vec);
			}
		}
		for(Vector<Integer> vec : compn){
			Collections.sort(vec);
			for(int a : vec)
				System.out.print(a+" ");
			System.out.println();
		}
	}
}

class Connectedcomp{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		g.all_con_comp(V);
	}
}