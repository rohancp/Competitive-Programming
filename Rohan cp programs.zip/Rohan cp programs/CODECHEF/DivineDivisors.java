import java.util.*;
import java.io.*;
class DivineDivisors{

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		HashMap<Long, TreeSet<Long>> hmap = new HashMap<Long, TreeSet<Long>>();
		while(tc-- > 0){

			long n = Long.parseLong(br.readLine());
			if(!(hmap.containsKey(n))){
			TreeSet<Long> ts = new TreeSet<Long>();
			int num = (int)Math.sqrt(n);
			for(int i = 1; i <= num; i++){

				if(n%i == 0){

					if(n/i == i){

						ts.add((long)i);
					}
					else{
						ts.add((long)i);
						ts.add((long)n/i);
					}

				}
			}
			hmap.put(n, ts);
			}
			TreeSet<Long> ts = hmap.get(n);
			Iterator<Long> it = ts.iterator();
			while(it.hasNext()){

				System.out.print(it.next()+" ");
			}
			System.out.println();
		}
	
	}
}