import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;
class Main{


	private static int KadaneSum(int dp[], int n){

		int cs = 0, bs = Integer.MIN_VALUE;
        int r = -1;

		for(int i = 0; i < n; i++){

			cs += dp[i];
			if(cs < 0)
				cs = 0;
			else if( cs > bs){
                r = 1;
				bs = cs;}
		}
        if( r == -1){
            Arrays.sort(dp);
            bs = dp[n-1];
        }
		return bs;
	}

	private static int Find_Max_Sum_Rectangle(int arr[][], int r, int c){

		int max_sum = Integer.MIN_VALUE;

		for(int i = 0; i < c; i++){

			int dp[] = new int[r];
			Arrays.fill(dp, 0);
			for(int j = i; j < c; j++){

				for(int k = 0; k < r; k++)
					dp[k] += arr[k][j];

				int result = KadaneSum(dp, r);
				max_sum = Math.max(max_sum, result);
			}

		}
			return max_sum;

	}
	public static void main(String [] args)throws IOException{

		// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// String a = br.readLine();
		// String s[] = a.split(" ");
		// int r = Integer.parseInt(s[0]);
		// int c = Integer.parseInt(s[1]);
		// int arr[][] = new int[r][c];
		// for(int i = 0; i < r; i++){

		// 	a = br.readLine();
		// 	s = a.split(" ");
		// 	int j = 0;
		// 	for(String aa : s)
		// 		arr[i][j++] = Integer.parseInt(aa);
		
		// }
		// 	int result = Find_Max_Sum_Rectangle(arr, r, c);
		// 	System.out.println(result);

		Scanner input = new Scanner(System.in);
		int r = input.nextInt();
		int c = input.nextInt();
		int arr[][] = new int[r][c];
		for(int i = 0 ; i < r; i++){

			for(int j = 0; j < c; j++)
				arr[i][j] = input.nextInt();
		}
		int result = Find_Max_Sum_Rectangle(arr, r, c);
			System.out.println(result);
	}
}