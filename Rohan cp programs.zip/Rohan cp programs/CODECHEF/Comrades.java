//#Rohan i am using dynamic programming to solve this problem..

import java.io.*;
import java.util.*;
class Graph{

	LinkedList<Integer> list[];
	public Graph(int size){
		list = new LinkedList[size];
		for(int i = 1; i < size; i++){
			list[i] = new LinkedList<>();
		}
	}

	public void addEdge(int u, int v){

		list[u].add(v);
	}

	public TreeNode createGeneralTree(int rt){

		TreeNode root = new TreeNode(rt);
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		queue.add(root);
		while(!queue.isEmpty()){

			TreeNode frontnode = queue.poll();
			for(int ele : list[frontnode.data]){
				TreeNode newnode = new TreeNode(ele);
				frontnode.children.add(newnode);
				queue.add(newnode);
			}
		}
		return root;
	}
	// public void print(int rt){

	// 	Queue<Integer> queue = new LinkedList<Integer>();
	// 	queue.add(rt);
	// 	while(!queue.isEmpty()){
	// 		int frontele = queue.poll();
	// 		String ans = frontele+":";
	// 		String s = "";
	// 		for(int a : list[frontele]){
	// 			s += a+" ";
	// 			queue.add(a);
	// 		}
	// 		System.out.println(ans+s);
	// 	}
	// }

	// public void printTree(TreeNode root){

	// 	Queue<TreeNode> queue = new LinkedList<>();
	// 	queue.add(root);
	// 	while(!queue.isEmpty()){
	// 		TreeNode frontnode = queue.poll();
	// 		String ans = frontnode.data+" : ";
	// 		for(TreeNode a : frontnode.children){
	// 			ans = ans + a.data+" ";
	// 			queue.add(a);
	// 		}
	// 		System.out.println(ans);
	// 	}
	// }

}

class TreeNode{

	int data;
	ArrayList<TreeNode> children;

	public TreeNode(int data){
		this.data = data;
		children = new ArrayList<TreeNode>();
	}
}
public class Comrades{


	public static HashMap<Integer, Integer> helperWithMap(TreeNode root){

		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		int i = 1;
		queue.add(root);
		while(!queue.isEmpty()){
			int size = queue.size();
			map.put(i,size);
			while(size-- > 0){
				TreeNode frontnode = queue.poll();
				for(int j = 0; j < frontnode.children.size(); j++){

						queue.add(frontnode.children.get(j));
				}
			}
			i++;
		}
		return map;
	}

	public static void countShakeHandes(int dptable1[], TreeNode root, int count){
		dptable1[root.data] = count;
		for(int i = 0; i < root.children.size(); i++){
			countShakeHandes(dptable1, root.children.get(i),count+1);
		}
	}

	public static void countFistBumps(int dptable2[], HashMap<Integer, Integer> mainmap, HashMap<Integer, Integer> temp, 
		TreeNode root, int count, int level){

		if(temp.containsKey(level)){

			dptable2[root.data] = count + (mainmap.get(level)-1-temp.get(level));
			temp.put(level, temp.get(level)+1);

		}else{
			dptable2[root.data] = count + (mainmap.get(level)-1);
			temp.put(level,1);
		}

		for(int i = 0; i < root.children.size();i++){

			countFistBumps(dptable2, mainmap,temp, root.children.get(i),count+mainmap.get(level)-1,level+1);
		}

	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		Graph graph;
		while(tc-- > 0){
			int n = Integer.parseInt(br.readLine());
			String soldier[] = br.readLine().split(" ");
			int root = -1;
			graph = new Graph(n+1);
			for(int i = 1; i <= n; i++){
				int immdteSupp = Integer.parseInt(soldier[i-1]);
				if(immdteSupp == 0) {
					root = i;
					continue;
				}
				graph.addEdge(immdteSupp,i);
			}
			// graph.print(root);
			TreeNode commander = graph.createGeneralTree(root);
			// graph.printTree(commander);
			int dptable1[] = new int [n+1];
			countShakeHandes(dptable1,commander, 0);
			int counthands = 0;
			for(int i = 1; i <= n; i++){
				// System.out.println(i+" "+dptable1[i]);
				counthands += dptable1[i];
			}
			// System.out.println(counthands);
			HashMap<Integer, Integer> map = helperWithMap(commander);
			// for(Map.Entry<Integer, Integer> entry : map.entrySet()){
			// 	System.out.println(entry.getKey()+" "+entry.getValue());
			// }
			int dptable2[] = new int[n+1];
			countFistBumps(dptable2, map, new HashMap<Integer, Integer>(), commander, 0, 1);
			int countfistbumps = 0;
			for(int i = 1; i <= n; i++){

				countfistbumps += dptable2[i];
			}
			System.out.println(counthands+" "+countfistbumps);
		}

	}
}