import java.util.Scanner;
import java.util.Arrays;

class Variation{

	private static int Find_D(int arr[], int K, int N){

		Arrays.sort(arr);
		int i,j,c;
		i = 0; j =1; c = 0;
		while(j < N){

			if(Math.abs(arr[i] - arr[j]) >= K){

				c +=  N - j;
				i++;
				continue;
			}
			j++;
		}
		return c;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int K = input.nextInt();
		int arr[] = new int[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextInt();
		int result = Find_D(arr, K, N);
		System.out.println(result);
	}
}