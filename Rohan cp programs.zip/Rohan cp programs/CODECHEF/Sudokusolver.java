import java.util.Scanner;
class Sudokusolver{

	private static boolean isPlaced(int board[][], int row, int col, int num){

			for(int i = 0; i < 9; i++){

				if(board[row][i] == num || board[i][col] == num)
					return false;
			}

			row = row - row%3;
			col = col - col%3;
			for(int i = row; i < row +3; i++){

				for(int j = col; j < col+3; j++)
				{
					if(board[i][j] == num)
						return false;
				}
			}

			return true;

	}
		private static boolean SolveSudoku(int board[][], int row, int col){

			if(row == 9)
			{
				return true;
			}

			if(col >= 9){
				return SolveSudoku(board, row+1, 0);
			}
			if(board[row][col] != 0)
			{
				return SolveSudoku(board,row,col+1);
			}

			for(int i = 1; i <= 9; i++){

				if(isPlaced(board,row, col, i)){
					board[row][col] = i;
					if(SolveSudoku(board, row, col+1))
						return true;
					else
						board[row][col] = 0;
				}
			}


			return false;
		}

	public static void main(String []a ){

		Scanner input = new Scanner(System.in);
		int board[][] = new int[9][9];
		for(int i = 0; i < 9; i++){

			for(int j = 0; j < 9; j++)
				board[i][j] = input.nextInt();
		}
		boolean result = SolveSudoku(board, 0, 0);
		System.out.println(result);

	}

}