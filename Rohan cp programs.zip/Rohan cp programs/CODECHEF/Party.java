import java.util.Scanner;
class Party{

	private static void party_fun(int wt[], int v[], int n, int W){

		int dp[][] = new int [n+1][W+1];
		for(int i = 1; i <= n; i++){

			for(int w = 1; w <= W; w++){

				if(w >= wt[i-1]){

					dp[i][w] = Math.max(v[i-1] + dp[i-1][w - wt[i-1]], dp[i-1][w]);
				}
				else
					dp[i][w] = dp[i-1][w];
			}
		}
		int ans = 0;
		for(int i = 0 ; i <= W;i++){

			if(dp[n][W] == dp[n][i]){

				ans = i;
				break;
			}
		}
		System.out.println(ans+" "+dp[n][W]);

	}

	public static void main(String [] a){

		Scanner input = new Scanner(System.in);
		while(true){

			int W = input.nextInt();
			int n = input.nextInt();
			if(W == 0 && n == 0)
				System.exit(0);
			int wt[] = new int [n];
			int v[] = new int [n];
			for(int i = 0; i < n; i++){

				wt[i] = input.nextInt();
				v[i] = input.nextInt();
			}
			
			party_fun(wt, v, n, W);	
			
		}
	}
}