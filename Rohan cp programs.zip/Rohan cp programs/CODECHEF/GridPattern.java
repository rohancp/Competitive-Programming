import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class GridPattern{

	//Perform operation...

	public static boolean Grid_Pattern(String G[], String P[])
	{

		boolean b = false;
		int count,a,pos,j = 0;
		int R,r;
		R = G.length;
		r = P.length;
		for(int i = 0;i<R;i++)
		{
			count = 0;
			pos = 0;
			a = G[i].indexOf(P[j]);

			while(0<a)
			{

				if(count == 0)
				{
					count++;
					pos = a;//here it is now constant
				}
				i++;j++;
				if(count == r)
				{
					b = true;
					break;
				}
				if(i == R)
					break;
				a = G[i].indexOf(P[j]);
				if(a == pos)
					count++;
				else
				{
					i = i-1;
					break;
				}
			}
			if(b)
				break;
		}

		return b;
	}



	public static void main(String[] args)throws IOException
	{


		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-->0)
		{

			int arr[] = new int[2];

			//input first Grid... Pattern..


			String line = br.readLine();
			String s[] = line.trim().split("\\s+");
			for(int i = 0 ;i<2;i++)
				arr[i] = Integer.parseInt(s[i]);
			int R = arr[0];
			int C = arr[1];
			String G[] = new String[R];
			for(int i = 0;i<R;i++)
				G[i] = br.readLine();

			//input second Grid.. Pattern..


			int arr2[] = new int[2];
			String line1 = br.readLine();
			String s1[] = line1.trim().split("\\s+");
			for(int i = 0;i<2;i++)
				arr2[i] = Integer.parseInt(s1[i]);
			int r = arr2[0];
			int c = arr2[1];
			String P[] = new String[r];
			for(int i = 0;i<r;i++)
				P[i] = br.readLine();

			boolean result = Grid_Pattern(G, P);

			if(result)
				System.out.println("Yes");
			else
				System.out.println("No");
		}

	}

}