import java.util.Scanner;
class Lsb{

	private static int Find(int n, int i){

		int a = (1<<i);
		System.out.println(a);
		a = a | (a-1);
		return (~a&n);
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int i = input.nextInt();
		int result = Find(N,i);
		System.out.println(result);
	}
}