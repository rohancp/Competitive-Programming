import java.util.Scanner;
import java.util.Arrays;
class Minimumcost{
	public static int mincost(int cost[][], int n, int p, int mask, int dp[]){
		if(p >= n)
			return 0;
		if(dp[mask] != Integer.MAX_VALUE)
			return dp[mask];
		int minans = Integer.MAX_VALUE;
		for(int j = 0; j < n; j++){
			if(((mask &(1<<j)) ^ 1) != 0){
				int ans = mincost(cost, n, p+1, mask | (1<<j), dp) + cost[p][j];
				minans = Math.min(ans, minans);
			}
		}
		dp[mask] = minans;
		return minans;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int p = input.nextInt();
		int job = input.nextInt();
		int cost[][] = new int[p][job];
		for(int i = 0; i < p; i++){
			for(int j = 0; j < job; j++)
				cost[i][j] = input.nextInt();
		}
		int dp[] = new int[1<<job];
		Arrays.fill(dp, Integer.MAX_VALUE);
		int ans = mincost(cost, job, 0, 0, dp);
		System.out.println(ans);
	}
}