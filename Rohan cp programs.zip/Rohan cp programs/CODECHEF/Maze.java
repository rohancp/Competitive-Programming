import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Collections;
import java.util.LinkedHashMap;
class Maze{

	static LinkedList<String> ll = new LinkedList<String>();

	public static void PrintMap(LinkedHashMap<String,Character> l)
	{

		String s = "";
		for(char c : l.values())
			s+=c;
		ll.add(s);
		return ;

	}

	public static void Rat_In_Maze(LinkedHashMap<String,Character> lhm, int c_r, int c_c, int p_r, int p_c, int n, int M[][])
	{
		if(c_r>=n || c_c>=n || c_r<0 || c_c<0)
			return ;
		if(c_r == n-1 && c_c == n-1)
		{
			PrintMap(lhm);
			return ;
		}
		String a = Integer.toString(c_r);
		String b = Integer.toString(c_c);

		if(!lhm.containsKey(a+b))
		{
			//up 'U'

			if(!(c_r-1<0) && (c_r-1!=p_r && M[c_r-1][c_c] == 1))
			{
				lhm.put(a+b,'U');
				Rat_In_Maze(lhm, c_r-1, c_c, c_r, c_c, n, M);
				lhm.remove(a+b);
			}

			//Down 'D'

			if(!(c_r+1>=n) && (c_r+1!=p_r && M[c_r+1][c_c] == 1))
			{

				lhm.put(a+b,'D');
				Rat_In_Maze(lhm, c_r+1, c_c, c_r, c_c, n, M);
				lhm.remove(a+b);
			}

			//Left 'L'

			if(!(c_c-1<0) && (p_c!=c_c-1 && M[c_r][c_c-1] == 1))
			{

				lhm.put(a+b,'L');
				Rat_In_Maze(lhm, c_r, c_c-1, c_r, c_c, n, M);
				lhm.remove(a+b);
			}

			//Right 'R'

			if(!(c_c+1>=n) && (p_c!=c_c+1 && M[c_r][c_c+1] == 1))
			{
				lhm.put(a+b,'R');
				Rat_In_Maze(lhm, c_r, c_c+1, c_r, c_c, n, M);
				lhm.remove(a+b);
			}
		}
		return ;
	}


	public static void main(String [] args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-->0)
		{
			int N = Integer.parseInt(br.readLine());
			int arr[] = new int[N*N];
			int Mat[][] = new int[N][N];
			String line = br.readLine();
			String s[] = line.trim().split("\\s+");
			for(int i = 0;i<N*N;i++)
				arr[i] = Integer.parseInt(s[i]);
			int k = 0;
			for(int i = 0;i<N;i++)
			{
				for(int j = 0;j<N;j++)
					Mat[i][j] = arr[k++];
			}
			// for(int i = 0;i<N;i++)
			// {
			// 	for(int j = 0;j<N;j++)
			// 	System.out.print(Mat[i][j]+" ");
			// System.out.println();
			// }

			int c_r,c_c;
			c_r = 0;
			c_c = 1;
			char c = 'R';
			if(Mat[1][0] == 1)
			{
				c_r = 1;
				c_c = 0;
				c = 'D';
			}
			// ll.put("00",c);
			LinkedHashMap<String,Character> lhm = new LinkedHashMap<String,Character>();
			// lhm.put("00",c);
			Rat_In_Maze(lhm, 0, 0, 0, 0, N,Mat);
			Collections.sort(ll);
			for(String sss : ll)
				System.out.print(sss+" ");
			System.out.println();
			ll.removeAll(ll);
		}
	}
}