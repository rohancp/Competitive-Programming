import java.util.Scanner;
class Node{

	int maxpreffixsum;
	int maxsuffixsum;
	int maxsum;
	int totalsum;
}
class Maxsuminsubarray{

	private static Node all_operation(Node left, Node right){

		Node node = new Node();
		node.maxsum = Math.max(Math.max(left.maxsum, right.maxsum),(left.maxsuffixsum + right.maxpreffixsum));
		node.totalsum = left.totalsum + right.totalsum;
		node.maxpreffixsum = Math.max(left.maxpreffixsum, (left.totalsum + right.maxpreffixsum));
		node.maxsuffixsum = Math.max(right.maxsuffixsum,(right.totalsum + left.maxsuffixsum));
		return node;
	}

	private static void build_tree(int arr[], Node tree[], int treenode, int start, int end){

		if(start == end){

		tree[treenode] = new Node();
		tree[treenode].maxsum = tree[treenode].totalsum = tree[treenode].maxpreffixsum = tree[treenode].maxsuffixsum =  arr[start];
			return ;
		}
		
		int mid = (start+end)/2;
		build_tree(arr, tree, (2*treenode), start, mid);
		build_tree(arr, tree, (2*treenode)+1, mid+1, end);

		tree[treenode] = all_operation(tree[2*treenode], tree[(2*treenode)+1]);

	}

	private static Node find_ans(Node tree[], int treenode, int start, int end, int l, int r){

		if( end < l || start > r)
			return null;
		if(start >= l && end <= r)
			return tree[treenode];
		int mid = (start + end)/2;
		Node ans1 = find_ans(tree, (2*treenode), start, mid, l, r);
		Node ans2 = find_ans(tree, (2*treenode)+1, mid+1, end, l, r);
		if(ans1 != null && ans2 != null){

			Node result = all_operation(ans1, ans2);
			return result;
		}
		else if(ans1 != null)
			return ans1;
		return ans2;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int query = input.nextInt();
		Node tree[] = new Node[4*n];
		build_tree(arr, tree, 1, 0, n-1);
		while(query-- > 0){
			int l = input.nextInt()-1;
			int r = input.nextInt()-1;
			Node result = find_ans(tree, 1, 0, n-1, l, r);
			System.out.println(result.maxsum);
		}
	}
}