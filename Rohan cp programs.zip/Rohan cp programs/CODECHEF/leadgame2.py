tc=int(input())
p1score=0
p2score=0
maxscore=0
w=1
while tc>0:
    tc-=1
    a,b=map(int,input().split())
    p1score+=a
    p2score+=b
    if abs(p1score-p2score)>maxscore:
           maxscore=abs(p1score-p2score)
           if (p1score>p2score):
               w=1
           else:
               w=2
    
print(w,maxscore)
