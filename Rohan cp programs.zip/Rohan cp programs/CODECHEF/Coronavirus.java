import java.io.*;
import java.util.*;
import java.lang.*;
class Coronavirus{


	private static String getAns(int arr[], int N){

		int count = 1;
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		for(int i = 1; i < N; i++){
			if(Math.abs(arr[i-1]- arr[i]) <= 2)
				count += 1;
			else{

				max = Math.max(max, count);
				min = Math.min(min, count);
				count = 1;
			}
		}
		max = Math.max(max, count);
		min = Math.min(min, count);
		return min+" "+max;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				int arr[] = new int[N];
				for(int i = 0; i < N; i++)
					arr[i] = Integer.parseInt(s[i]);
				String ans = getAns(arr, N);
				sb.append(ans+"\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){
			return ;
		}

	}
}