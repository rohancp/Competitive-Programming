import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import java.util.LinkedHashSet;
import java.util.Iterator;
class Combination_Sum2{

	static LinkedHashSet<String> hs = new LinkedHashSet<String>();

	// static int count = 0;

	public static void Combination(Vector<Integer> vec, int arr[], int Sum, int val, int index)
	{

		if(Sum == val)
		{
			Print_List(vec);
			// count+=1;
			return ;
		}
		if(Sum > val || index >= arr.length)
			return ;

		Sum+=arr[index];

		vec.add(arr[index]);

		Combination(vec, arr, Sum, val, index + 1);

		//Now Backtrack..

		Sum-=arr[index];
		vec.remove(vec.size() - 1);
		Combination(vec, arr, Sum, val, index + 1);
		return ;
	}

	public static void Print_List(Vector<Integer> vec)
	{

		StringBuffer sb = new StringBuffer();
		sb.append("(");
		for(int i = 0;i<vec.size();i++)
		{

			String a = Integer.toString(vec.get(i));
			sb.append(a);
			if(i!=vec.size()-1)
				sb.append(" ");
		}
		sb.append(")");
		hs.add(sb.toString());
		// System.out.println(hs);

	}

	public static void main(String[]args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-->0)
		{

			int N = Integer.parseInt(br.readLine());
			int arr[] = new int[N];
			String line = br.readLine();
			String s[]  = line.trim().split("\\s+");
			for(int i = 0;i<N;i++)
				arr[i] = Integer.parseInt(s[i]);
			int Sum = Integer.parseInt(br.readLine());

			Arrays.sort(arr);
			Vector<Integer> vec = new Vector<Integer>();
			Combination(vec,arr,0, Sum, 0);
			if(hs.size() == 0 )
				System.out.print("Empty");
			else
			{
				Iterator<String> it = hs.iterator();
				while(it.hasNext())
					System.out.print(it.next());
				hs.removeAll(hs);
			}
			System.out.println();
		}
	}
}