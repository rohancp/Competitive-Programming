import java.util.Scanner;

class QuickSort{

	private static void Swap(int arr[], int i, int j){

		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	private static int partition(int arr[], int si, int ei){

		int X = arr[si];

		int count = 0;
		for(int i = si+1; i <= ei; i++){

			if(X > arr[i])
				count++;
		}
		// System.out.println(count);
		Swap(arr, si, si + count);
		int i = si;int j = ei;
		while((si+count) != i && (si+count) != j){

			if(X >  arr[i])
				i++;
			else if( X < arr[j])
				j--;
			else
				Swap(arr, i, j);


		}
		// System.out.prinltn("Rohan");
		return (si+count);


	}

	private static void QS(int arr[], int si, int ei){

			if(si < ei){
				int C = partition(arr, si, ei);
				// System.out.println(C);
				QS(arr, si, C-1);
				QS(arr, C+1, ei);
			}
	}

		public static void main(String [] args){

			Scanner input = new Scanner(System.in);
			int N = input.nextInt();
			int arr[] = new int[N];
			for(int i = 0; i < N; i++)
				arr[i] = input.nextInt();
			// System.out.println("Rohan");
			QS(arr, 0, N-1);
			// System.out.println("After Sort:");
			for(int i = 0; i < N; i++)
				System.out.print(arr[i]+" ");
		}
}