import java.util.*;
class Cn{

	static int temp[][] = {{-1,0},{-1,-1},{-1,1},{0,-1},
							{0,1},{1,-1},{1,0},{1,1}};
    
    private static boolean helper(String Graph[],String str, int row,int col, boolean visited[][]){
    	if(str.isEmpty())return true;

        
        if(row<0 || row>=Graph.length || col<0 || col>=Graph[0].length() || visited[row][col])return false;
        
        // System.out.println(row+" "+col+" "+(Graph[row].charAt(col))+" "+str);
        if(Graph[row].charAt(col) == str.charAt(0)){
            str = str.substring(1);
            visited[row][col] = true;
        // System.out.println(row+" "+col);
        for(int i = 0; i < temp.length;i++){
            int r = temp[i][0]+row;
            int c = temp[i][1]+col;
            // System.out.println(r+" "+c);
           
            if(helper(Graph,str,r,c,visited))return true;
            // System.exit(0);
        }
         
        visited[row][col] = false;
    }
        return false;
    }
	
	private static int solve(String[] Graph , int N, int M)
	{
		// Write your code here.
        boolean visited[][] = new boolean [N][M];
        for(int i = 0; i < N; i++){
            for(int j = 0; j < M; j++){
                if(Graph[i].charAt(j) == 'C'){
                    if(helper(Graph,"CODINGNINJA",i,j,visited))return 1;
                }
            }
        }
        return 0;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int M = input.nextInt();
		String Graph[] = new String[N];
		for(int i = 0; i < N; i++){
			Graph[i] = input.next();
		}
		// System.out.println(Graph[0].charAt(2));
		System.out.println(solve(Graph, N, M));
	}
}