import java.util.*;
class TrieNode{
	char data;
	boolean isTerminating;
	int count;
	TrieNode children[];
	public TrieNode(char data){
		this.data = data;
		count = 0;
		isTerminating = false;
		children = new TrieNode[26];
	}
}

public class Trie{


	private static void addWord(TrieNode root, String word){

		if(word.length() == 0){
			root.isTerminating = true;
			return ;
		}
		int childIndex = word.charAt(0)-65;
		TrieNode child = root.children[childIndex];
		if(child == null){
			child = new TrieNode(word.charAt(0));
			root.children[childIndex] = child;
			root.count = root.count+1;
		}
		addWord(child, word.substring(1));
	}

	private static void printAllWord(TrieNode root, String ans){

		if(root.isTerminating){
			System.out.println(ans);
		}
		for(int i = 0; i < 26; i++){
			if(root.children[i] != null){
				printAllWord(root.children[i], ans+root.children[i].data);
			}
		}
	}
	private static boolean search(TrieNode root, String word){

		if(root.isTerminating && word.length() == 0)	return true;
		if(word.length()==0)	return false;
		int childIndex = word.charAt(0)-65;
		TrieNode child = root.children[childIndex];
		if(child != null){

			if(search(child, word.substring(1)))return true;
		}
		return false;
	}

	private static TrieNode deleteWord(TrieNode root, String word){

		if(root.isTerminating && word.length() == 0){
			if(root.count == 0){
				return null;
			}else{
				root.isTerminating = false;
				return root;
			}
		}
		if(word.length() == 0)return root;
		int childIndex = word.charAt(0)-65;
		TrieNode child = root.children[childIndex];
		if(child != null){
			TrieNode res = deleteWord(child, word.substring(1));
			if(res == null){
				root.count = root.count-1;
				root.children[childIndex] = null;
				if(root.count == 0 && root.isTerminating==false){
					return null;
				}
			}
		}
		return root;

	}
		public static void main(String[] args){
			TrieNode root = new TrieNode('\0');
			Scanner input = new Scanner(System.in);
			while(true){
				String word = input.next();
				if(word.equals("-1"))break;
				addWord(root, word);
			}
			printAllWord(root,"");
			System.out.println();
			deleteWord(root, "ROHAN");
			printAllWord(root,"");
			System.out.println();
			deleteWord(root,"BITS");
			printAllWord(root, "");
			System.out.println();
			deleteWord(root, "NODE");
			printAllWord(root, "");
			System.out.println();
			deleteWord(root, "ROHIT");
			printAllWord(root, "");
		}

}