import java.util.Scanner;
import java.util.Vector;
class Sequence{
	
	private static void Sequences(Vector<Integer> al, int n){

		if(n < 2)
			return ;
		if(al.isEmpty()){

			if( 2 <= n){
				al.add(2);
				System.out.println(2);
			}
			if( 5 <= n){
				al.add(5);
				System.out.println(5);
			}
		}
		int si = al.size();
		for(int i = 0; i < si; i++){

			int num = al.get(i);
			String s = Integer.toString(num);
			int g = Integer.parseInt(s + Integer.toString(2));
			if( g <= n){
				al.add(g);
				System.out.println(g);
			}
			else
				return ;
			g = Integer.parseInt(s + Integer.toString(5));
			if( g <= n)
			{
				al.add(g);
				System.out.println(g);
			}
			else
				return ;
		}
		// System.out.println(al);
		for(int j = 0; j < si;j++)
			al.remove(0);
		Sequences(al, n);
	}
	public static void printSequence(int range){
		
		Vector<Integer> al = new Vector<Integer>();
		Sequences(al, range);
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		printSequence(n);
	}
}