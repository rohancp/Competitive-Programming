import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Kcon{

	private static long Kadane(int arr[], int size){

		long current_max = 0;
		long best_max = 0;
		for(int i = 0; i < size; i++)
		{
			current_max += arr[i];
			if(current_max > best_max)
				best_max = current_max;
			if(current_max < 0)
				current_max = 0;
		}
		return best_max;

	}


	private static long LargestSum(int arr[], int k, int size){

		long kadane_sum = Kadane(arr, size);

		if(k == 1)
			return kadane_sum;
		long current_preffix=0,curernt_suffix=0,best_preffix=0,best_suffix=0;

		for(int i = 0; i < size; i++){

			current_preffix += arr[i];
			best_preffix = Math.max(best_preffix, current_preffix);
		}
		long total_sum = current_preffix;
		for(int i = size-1; i >= 0; i--){

			curernt_suffix +=arr[i];
			best_suffix = Math.max(best_suffix, curernt_suffix);

		}
		if(total_sum <= 0)

			return (best_suffix+best_preffix);
		return (best_preffix+best_suffix+(total_sum*(k-2)));


	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			int arr[] = new int[2];
			String s[] = br.readLine().trim().split("\\s+");
			int i = 0;
			for(String a : s)
				arr[i++] = Integer.parseInt(a);
			int n,k;
			n = arr[0];
			k = arr[1];
			int arr2[] = new int[n];
			String s1[] = br.readLine().trim().split("\\s+");
			i = 0;
			for(String a : s1)
				arr2[i++] = Integer.parseInt(a);
			long result = LargestSum(arr2, k, n);
			System.out.println(result);
		}
	}
}