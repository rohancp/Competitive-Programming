import java.util.Scanner;
import java.util.ArrayList;
class ReturnParenthesis{


	private static void Find2(ArrayList<String> al, int n, String ans, int o, int c){

		if(n == c){

			al.add(ans);
			return ;
		}

		if( o < n){

			Find2(al, n, ans+"(", o+1, c);
		}
		if( o > c)
		Find2(al, n, ans+")", o, c+1);


	}

	private static String [] FindParenthesis(int n){

		ArrayList<String> al = new ArrayList<String>();
		Find2(al, n, "", 0, 0);
		String s[] = new String[al.size()];
		for(int i = 0; i < al.size(); i++)
			s[i] = al.get(i);
		return s;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		String s[] = FindParenthesis(n);
		for(int i = 0; i < s.length; i++)
			System.out.println(s[i]);
	}
}