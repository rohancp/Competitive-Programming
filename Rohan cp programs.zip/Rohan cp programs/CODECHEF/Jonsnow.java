import java.util.Scanner;
import java.util.Arrays;
class Jonsnow{

	private static void max_min_Strength(int arr[], int n, int k, int x){

		int dp1[] = new int [1024];
		int dp2[] = new int[1024];
		int prev = 0;
		for(int i = 0; i <n ; i++)
			dp1[arr[i]] += 1;
		while(k-- > 0){

			for(int j = 0; j < 1024; j++){

				if(dp1[j] != 0){

					if(prev %2 == 0){

						int v = dp1[j]/2;
						dp2[j] += v;
						dp2[j ^ x] += dp1[j] - v;
						prev += dp1[j];
					}else{

						int v = dp1[j]/2;
						dp2[j] += dp1[j] - v;
						if(v != 0){

							dp2[j ^ x] += v;
						}
						prev += dp1[j];
					}
				}
			}
			dp1 = dp2.clone();
			Arrays.fill(dp2, 0);
			prev = 0;
		}
		int min = 0,max = 0;
		for(int i = 0; i < 1024; i++){

			if(dp1[i] != 0){

				min = i;
				break;
			}
		}
		for(int i = 1023; i>=0; i--){

			if(dp1[i] != 0){

				max = i;
				break;
			}
		}

		System.out.println(max+" "+min);
	}

	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int k = input.nextInt();
		int x = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		max_min_Strength(arr, n, k, x);
	}
}