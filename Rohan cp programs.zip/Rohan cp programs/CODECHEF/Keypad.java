import java.util.Scanner;
import java.util.HashMap;
class Keypad{
	private static void KeypadKeys(int n, String output, HashMap<Integer, String> map){
		if(n == 0){
			System.out.println(output);
			return ;
		}
		int m = n %10;
		String s = map.get(m);
		for(int i = 0; i < s.length(); i++)
		{
			KeypadKeys((n/10), (s.substring(i,i+1) + output), map);
		}
	}

	public static void main(String []a){
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(2,"abc");
		map.put(3,"def");
		map.put(4,"ghi");
		map.put(5,"jkl");
		map.put(6,"mno");
		map.put(7,"pqrs");
		map.put(8,"tuv");
		map.put(9,"wxyz");
		KeypadKeys(N, "", map);

	}
}