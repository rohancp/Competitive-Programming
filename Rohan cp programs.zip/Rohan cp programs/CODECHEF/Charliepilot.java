import java.util.Scanner;
class Charliepilot{

	private static int make_Pilotcrew(int n, int capt[], int asst[], int c, int a, int dp[][]){

        
		if( n == 1)
			return asst[n];
		if(dp[n][c] != 0)
			return dp[n][c];
		if(c == a)
			dp[n][c] = capt[n] + make_Pilotcrew(n-1, capt, asst, c+1, a, dp);
		
		else if(c == (capt.length-1)/2)
			dp[n][c] = asst[n] + make_Pilotcrew(n-1, capt, asst, c, a+1, dp);

		else
			dp[n][c] = Math.min(capt[n] + make_Pilotcrew(n-1, capt, asst, c+1, a, dp), asst[n] + make_Pilotcrew(n-1, capt, asst, c, a+1, dp));
			return dp[n][c];
	}


	public static void main(String [] ar){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int capt[] = new int[n+1];
		int asst[] = new int[n+1];
		for(int i = 1; i <= n; i++){

			capt[i] = input.nextInt();
			asst[i] = input.nextInt();
		}		
		int dp[][] = new int[n+1][(n/2)+1];
		int ans = capt[n] + make_Pilotcrew(n-1, capt, asst, 1, 0, dp);
		System.out.println(ans);
	}
}