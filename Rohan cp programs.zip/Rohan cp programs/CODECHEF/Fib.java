import java.util.Scanner;
class Fib{

	private static int Fibanooci(int n){

		if(n == 0 || n == 1)
			return 1;
		return Fibanooci(n-1)+Fibanooci(n-2);
	}

	private static int Fibanooci2(int n, int arr[]){

		if(n == 0 || n == 1)
		{
			arr[n] = 1;
			return 1;
		}
		if(arr[n] > 0)
			return arr[n];
		int output = Fibanooci2(n-1, arr) + Fibanooci2(n-2, arr);
		arr[n] = output;
		return output;
	}

	private static int Fibanooci3(int n){

		int arr[] = new int[n+1];
		arr[0] = 0;
		arr[1] = 1;
		for(int i = 2; i <= n; i++){
			arr[i] = arr[i-1] + arr[i-2];
		}
		return arr[n];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n+1];
		// System.out.println(Fibanooci2(n, arr));
		// System.out.println(Fibanooci(n));
		System.out.println(Fibanooci3(n));
	}
}