import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Roycoin{


	private static void Boxes(int n, int day[][], int qry[]){

		int s[] = new int[n+1];
		int e[] = new int[n+1];
		int m = day.length;
		for(int i = 0; i < m; i++){

			int st = day[i][0];
			int en = day[i][1];
			s[st] += 1;
			e[en] += 1;

		}

		int dp[] = new int[n+1];
        int count[] = new int [n+1];
		dp[1] = s[1];
        count[dp[1]] += 1;
		for(int i = 2; i <= n; i++){

			dp[i] = s[i] + dp[i-1] - e[i-1];
            count[dp[i]] += 1;
 		}

		for(int i = n-1; i > 0; i--){

			count[i] += count[i+1];
		}

		for(int i = 0; i < qry.length ; i++){

			System.out.println(count[qry[i]]);
		}


	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		
		int n = Integer.parseInt(br.readLine());
		int m = Integer.parseInt(br.readLine());

		int day[][] = new int[m][2];
		for(int i = 0; i < m; i++){

			String s = br.readLine();
			String ss[] = s.split(" ");
			day[i][0] = Integer.parseInt(ss[0]);
			day[i][1] = Integer.parseInt(ss[1]);
		}
		int Q = Integer.parseInt(br.readLine());
		int qry[] = new int[Q];
		for(int i = 0; i < Q; i++)
			qry[i] = Integer.parseInt(br.readLine());

		Boxes(n, day, qry);
	}
}