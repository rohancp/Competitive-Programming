import java.util.Scanner;
class Flipbit{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int i = input.nextInt();
		System.out.println(N^(1<<i));

	}
}