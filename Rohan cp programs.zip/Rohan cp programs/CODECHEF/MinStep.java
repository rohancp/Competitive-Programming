import java.util.Scanner;
class MinStep{

	private static int Minimum_step(int n, int arr[]){

		if( n == 1 )
			return 0;
		if(arr[n] != 0)
			return arr[n];
		int ans = Minimum_step(n-1, arr);
		if(n % 3 == 0){

			ans = Math.min(ans, Minimum_step(n/3, arr));
		}

		if( n % 2 == 0)
		{
			ans = Math.min(ans, Minimum_step(n/2, arr));
		}
		arr[n] = 1+ans;
		return arr[n];
	}

	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		//we apply dp..
		int arr[] = new int[n+1];
		int result = Minimum_step(n, arr);
		System.out.println(result);
	}
}