tc=int(input())
while tc>0:
    tc-=1
    a,b,c=map(int,input().split())
    if(a>b and a>c):
        if(b>c):
            print(b)
        else:
            print(c)
    elif (b>c):
        if a>c:
            print(a)
        else:
            print(c)
    else:
        if(b>a):
            print(b)
        else:
            print(a)
            
