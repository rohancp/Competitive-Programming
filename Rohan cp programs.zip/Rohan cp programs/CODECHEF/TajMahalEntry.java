import java.util.Scanner;
class TajMahalEntry{

	private static int Find(int arr[], int i, int N){

		int s = 0;
		int l = 1000000000;
		int ans = 0;
		while(s <= l){

			int mid = (s+l)/2;
			if(i+(mid*N) >= arr[i]){

				ans = mid;
				l = mid - 1;
			}
			else
				s = mid+1;
		}

		return(i + (ans*N));
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr[] = new int[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextInt();
		for(int i = 0 ;i < N; i++)
			arr[i] = Find(arr, i, N-1);

		int min = arr[0];
		int index = 0;
		for(int i = 1; i < N; i++)
		{
			if(min > arr[i])
			{
				min = arr[i];
				index = i;
			}
		}
		System.out.println(index+1);

	}

}