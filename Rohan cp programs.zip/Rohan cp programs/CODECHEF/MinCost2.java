import java.util.Scanner;
class MinCost2{

	private static int Find_Min_Cost(int arr[][], int r, int c, int i, int j, int S, int dp[][]){

		if( i == r || j == c)
			return -1;
		if( i == r -1 && j == c-1){

			S += arr[i][j];
			return S;
		}
		if(dp[i][j] != 0){

			return S + dp[i][j];
		}

		int max1, max2, max3;
		max1 = max2 = max3 = Integer.MAX_VALUE;
		int v = Find_Min_Cost(arr, r, c, i, j+1, S+arr[i][j], dp);
		if(v != -1)
			max1 = v;

		v = Find_Min_Cost(arr, r, c, i+1, j+1, S+arr[i][j], dp);
		if(v != -1)
			max2 = v;

		v = Find_Min_Cost(arr, r, c, i+1, j, S+arr[i][j], dp);

		if(v != -1)
			max3 = v;

		int min = Math.min(max3, Math.min(max1, max2));
		dp[i][j] = min - S;
		return min;

	}

	private static int Find_Min_Cost2(int arr[][], int r, int c){

		int dp[][] = new int[r][c];

		dp[r-1][c-1] = arr[r-1][c-1];
		for(int i = r-2; i >= 0; i--){

			dp[i][c-1] = dp[i+1][c-1] + arr[i][c-1];
		}
		for(int i = c-2; i >= 0; i--){

			dp[r-1][i] = dp[r-1][i + 1] + arr[r-1][i];
		}

		for(int i = r-2; i >= 0; i--){

			for(int j = c-2; j >= 0; j--){

				dp[i][j] = arr[i][j] + Math.min(dp[i+1][j], Math.min(dp[i+1][j+1], dp[i][j+1]));
			}
		}

		return dp[0][0];
	}

	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		int m = input.nextInt();
		int n = input.nextInt();
		int arr[][] = new int[m][n];
		for(int i = 0; i < m; i++){

			for(int j = 0; j < n; j++)
				arr[i][j] = input.nextInt();
		}

		int dp[][] = new int[m][n];
		int result = Find_Min_Cost(arr, m, n, 0, 0, 0, dp);
		System.out.println(result);
		System.out.println(Find_Min_Cost2(arr, m, n));

	}
}