import java.util.*;
import java.io.*;
import java.lang.*;
class Isolationcentre{

	private static int arr[];
	private static void precompute(String str){

		arr = new int[26];
		for(int i = 0; i < str.length(); i++){
			int index = str.charAt(i) - 'a';
			arr[index]++;
		}
	}
	private static int getpendingQ(int C){

		int pendingQ = 0;
		for(int i = 0; i < 26; i++){

			if(C < arr[i]){
				pendingQ += arr[i]-C;
			}
		}
		return pendingQ;

	}
	public static void main(String[] args)throws IOException{

try{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		StringBuilder sb = new StringBuilder();
		while(tc-- > 0){

			String s[] = br.readLine().split(" ");
			int Q = Integer.parseInt(s[1]);
			String str = br.readLine();
			precompute(str);
			while(Q-- > 0){
				int c = Integer.parseInt(br.readLine());
				sb.append(getpendingQ(c)+"\n");

			}
		}
		System.out.print(sb.toString());
	}catch(Exception e){
		return ;
	}
	}
}