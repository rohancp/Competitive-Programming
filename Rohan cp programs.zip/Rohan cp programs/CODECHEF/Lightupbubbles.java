import java.util.Scanner;
class Main{

	public static long Find_Min_Cost(int arr[],int n, int x, int y){

		long g = 0;
		for(int i = 0; i < n-1; i++){

			if(arr[i] == 1 && arr[i+1] == 0)
				g++;
		}

		if(arr[0] == 0)
			g++;
		if(g == 0)
			return 0;
		return ((g-1)*Math.min(x,y))+y;

	}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int x = input.nextInt();
		int y = input.nextInt();
		String s = input.next();
		String ss[] = s.split("");
		int arr[] = new int[n];
		int i = 0;
		for(String a : ss)
			arr[i++] = Integer.parseInt(a);
		long result = Find_Min_Cost(arr, n, x, y);
		System.out.println(result);
	}
}