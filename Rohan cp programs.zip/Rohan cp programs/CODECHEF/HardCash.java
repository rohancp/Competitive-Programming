import java.util.*;
import java.io.*;
import java.lang.*;
class HardCash{


	public static long helper(long cash[], int K){

		int N = cash.length;
		long leftOver[] = new long[N];
		long rightOver[] = new long[N];
		for(int i = 0; i < N; i++){
			leftOver[i] = cash[i]%K;
			if((cash[i]%K) != 0){
				rightOver[i] = K-(cash[i]%K);
			}
			else{
				rightOver[i] = 0;
			}
		}
		for(int i = 1; i < N; i++){
			leftOver[i] +=leftOver[i-1];
		}
		for(int i = N-2; i >=0; i--){
			rightOver[i] += rightOver[i+1];
		}
		long smallans = leftOver[N-1];
		for(int i = N-2; i >=0; i--){
			long left = leftOver[i];
			long right = rightOver[i+1];
			if(left >= right){
				long min = left-right;
				smallans = Math.min(min, smallans);
			}
		}
		return smallans;
	}

	public static void main(String[] args)throws IOException{

		try{

			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int N = Integer.parseInt(s[0]);
				int K = Integer.parseInt(s[1]);
				String input[] = br.readLine().split(" ");
				long cash[] = new long[N];
				for(int i = 0; i < N; i++){
					cash[i] = Long.parseLong(input[i]);
				}
				long result = helper(cash,K);
				sb.append(result);
				if(tc != 0)
					sb.append("\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}