import java.util.Scanner;
class Ratinamaze{

	private static void printSolution(int solmat[][], int n){

		for(int i = 0; i < n; i++){

			for(int j = 0; j < n; j++)
				System.out.print(solmat[i][j]+" ");
		}
		System.out.println();

	}

	private static void findway(int path[][], int solmat[][], int r, int c, int n){

		if(r == n-1 && c == n-1)
		{
			solmat[r][c] = 1;
			printSolution(solmat, n);
			solmat[r][c] = 0;
			return ;
		}
		//left..
		if((c-1 >= 0) &&(path[r][c-1] == 1 && solmat[r][c-1] != 1)){
			solmat[r][c] = 1;
			findway(path, solmat, r, c-1, n);
		}
		//right..
		if((c+1 < n) && (path[r][c+1] == 1 && solmat[r][c+1] != 1)){
			solmat[r][c] = 1;
			findway(path, solmat, r, c+1, n);
		}
		//upper..
		if((r-1 >= 0) &&(path[r-1][c] == 1 && solmat[r-1][c] != 1)){

			solmat[r][c] = 1;
			findway(path, solmat, r-1, c, n);
		}
		//down..
		if((r+1 <n) &&(path[r+1][c] ==1 && solmat[r+1][c] != 1))
		{
			solmat[r][c] = 1;
			findway(path, solmat, r+1, c, n);
		}
		solmat[r][c] = 0;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int path[][] = new int[n][n];
		int solmat[][] = new int[n][n];
		for(int i = 0; i < n; i++){

			for(int j = 0; j < n; j++){
				path[i][j] = input.nextInt();
				solmat[i][j] = 0;
			}
		}

		findway(path, solmat, 0, 0, n);

	}

}