tc=int(input())
while tc>0:
    tc-=1
    n=input()
    print(n.count("4"))
    
