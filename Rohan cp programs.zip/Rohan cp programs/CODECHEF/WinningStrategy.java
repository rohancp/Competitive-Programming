import java.util.Scanner;
class WinningStrategy{

	private static int Find_Prop_Index(int arr[], int search, int l, int h){

		int mid = (l+h)/2;
		while( l <= h){

			mid = (l+h)/2;
			if(arr[mid] == search){
				break;
			}
			else if(search > arr[mid]){
				l = mid + 1;
			}
			else
				h = mid - 1;
		}
		return mid;
	}

	private static void TeamRohan(int player[], int n)
	{

		int arr[] = new int [n];
		for(int i = 0; i < n; i++)
			arr[i] = i+1;
		int max_swap = 0;
		boolean b = true;
		for(int i = 0; i < n; i++){

				if(arr[i] == player[i])
					continue;
			int index = Find_Prop_Index(arr, player[i], i, n-1);
			if(Math.abs(i - index) > 2){
				b = false;
				break;
			}
			max_swap += Math.abs(i - index);
			int j = index;
			for(; j > i; j--)
				arr[j] = arr[j-1];
			arr[j] = player[i];
			
		}

		if(b){

			System.out.println("YES");
			System.out.println(max_swap);
		}
		else
			System.out.println("NO");
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		TeamRohan(arr, n);

	}
}