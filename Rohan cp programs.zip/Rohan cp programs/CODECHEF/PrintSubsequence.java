import java.util.Scanner;
import java.util.Vector;
class PrintSubsequence{

	private static void Print_subsequences(String s, Vector<String> vect){

			if(s.isEmpty())
			{
				vect.add("");
				return ;
			}
			String small = s.substring(0,1);
			Print_subsequences(s.substring(1), vect);
			int size = vect.size();
			for(int i = 0; i < size; i++)
				vect.add(small+vect.get(i) );

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		String s = input.next();
		Vector<String> vect = new Vector<String>();
		Print_subsequences(s, vect);
		for(String a : vect)
			System.out.println(a);
	}
}