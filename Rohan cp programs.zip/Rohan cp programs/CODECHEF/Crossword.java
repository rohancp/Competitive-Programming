import java.util.Scanner;
import java.util.Arrays;
class Crossword{

	private static void Print_Solution(char board[][]){

		for(int i = 0; i < 10; i++)
		{
			for(int j = 0; j< 10; j++)
				System.out.print(board[i][j]+" ");
			System.out.println();
		}
	}

		private static boolean isValidVertical(char board[][], char word[], int index, int li, int r, int c){


			int count = 1;
			// System.out.println("Vertical:");
			// System.out.println(r+" "+c);
			for( r = r+1; r < 10; r++){

				if(board[r][c] == '+')
					break;
				if(board[r][c] == '-' || board[r][c] == word[index+count])
					count++;
			}

			// System.out.println(count);
			if((li-index) == count)
				return true;
			return false;

		}

		private static boolean isValidHorizontal(char board[][], char word[], int index, int li, int r, int c){

			int count = 1;
			// System.out.println("Horizontal:");
			// System.out.println(r+" "+c);
			for( c = c+1; c < 10; c++){

				if(board[r][c] == '+')
					break;
				if(board[r][c] == '-' || board[r][c] == word[index+count])
					count++;
			}
			// System.out.println(count);
			if((li-index) == count)
				return true;
			return false;
		}

		private static void  setVertical(char board[][], char word[], int index, int li, int r, int c, boolean helper[]){

		int i = 0;
		for(; index < li; index++){

				if(board[r][c] != '-')
					helper[i] = true;
				else
					board[r][c] = word[index];
				i++;r++;
		}			

		}

		private static void setHorizontal(char board[][], char word[], int index, int li, int r, int c, boolean helper[]){

			int i = 0;
			for(; index < li; index++){

				if(board[r][c] != '-'){

					helper[i] = true;
				}
				else
					board[r][c] = word[index];
				i++;c++;
			}
		}

		private static void ResetVertical(char board[][], char word[], int index, int li, int r, int c, boolean helper[]){

			int i = 0;
			for(; index < li; index++){

				if(helper[i] != true){
					board[r][c] = '-';
				}
				else
					helper[i] = false;
				r++;i++;
			}
		}

		private static void ResetHorizontal(char board[][], char word[], int index, int li, int r, int c, boolean helper[]){

			int i = 0;
			for(; index < li; index++){

				if(helper[i] != true)
					board[r][c] = '-';
				else
					helper[i] = false;
				c++;i++;
			}
		}

	private static boolean Entry_Word(char board[][], char word[], int index){
		// System.out.println("O");

		if(word.length < index)
		{
			Print_Solution(board);
			return true;
		}

		int li = index;
		for( ; li < word.length; li++){

			if(word[li] == ';')
				break;
		}

		for(int r = 0; r < 10; r++){


			for(int c = 0; c < 10; c++){
				// System.out.print(board[r][c]+"");

				if(board[r][c] == '-' || board[r][c] == word[index]){
					// System.out.print(board[r][c]+"");

					if(isValidVertical(board, word, index, li, r, c)){

						// System.out.println("Rohanv");
						boolean helper[] = new boolean [li-index];
						Arrays.fill(helper, false);
						setVertical(board, word, index, li, r, c, helper);
						if(Entry_Word(board, word, li+1))
							return true;
						ResetVertical(board, word, index, li, r, c, helper);
					}
					if(isValidHorizontal(board, word, index, li, r, c)){
						
						boolean helper[] = new boolean [li-index];
						Arrays.fill(helper, false);
						setHorizontal(board, word, index, li, r, c, helper);
						if(Entry_Word(board, word, li+1))
							return true;
						ResetHorizontal(board, word, index, li, r, c, helper);
					}
				}
			}
		}
		return false;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		char board[][] = new char[10][10];
		for(int i = 0; i < 10; i++){

			String s = input.next();
			for(int j = 0; j < 10; j++)
				board[i][j] = s.charAt(j);
		}
		String s = input.next();
		char word[] = s.toCharArray();
		Entry_Word(board, word, 0);

	}
}
/*
TEST CASES 1..

+-++++++++
+-++-+++++
+-------++
+-++-+++++
+-++-+++++
+-++-+++++
++++-+++++
++++-+++++
++++++++++
----------
CALIFORNIA;NIGERIA;CANADA;TELAVIV

TEST CASES 2..
*/