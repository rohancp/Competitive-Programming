import java.util.*;
import java.io.*;
import java.lang.*;
import java.util.concurrent.ConcurrentHashMap;
class Theatre{

	private static int watchmovies = 0;
	private static long getMaximumProfit(ConcurrentHashMap<String, ConcurrentHashMap<Integer, Integer>> showmap){

		// System.out.println("hii");
		int ticketPrice[] = {100,75,50,25};
		long sum = 0;
		int i = 0;
		while(!showmap.isEmpty()){
			String m = null;
			int stime = 0;
			int c = 0;
			for(Map.Entry<String, ConcurrentHashMap<Integer, Integer>> entry_1: showmap.entrySet()){

				ConcurrentHashMap<Integer, Integer> map = entry_1.getValue();
				String entry_1Key = entry_1.getKey();
				for(Map.Entry<Integer, Integer> entry_2 : map.entrySet()){

					int entry_2Key = entry_2.getKey();
					int entry_2Val = entry_2.getValue();
					if(c < entry_2Val){
						c = entry_2Val;
						stime = entry_2Key;
						m = entry_1Key;
					}
				}
			}
			// System.out.println(m+" "+stime+" "+c);
			sum += (c*ticketPrice[i++]);
			watchmovies++;
			Set<String> set = showmap.keySet();
			for(String k : set){
				ConcurrentHashMap<Integer, Integer> map = showmap.get(k);
				for(Map.Entry<Integer, Integer> entry : map.entrySet()){

					if(map.containsKey(stime)){
						if(map.size() == 1){
							showmap.remove(k);break;
						}
						else{
							map.remove(stime);break;
						}
					}
				}
			}
			/* for(Map.Entry<String, HashMap<Integer, Integer>> entry_1 : showmap.entrySet()){
				HashMap<Integer, Integer> map = entry_1.getValue();
				for(Map.Entry<Integer, Integer> entry_2 : map.entrySet()){
					if(map.containsKey(stime)){
						map.remove(stime);
						if(map.isEmpty()){
							// System.out.println(map);
							// System.out.println(entry_1.getKey());
							// printMap(showmap);
							showmap.remove(entry_1.getKey());
							// printMap(showmap);
						}
						break;
					}
				}
			}*/

			if(showmap.containsKey(m)){
			showmap.remove(m);}
			// printMap(showmap);
		}
		return sum;
	}
		//this method add all values....
	// private static long getTotalProfit(Vector<Long> vec){
	// 	long sum = 0;
	// 	for(long ele : vec){
	// 		sum += ele;
	// 	}
	// 	return sum;
	// }

	private static void printMap(ConcurrentHashMap<String, ConcurrentHashMap<Integer, Integer>> showmap){

		for(Map.Entry<String, ConcurrentHashMap<Integer, Integer>> entry : showmap.entrySet()){

			String key = entry.getKey();
			key += ": ";
			ConcurrentHashMap<Integer, Integer> map = entry.getValue();
			for(Map.Entry<Integer, Integer> entry2 : map.entrySet()){
				key += entry2.getKey()+"->"+entry2.getValue()+",";
			}
			System.out.println(key);
		}
	}

	public static void main(String [] args)throws IOException{

		try{
			StringBuilder sb = new StringBuilder();
			// Vector<Long> totalProfit = new Vector<Long>();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			long totalProfit = 0;
			while(tc-- > 0){
				// totalProfit = 0;
				watchmovies = 0;
				int sizeOfMap = 0;
				ConcurrentHashMap<String, ConcurrentHashMap<Integer,Integer>> showmap = new ConcurrentHashMap<>();
				int N = Integer.parseInt(br.readLine());
				while(N-- > 0){
					String input[] = br.readLine().split(" ");
					String movie = input[0];
					int showtime = Integer.parseInt(input[1]);
					// System.out.println(movie+" "+showtime);
					if(showmap.containsKey(movie)){
						ConcurrentHashMap<Integer, Integer> map = showmap.get(movie);
						if(map.containsKey(showtime)){
							map.put(showtime,map.get(showtime)+1);
						}
						else{
							map.put(showtime,1);
						}
						showmap.put(movie,map);

					}else{
						ConcurrentHashMap<Integer, Integer> map = new ConcurrentHashMap<>();
						map.put(showtime,1);
						showmap.put(movie,map);
					}

				}
				 // printMap(showmap);
				// sizeOfMap = showmap.size();
				// System.out.println(sizeOfMap);
				long result = getMaximumProfit(showmap);
				// System.out.println(result);
				if(watchmovies<4){
					int g = 4 - watchmovies;
					g = g*100;
					result = result - g;
				}
				sb.append(result+"\n");
				totalProfit += result;
				// totalProfit.add(result);
				// printMap(showmap);
			}
			// long ans = getTotalProfit(totalProfit);
			sb.append(totalProfit+"\n");
			System.out.print(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}