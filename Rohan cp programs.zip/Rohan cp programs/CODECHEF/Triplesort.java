import java.util.*;
import java.io.*;
import java.lang.*;
class Triplesort{


	private static void printarr(int per[], int pos[], int min, int mid, int max, int N){

		for(int i = 1; i <= N; i++){
			System.out.print(per[i]+" ");
		}
		System.out.println();
		for(int i = 1; i <= N; i++){
			System.out.print(pos[i]+" ");
		}
		System.out.println();
		System.out.print(min+" "+mid+" "+max);
		System.out.println();
	}

	private static StringBuilder sortthePermutation(int per[], int pos[], int count, LinkedList<Integer>list, int N, int K){

		// String numOperations = "";
		StringBuilder numberofOp = new StringBuilder();
		int orgK = K;

		while((K > 0) && (count >= 3)){

			int i = list.get(0);
			if(per[i] == i){
				list.pollFirst();
				continue;
			}
			int a,b,c;
			a = pos[i];
			i = a;
			b = pos[i];
			i = b;
			if(i == list.get(0)){
				for(int j = 0; j < list.size(); j++){
					if((a != list.get(j)) && (b != list.get(j))){
						i = list.get(j);
						break;
					}
				}
			}
			c = pos[i];
			int min_index, mid_index, max_index;
			min_index = Math.min(a, Math.min(b,c));
			max_index = Math.max(a, Math.max(b, c));
			if(min_index < a  && a < max_index)
				mid_index = a;
			else if(min_index < b && b < max_index)
				mid_index = b;
			else
				mid_index = c;

			int ele1, ele2, ele3;
			ele1 = per[min_index];
			ele2 = per[mid_index];
			ele3 = per[max_index];
			per[min_index] = ele3;
			pos[ele3] = min_index;
			per[mid_index] = ele1;
			pos[ele1] = mid_index;
			per[max_index] = ele2;
			pos[ele2] = max_index;
			if(pos[ele3] == ele3)
				count--;
			if(pos[ele1] == ele1)
				count--;
			if(pos[ele2] == ele2)
				count--;
			numberofOp.append(min_index).append(" ").append(mid_index).append(" ").append(max_index).append("\n");
			// numOperations = numOperations+min_index+" "+mid_index+" "+max_index+"\n";
			K--;
			// printarr(per, pos,min_index, mid_index, max_index, N);
		}
		// if sort the permutation when count is Zero otherwise -1
		if(count == 0){
			int M = orgK - K;
			StringBuilder sb = new StringBuilder();
			sb.append(M).append("\n").append(numberofOp);
			
			return sb;
		}
		StringBuilder ss = new StringBuilder();
		ss.append("-1").append("\n");
		return ss;
	}
	public static void main(String[] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				int count = 0;
				LinkedList<Integer> list = new LinkedList<Integer>();
				String s[] = br.readLine().split(" ");
				int N = Integer.parseInt(s[0]);
				int K = Integer.parseInt(s[1]);
				s = br.readLine().split(" ");
				int per[] = new int[N+1];
				int pos[] = new int[N+1];
				for(int i = 1; i <= N; i++){
					int val = Integer.parseInt(s[i-1]);
					per[i] = val;
					pos[val] = i;
					if(per[i] != i){
						count++;
						list.add(i);
					}
				}
				// if its already sort..
				if(count == 0){
					sb.append("0").append("\n");
					continue;
				}
				if(count <=2){
					sb.append("-1").append("\n");
					continue;
				}
				StringBuilder result = sortthePermutation(per, pos, count, list, N, K);
				sb.append(result);				
			}
			System.out.print(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}