import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Largestnumber{

	private static String ans = "";

	public static void Swap(StringBuilder sb ,int i, int j)
	{

		char temp = sb.charAt(i);
		sb.setCharAt(i, sb.charAt(j));
		sb.setCharAt(j, temp);
		return ;
	}

	public static void Initialize(String s)
	{
		ans = s;

	}


	public static String getAnswer()
	{
		return ans;
	}	


	public static void FindMaxnum(StringBuilder sb, int K)
	{

		if(K == 0)
			return ;
		int N = sb.length();
		for(int i = 0; i < N-1; i++)
		{

			for(int j = i+1; j < N; j++)
			{

				if(sb.charAt(i) < sb.charAt(j))
				{

					Swap(sb, i, j);

					if(sb.toString().compareTo(ans) > 0)
						ans = sb.toString();
					FindMaxnum(sb, K - 1);

					//Now Backtrack....

					Swap(sb, i, j);
				}

			}
		}

	}


	public static void main(String[]args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			int testcases = Integer.parseInt(br.readLine());
			while(testcases-- > 0)
			{
				Largestnumber l = new Largestnumber();
				int K = Integer.parseInt(br.readLine());
				String S = br.readLine();
				StringBuilder sb = new StringBuilder(S);
				l.Initialize(S);
				l.FindMaxnum(sb, K);
				System.out.println(l.getAnswer());
				// return ;
			}

	}
}