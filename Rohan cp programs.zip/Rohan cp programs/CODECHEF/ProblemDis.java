import java.util.Scanner;
import java.util.Arrays;
class ProblemDis{

	private static int MinimumDifference(int arr[], int n, int k){
		
		Arrays.sort(arr);
		int min = arr[n-1] - arr[0];
		int sm,bg;
		sm = arr[0] + k;
		bg = arr[n-1] - k;
		if(sm > bg){

			int temp = sm;
			sm = bg;
			bg = temp;
		}
		for(int i = 1; i < n-1; i++){

			int sub = arr[i] - k;
			int add = arr[i] + k;
			if(sub >= sm || add <= bg)
				continue;
			if(bg - sub <= add - sm){

				sm = sub;
				continue;
			}
			bg = add;
		}

		return Math.min(min, bg - sm);
	}


	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int k = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++){

			arr[i] = input.nextInt();
		}
		int result = MinimumDifference(arr, n, k);
		System.out.println(result);
	}
}