import java.util.Scanner;
import java.util.Arrays;
class Graph{

	int edges[][];
	public Graph(int V){
		edges = new int[V][V];
	}

	public void add_Edge(int fv, int sv, int weight){
		edges[fv][sv] = weight;
		edges[sv][fv] = weight;
	}

	public int getminvertex(int distance[], boolean visited[], int V){

		int minvertex = -1;
		for(int i = 0; i < V; i++){

			if(!visited[i] && (minvertex == -1 || distance[minvertex] > distance[i]))
				minvertex = i;
		}
		return minvertex;
	}

	public void dijkastra(int V){

		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		int distance[] = new int[V];
		Arrays.fill(distance, Integer.MAX_VALUE);
		distance[0] = 0;
		for(int i = 0; i < V-1; i++){

			int minvertex = getminvertex(distance, visited, V);
			visited[minvertex] = true;
			for(int j = 0; j < V; j++){
				if(edges[minvertex][j] != 0 && !visited[j]){
					if(distance[j] > distance[minvertex]+ edges[minvertex][j]){
						distance[j] = distance[minvertex] + edges[minvertex][j];
					}
				}
			}
		}

		for(int i = 0; i < V; i++){

			System.out.println(i+" "+distance[i]);
		}
	}
}
class Dijkastra{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			int w = input.nextInt();
			g.add_Edge(fv, sv, w);
		}
		g.dijkastra(V);

	}
}