#include<stdio.h>
int main(){
	int bin[10000],Q,N;
	scanf("%d",&N);
	scanf("%d",&Q);
	printf("%d\n%d",N,Q);
	return 0;
}
