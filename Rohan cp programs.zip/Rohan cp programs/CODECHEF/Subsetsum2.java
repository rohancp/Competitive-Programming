import java.util.Scanner;
class Subsetsum2{

	static boolean subset_sum(int arr[], int n, int sum){

		boolean dp[][] = new boolean[n+1][sum+1];

		for(int i = 0; i <= sum; i++)
			dp[0][i] = false;
		for(int i = 0; i <= n; i++)
			dp[i][0] = true;
		for(int i = 1; i <= n ;i++){

			for(int s = 1 ; s <= sum; s++){

				dp[i][s] = dp[i-1][s];
				if(s >= arr[i-1])
					dp[i][s] = dp[i][s] || dp[i-1][s-arr[i-1]];
			}
		}
		return dp[n][sum];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int K = input.nextInt();
		boolean ans = subset_sum(arr, n, K);
		if(ans)
			System.out.println("Yes");
		else
			System.out.println("No");

	}
}