import java.util.Scanner;
class Oddevenbit{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		if((1&N) == 0)
			System.out.println("no is even!!..");
		else 
			System.out.println("no is odd!!..");
	}
}