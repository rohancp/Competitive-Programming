import java.util.Scanner;
class Vanyagcd{

	private static int GCD(int a, int b){

		if(a == 0)
			return b;
		return GCD(b % a, a);

	}
		private static int find_subsequences(int arr[], int n){

			int MOD = (int)Math.pow(10,9)+7;

				int dp[][] = new int[n][101];
				dp[0][arr[0]] = 1;
				for(int i = 1; i < n; i++){

					dp[i][arr[i]] = 1;

					for(int k = i-1; k >= 0; k--){


						if(arr[k] < arr[i]){

							for(int j = 1; j <= 100; j++){


								if(dp[k][j] != 0){

									int l = GCD(j, arr[i]);
									
									dp[i][l] = (dp[i][l] + dp[k][j])%MOD;
								}
							}
						}
					}
				}

				int sum = 0;
				for(int i = 0; i < n; i++){

					sum = (sum+ dp[i][1])%MOD;
				}

				return sum;
		}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = find_subsequences(arr, n);
		System.out.println(result);

	}
}