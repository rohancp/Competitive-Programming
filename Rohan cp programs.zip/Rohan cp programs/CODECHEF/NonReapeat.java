import java.util.Scanner;
import java.util.LinkedHashMap;

class NonReapeat{


	private static char First_non_reapeat_character(String s){

		LinkedHashMap<Character, Integer> freq = new LinkedHashMap<>();
		char ch[] = s.toCharArray();
		for(int i = 0; i < ch.length; i++){

			if(freq.containsKey(ch[i])){
				freq.put(ch[i], freq.get(ch[i])+1);
			}
			else
				freq.put(ch[i], 1);
		}
		int i;
		boolean b = false;
		for( i = 0; i < ch.length; i++){

			if(freq.get(ch[i]) == 1)
				{break;b = true;}
		}
		if(b)
		return ch[i];
	return ch[0];

	}
	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		String s = input.next();
		char result = First_non_reapeat_character(s);
		System.out.println(result);


	}

}