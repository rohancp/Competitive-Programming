import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Murder
{


	private static long Merging(int arr[], int s, int l, int mid){

		int i = s;
		int j = mid+1;
		int k = s;
		long prev_sum = 0, current_sum = 0;
		int arr2[] = new int[arr.length];
		while( i <= mid && j <= l){

			if(arr[i] < arr[j]){

				arr2[k++] = arr[i];
				current_sum = current_sum + (arr[i] *(l+1-j));
				i++;

			}
			else
			{
				arr2[k++] = arr[j];
				prev_sum += current_sum;
				current_sum = 0;
				j++;
				
			}

		}

		while( i <= mid)
			arr2[k++] = arr[i++];

		while( j <= l)
			arr2[k++] = arr[j++];

		for(; s <= l; s++)
			arr[s] = arr2[s];

		return (prev_sum + current_sum);

	}
	private static long MergeSort(int arr[], int s, int l){

		if(s < l)
		{

			int mid = (s+l)/2;
			long left = MergeSort(arr, s, mid);
			long right = MergeSort(arr, mid+1, l);
			long C = Merging(arr, s, l, mid);
			return (left+ right+ C);

		}
		return 0;
	}

		public static void main(String [] args)throws IOException{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				String s[] = br.readLine().trim().split("\\s+");
				int i = 0;
				int arr[] = new int[N];
				for(String a : s)
					arr[i++] = Integer.parseInt(a);
				long result = MergeSort(arr, 0, N-1);
				System.out.println(result);
			}

		}
}