import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
import java.util.TreeSet;
import java.util.Collections;

class Boggle{

	static TreeSet<String> al = new TreeSet<String>();


	public static void Find_Words(char boggle[][], boolean visited[][], int M, int N, int i, 
		int j, Vector<String> vec, String ans)
	{


		visited[i][j] = true;
		ans+=boggle[i][j];

		//check word is Exist in the dicitionary or not...

		// for(String ss : vec)
		// {
		// 	if(ans.equals(ss))
		// 		al.add(ans);
		// }
		if(vec.contains(ans))
			al.add(ans);

		for(int a = i-1;a<=i+1;a++)
		{
			for(int b = j-1;b<=j+1;b++)
			{
				if(a>=0 && b>=0 && a<M && b<N)
				{
					if(!visited[a][b])
						Find_Words(boggle, visited, M, N, a, b, vec, ans);
				}
			}
		}


		//Now Backtrack..

		ans = ans.substring(0,ans.length() - 1);

		visited[i][j] = false;

		 // return ;

	}

	public static void main(String[] args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int tc = Integer.parseInt(br.readLine());


		while(tc-->0)
		{
			int NU = Integer.parseInt(br.readLine());

			String line = br.readLine();
			String s[] = line.trim().split("\\s+");

			Vector<String> vec = new Vector<String>();
			for(int i = 0; i<NU; i++)
			{
				String a = s[i];
				vec.add(a);
			}
			// System.out.println(vec);

			String line1 = br.readLine();
			String s2[] = line1.trim().split("\\s+");

			int arr[] = new int[2];

			for(int i = 0;i<2;i++)
				arr[i] = Integer.parseInt(s2[i]);

			int M = arr[0];
			int N = arr[1];

			String line2 = br.readLine();
			String s3[] = line2.trim().split("\\s+");
			String str[] = new String[M*N];
			for(int i = 0;i<M*N;i++)
				str[i] = s3[i];

			char ch[][] = new char[M][N];
			int k = 0;

			for(int i = 0;i<M;i++)
			{
				for(int j = 0;j<N;j++)
				{
					ch[i][j] = str[k++].charAt(0);
				}
			}

			boolean visited[][] = new boolean[M][N];

			//Initialization...

			for(int i = 0;i<M;i++)
			{
				for(int j = 0;j<N;j++)
					visited[i][j] = false;
			}

			for(int i = 0;i<M;i++)
			{
				for(int j = 0;j<N;j++)
					Find_Words(ch, visited, M, N, i, j, vec, "");
			}
			

			if(al.size() == 0)
				System.out.print("-1");
			else
			{
				// Collections.sort(al);
				for(String j : al)
					System.out.print(j+" ");
				al.removeAll(al);
			}
			System.out.println();
		}
	}
}