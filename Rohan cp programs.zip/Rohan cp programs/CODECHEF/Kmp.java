import java.util.Scanner;
class Kmp{

	public static int[] find_lps(String pattern){
		int lps[] = new int[pattern.length()];
		int i = 1,j = 0;
		lps[0] = 0;
		while(i < pattern.length()){

			if(pattern.charAt(j) != pattern.charAt(i)){
				if(j == 0){
					lps[i] = 0;
					i++;
				}
				else
					j = lps[j-1];
			}
			else{
				lps[i] = j+1;
				i++;j++;
			}
		}
		return lps;
	}

	public static boolean isMatching(String text, String pattern){

		int lentext = text.length();
		int lenpattern = pattern.length();
		int i = 0, j = 0;
		int lps[] = find_lps(pattern);
		while(i < lentext && j < lenpattern){
			if(text.charAt(i) == pattern.charAt(j)){
				i++;j++;
			}
			else{
				if( j != 0){
					j = lps[j-1];
				}
				else{
					i++;
				}
			}
		}
		if(j == lenpattern)
			return true;
		return false;
	}
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		String text = input.next();
		String pattern = input.next();
		boolean ans = isMatching(text, pattern);
		System.out.println(ans);
	}
}