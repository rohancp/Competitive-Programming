import java.util.Scanner;
class Power{

		private static int CalculatePower(int x, int n){

			if(n == 0)
				return 1;
			if(n%2 == 0){

				int ans = CalculatePower(x,n/2);
				return (ans*ans);
			}
			int ans = CalculatePower(x,n/2);
			return (ans*ans*x);
		}


	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int X = input.nextInt();
		int N = input.nextInt();
		int result = CalculatePower(X,N);
		System.out.println(result);

	}
}