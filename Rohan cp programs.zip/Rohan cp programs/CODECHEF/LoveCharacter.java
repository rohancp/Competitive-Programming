import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;

class LoveCharacter{


		private static Map<Character,Integer> Find_Occurence(String s, int size){

			char ch[] = s.toCharArray();
			Map<Character, Integer> map = new HashMap<>();
			for(int i = 0; i < s.length(); i++){

				if(map.containsKey(ch[i])){
					map.put(ch[i], map.get(ch[i])+1);
				}
				else{
					map.put(ch[i], 1);
				}
			}
			return map;
		}

	public static void main(String []  args){

		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		String s = input.next();
		Map<Character,Integer> freq = Find_Occurence(s, size);

		if(freq.containsKey('a'))
			System.out.print(freq.get('a')+" ")
		else
			System.out.print("0"+" ");
		if(freq.containsKey('s'))
			System.out.print(freq.get('s')+" ");
		else
			System.out.print("0"+ " ");
		if(freq.containsKey('p'))
			System.out.print(freq.get('p')+" ");
		else
			System.out.print("0"+" ");
	}
}