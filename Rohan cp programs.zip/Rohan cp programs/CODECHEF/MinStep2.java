import java.util.Scanner;
class MinStep2{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr[] = new int[N+1];
		arr[1] = 0;
		for(int i = 2; i <= N; i++){

			int ans = arr[i-1];
			if(i%3 == 0){

				ans = Math.min(ans, arr[i/3]);
			}
			if(i%2 == 0)
			{
				ans = Math.min(ans, arr[i/2]);
			}
			arr[i] = 1 + ans;
		}
		System.out.println(arr[N]);
	}
}