import java.util.Scanner;

class Momos{


	private static int Find_Index(long arr[], int low, int high, long X){

		while(low < high){

			int mid = (low+high)/2;
			if(arr[mid] <= X && arr[mid+1] >= X)
				return mid;
			if(X > arr[mid])
				low = mid + 1;
			else
				high = mid - 1;
		}
		return low;
	}
	
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);

		int N = input.nextInt();
		long arr[] = new long[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextLong();
		
		//find Prefix Sum...

		for(int i = 1; i < N; i++)
			arr[i] = arr[i] + arr[i-1];


		int q = input.nextInt();
		while(q-->0){

			long X = input.nextLong();
			int position = Find_Index(arr, 0, N-1, X);
			System.out.println((position+1)+" "+(X-arr[position]));
		}

	}

}