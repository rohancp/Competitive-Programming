import java.util.Scanner;
class Knapsack{

	private static int fill_knapsack(int value[], int wt[], int n, int W){

		if(n == 0 || W == 0)
			return 0;

		if(wt[n-1] <= W){

			return Math.max(value[n-1] + fill_knapsack(value, wt, n-1, W - wt[n-1]), fill_knapsack(value, wt, n-1, W));
		}
		return fill_knapsack(value, wt, n-1, W);
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int wt[] = new int[n];
		int value[] = new int[n];
		for(int i = 0; i < n; i++)
			wt[i] = input.nextInt();
		for(int i = 0; i < n; i++)
			value[i] = input.nextInt();
		int W = input.nextInt();
		int ans = fill_knapsack(value, wt, n, W);
		System.out.println(ans);
	}
}