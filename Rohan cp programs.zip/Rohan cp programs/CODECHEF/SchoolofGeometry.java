import java.util.*;
import  java.io.*;
import java.lang.*;
class SchoolofGeometry{

	private static long getMaximumDiameter(int seqA[], int seqB[]){

		int n = seqB.length;
		Arrays.sort(seqB);
		Arrays.sort(seqA);
		long result = 0;
		for(int i = 0; i < n; i++){

			int min = Math.min(seqA[i],seqB[i]);
			result += min;
		}

		return result;
	}

	public static void main(String [] args)throws IOException{
		StringBuilder sb = new StringBuilder();

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){
				int n = Integer.parseInt(br.readLine());
				int seqA[] = new int[n];
				int seqB[] = new int[n];
				String input[] = br.readLine().split(" ");
				String input2[] = br.readLine().split(" ");
				int i = 0;
				for(String in : input){
					seqA[i++] = Integer.parseInt(in);
				}
				i = 0;
				for(String in : input2){
					seqB[i++] = Integer.parseInt(in);
				}
				long result = getMaximumDiameter(seqA, seqB);
				sb.append(result);
				if(tc != 0)
					sb.append("\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}