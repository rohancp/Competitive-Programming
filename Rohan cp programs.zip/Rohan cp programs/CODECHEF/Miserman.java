import java.util.Scanner;
class Miserman{

	private static int min_amount(int mat[][], int n, int m){

		int dp[][] = new int[n+1][m+1];
		for(int i = 1; i <= m; i++)
			dp[n][i] = mat[n][i];
		for(int i = n-1; i >= 1; i--){
			for(int j = m; j >= 1; j--){

				dp[i][j] = mat[i][j] + dp[i+1][j];
				if(j-1 > 0)
					dp[i][j] = Math.min(dp[i][j], mat[i][j] + dp[i+1][j-1]);
				if(j != m)
					dp[i][j] = Math.min(dp[i][j], mat[i][j] + dp[i+1][j+1]);
			}
		}

		int min = Integer.MAX_VALUE;
		for(int i = 1; i <= m; i++){
			if(min > dp[1][i])
				min = dp[1][i];
		}
		return min;
	}

	
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int m = input.nextInt();
		int mat[][] = new int[n+1][m+1];
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= m; j++)
				mat[i][j] = input.nextInt();
		}
		int ans = min_amount(mat, n, m);
		System.out.println(ans);
	}
}