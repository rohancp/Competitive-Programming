import java.util.Scanner;
class Msb{

	private static int Find(int N, int i){

		if( i == 0)
			return 0;

		int A = (1 << i-1);
		A = A | A-1;
		return (A & N);

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int i = input.nextInt();
		int result = Find(N, i);
		System.out.println(result);
	}
}