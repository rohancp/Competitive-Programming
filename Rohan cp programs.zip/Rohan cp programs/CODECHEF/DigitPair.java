import java.util.Scanner;
class DigitPairs{


	private static int find_pair(int arr[], int n){


		String str[] = new String[n];


		for(int i = 0; i < n; i++){


			int num = arr[i];
			int a = num%10;
			num /=10;
			int b = num %10;
			num /= 10;
			int c = num%10;
			int max,min;
			max = Math.max(a, Math.max(b,c));
			min = Math.min(a, Math.min(b,c));
			num = (max*11) + (min*7);
			String s = Integer.toString(num);
			if(s.length() == 3){
				s = s.substring(1,3);
			}
			str[i] = s;
		}
		int count = 0;
		for(int i = 0; i < n; i++){

			for(int j = i+2; j < n; j +=2){


				if(str[i].equals(str[j])){

					count++;
					break;
				}
				else if(str[i].charAt(0) == str[j].charAt(0)){

					count++;
					break;
				}
			}
		}
		return count;
	}


	public static void main(String [] args){


		Scanner input = new Scanner(System.in);
		// System.out.println("Input");
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = find_pair(arr, n);
		// System.out.println("Output");
		System.out.println(result);

	}
}