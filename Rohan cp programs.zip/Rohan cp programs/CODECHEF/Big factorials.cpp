#include<stdio.h>

int main(){
	int a[1000],n,m,carry,i=0,c,l,v,testcases;
	scanf("%d",&testcases);
	while(testcases>0){
		testcases--;
	scanf("%d",&n);
	if(n==0 || n==1)
	printf("%d",1);
	else{i=0;
		m=n-1;
		while(n>0){
			a[i]=n%10;
			n=n/10;
			i++;
		}
		while(m>1){
			carry=0;
			l=0;
			c=0;
			while(c<i){
				v=a[c]*m;
				v+=carry;
				a[c]=v%10;
				l++;
				carry=v/10;c++;
			}
			while(carry>0){
				a[c]=carry%10;
				carry=carry/10;
				l++;
				c++;
			}
			i=l;
			m--;
		}i--;
		while(i>-1){
			printf("%d",a[i--]);
		}
	
	}printf("\n");
	}
	return 0;
}
//93326215443944152681699238856266700490715968264381621468592963895217599993229915608941463976156518286253697920827223758251185210916864000000000000000000000000
