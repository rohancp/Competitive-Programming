import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Vector;
class Graph{

	LinkedList<Integer> adlist[];
	public Graph(int V){
		adlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adlist[i] = new LinkedList<>();
	}
	public void add_Edge(int fv, int sv){
		adlist[fv].add(sv);
		adlist[sv].add(fv);
	}
	public void find_Path(int src, int end, int n, boolean visited[]){
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(src);
		int sp[] = new int[n];
		Arrays.fill(sp, -1);
		visited[src] = true;
		while(!queue.isEmpty()){

			int v = queue.poll();
			for(int u : adlist[v]){
				if(!visited[u]){
					sp[u] = v;
					queue.add(u);
					visited[u] = true;
				}
			}

		}
		if(sp[end] != -1){
			Vector<Integer> vec = new Vector<Integer>();
			while(sp[end] != -1){
				vec.add(end);
				end = sp[end];
			}
			vec.add(end);
			for(int i = vec.size()-1; i >= 0; i--)
				System.out.print(vec.get(i)+" ");
		}
	}
}

class Getpathbfs{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E;i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		boolean visited[] = new boolean [V];
		Arrays.fill(visited, false);
		int src = input.nextInt();
		int end = input.nextInt();
		g.find_Path(src, end, V, visited);
	}
}