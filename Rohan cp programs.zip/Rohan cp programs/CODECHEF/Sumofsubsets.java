import java.util.Scanner;
class Sumofsubsets{

	private static int FindSumofSubsets(int arr[], int Sum, int i){
		
		if(Sum == 0)
			return 1;
		if(Sum < 0 || i >= arr.length)
			return 0;
		int f = FindSumofSubsets(arr, Sum - arr[i], i+1);
		int s = FindSumofSubsets(arr, Sum, i+1);
		return (f+s);
	}

	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int W = input.nextInt();
		int result = FindSumofSubsets(arr, W, 0);
		System.out.println(result);
	}
}