import java.util.Scanner;
import java.util.Arrays;
class WarmReception{


	private static int find(int arr[], int dep[]){

		Arrays.sort(arr);
		Arrays.sort(dep);
		int i = 0,j = 0;
		int count = 0;
		int min = Integer.MIN_VALUE;
		while( i < arr.length && j < dep.length){

			if(arr[i] <  dep[j]){

				count++;
				i++;
			}
			else{

				count--;
				j++;
			}

			if(count > min){

				min = count;
			}


		}
		return min;

			}


	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arrival[] = new int[n];
		int depar[] = new int[n];
		for(int i = 0; i < n; i++){

			arrival[i] = input.nextInt();
		}
		for(int i = 0; i < n; i++){

			depar[i] = input.nextInt();
		}

		int result = find(arrival, depar);
		System.out.println(result);
	}
}