import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class MagicGrid{

	private static int Minimum_Strength(int arr[][], int r, int c){

		// System.out.println(arr[r-1][c-2]);
		int dp[][] = new int[r][c];
		dp[r-1][c-1] = 1;
		for(int i = c-2; i >= 0; i--){
			// System.out.println(dp[r-1][i+1]);
			// System.out.println(arr[r-1][i]);

			int value = dp[r-1][i+1] - (arr[r-1][i]);
			// System.out.println(value);
			if(value <= 0)
				dp[r-1][i] = 1;
			else
				dp[r-1][i] = value;
		}

		for(int i = r-2; i >= 0; i--){

			int value = dp[i+1][c-1] - arr[i][c-1];
			if(value <= 0)
				dp[i][c-1] = 1;
			else
				dp[i][c-1] = value;
		}

		for(int i = r-2; i >= 0; i--){

			for(int j = c-2; j >= 0; j--){

				int min = Math.min(dp[i][j+1], dp[i+1][j]);
				int value = min - arr[i][j];
				if(value <= 0)
					dp[i][j]  = 1;
				else
					dp[i][j] = value;
			}
		}


		// for(int i = 0; i < r; i++)
		// {

		// 	for(int j = 0; j < c; j++)
		// 		System.out.print(dp[i][j]+" ");
		// 	System.out.println();
		// }

		return dp[0][0];

	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			String s = br.readLine();
			String ss[] = s.split(" ");
			int r = Integer.parseInt(ss[0]);
			int c = Integer.parseInt(ss[1]);
			int arr[][] = new int[r][c];
			for(int i = 0; i < r; i++){

				String b = br.readLine();
				String a[] = b.split(" ");
				int j  = 0;

				for(String in : a)
					arr[i][j++] = Integer.parseInt(in);
			}

			int result = Minimum_Strength(arr, r, c);
			System.out.println(result);

		}
	}
}