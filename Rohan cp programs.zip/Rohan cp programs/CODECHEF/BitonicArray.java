import java.util.Scanner;
class BitonicArray{

	private static int longestBitonicSubarray(int[] arr){

			int n = arr.length;
			int dp1[] = new int[n];
			int dp2[] = new int[n];
			dp1[0] = 1;
			dp2[n-1] = 1;
			for(int i = 1; i < n; i++){

				dp1[i] =1;
				int k = n-i-1;
				dp2[k] = 1;
				//for first dp1 array..
				for(int j = i-1; j >= 0; j--){

					if(arr[i] > arr[j] && dp1[j] +1 > dp1[i])
						dp1[i] = dp1[j] +1;
				}
				//for second dp2 array..
				for(int j = k+1; j < n; j++){

					if(arr[k] > arr[j] && dp2[j] +1 > dp2[k])
						dp2[k] = dp2[j] + 1;
				}
			}

			int max = Integer.MIN_VALUE;
			for(int i = 0; i < n; i++)
				max = Math.max(max, dp1[i] + dp2[i] - 1);

			return max;
		}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = longestBitonicSubarray(arr);
		System.out.println(result);
	}
}