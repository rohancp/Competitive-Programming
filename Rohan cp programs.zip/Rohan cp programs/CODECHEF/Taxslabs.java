import java.util.*;
import java.lang.*;
import java.io.*;
class Taxslabs{


	public static void main(String [] args){


		try{
			Scanner input = new Scanner(System.in);
			int tc = input.nextInt();
			while(tc-- > 0){
				int n = input.nextInt();
				int tax = 0;
				if(n>=250000){
					tax = 0;
				}
				if(n>= 250001){
					if(n < 500000){
						tax = tax + (int)(.05*(n-250000));
					}
					else{
						tax = tax +(int) (.05*(500000-250000));
					}
				}
				if(n >= 500001){
					if(n < 750000){
						tax = tax + (int)(.10*(n-500000));
					}
					else{
						tax = tax + (int)(.10*(750000-500000));
					}
				}
				if( n >= 750001){
					if(n < 1000000){
						tax = tax + (int)(.15*(n-750000));
					}else{
						tax = tax + (int)(.15*(1000000-750000));
					}
				}
				if( n >= 1000001){
					if(n < 1250000){
						tax = tax + (int)(.20*(n-1000000));
					}
					else{
						tax = tax + (int)(.20*(1250000-1000000));
					}
				}
				if(n >= 1250001){
					if(n < 1500000){
						tax = tax +(int)(.25*(n-1250000));
					}
					else{
						tax = tax + (int)(.25*(1500000-1250000));
					}
				}
				if(n >= 1500000){
					tax = tax+(int)(.30*(n-1500000));
				}
				System.out.println(n-tax);
			}

		}
		catch(Exception E){
			return ;
		}
	}
}