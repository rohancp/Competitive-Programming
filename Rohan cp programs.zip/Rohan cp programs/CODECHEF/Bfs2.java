import java.util.Scanner;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Queue;
class Graph{

	LinkedList<Integer> adjlist[];
	public Graph(int V){
		adjlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adjlist[i] = new LinkedList<>();
	}
	public void add_Edge(int fv, int sv){
		adjlist[fv].add(sv);
		adjlist[sv].add(fv);
	}

	public void traverse_graph(int src, boolean visited[]){

		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(src);
		visited[src] = true;
		while(!queue.isEmpty()){
			int v = queue.poll();
			System.out.print(v+" ");
			for(int u : adjlist[v]){
				if(!visited[u]){
					queue.add(u);
					visited[u] = true;
				}
			}
		}
		}
}
class Bfs2{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		g.traverse_graph(0, visited);
	}
}