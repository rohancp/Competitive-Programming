import java.util.Scanner;
import java.util.Arrays;
class Traderprofit2{

	private static int max_profit(int arr[], int n, int k, int in, int dp[]){
		if( k == 0 || in > n)	return 0;
		
		if(dp[in] != -1)	return dp[in];

		int ans = 0;
		for(int i = in; i < n; i++){
			int value = 0;
			for(int j = i+1; j <= n; j++){
				if(arr[i] < arr[j])
					value = (arr[j] - arr[i]) + max_profit(arr, n, k-1, j+1, dp);
				ans = Math.max(ans, value);
			}
		}
		dp[in] = ans;
		return dp[in];
	}

	public static void main(String [] a){
		Scanner input = new Scanner(System.in);
		int queries = input.nextInt();
		while(queries-- > 0){
			int k = input.nextInt();
			int n = input.nextInt();
			int arr[] = new int [n+1];
			for(int i = 1; i <= n; i++)
				arr[i] = input.nextInt();
			int dp[] = new int[n+1];
			Arrays.fill(dp, -1);
			int ans = max_profit(arr, n, k, 1, dp);
			System.out.println(ans);
			for(int i = 0; i <= n; i++)
				System.out.print(dp[i] +" ");
			System.out.println();
		}	
	}
}