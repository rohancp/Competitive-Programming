import java.util.Scanner;
import java.util.LinkedList;
import java.util.Arrays;
import java.util.Queue;
class Graph{
	LinkedList<Integer> adjlist[];
	Graph(int V){
		adjlist = new LinkedList[V+1];
		for(int i = 0; i <= V; i++)
			adjlist[i] = new LinkedList<>();
	}
	public void add_edge(int fv, int sv){
		adjlist[fv].add(sv);
		adjlist[sv].add(fv);

	}

	public  long dfs(long arr[], int start, boolean visited[], long ans){

		Queue<Integer> q = new LinkedList<>();
		q.add(start);
		visited[start] = true;
		ans += arr[start];
		while(!q.isEmpty()){
			int val = q.peek();
			q.poll();
			for(int u : adjlist[val]){
				if(!visited[u]){
					ans += arr[u];
					q.add(u);
					visited[u] = true;
				}
			}
		}
		return ans;
	}
	public  long get_ans(int n, long arr[]){
		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		long max = 0;
		for(int i = 1; i <= n; i++){
			if(!visited[i]){
				long a = dfs(arr, i, visited, 0);
				max = Math.max(max, a);
			}
		}
		return max;
	}
}
class Kingdom{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int n = input.nextInt();
			int m = input.nextInt();
			Graph g = new Graph(n);
			for(int i = 0 ;i < m;i++){

				int fv = input.nextInt();
				int sv = input.nextInt();
				g.add_edge(fv, sv);
			}
			long arr[] = new long[n+1];
			for(int i = 1; i <= n; i++)
				arr[i] = input.nextLong();
			long ans = g.get_ans(n, arr);
			System.out.println(ans);
			}
	}

}