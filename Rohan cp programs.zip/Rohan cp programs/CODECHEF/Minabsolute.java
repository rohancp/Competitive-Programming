import java.util.Scanner;
import java.util.Arrays;
class Minabsolute{

	private static int Find_abs_difference(int arr[], int n){

		Arrays.sort(arr);
		int min = Integer.MAX_VALUE;
		for(int i = 0 ; i < n-1; i++){

			int m = Math.abs(arr[i] - arr[i+1]);
			if(m <min)
				min = m;
		}

		return min;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr[] = new int[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextInt();
		int result = Find_abs_difference(arr, N);
		System.out.println(result);

	}
}