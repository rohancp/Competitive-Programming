#include<stdio.h>
int main(){
	int n,k,ti,c=0;
	scanf("%d %d",&n,&k);
	while(n>0){
		scanf("%d",&ti);
		if(ti%k==0)
		c++;
		n--;
	}
	printf("%d",c);
	return 0;
}
