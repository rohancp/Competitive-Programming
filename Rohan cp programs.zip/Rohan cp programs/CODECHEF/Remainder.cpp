#include<stdio.h>
int main(){
	int t_c,A,B;
	scanf("%d",&t_c);
	while(t_c-->0){
		scanf("%d %d",&A,&B);
		
		printf("%d\n",A%B);
		
	}
	return 0;
}
