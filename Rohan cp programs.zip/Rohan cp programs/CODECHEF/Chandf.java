import java.io.*;
import java.util.*;
import java.lang.*;
class Chandf{


	private static String ones[] = new String[41];
	private static String zeros[] = new String[41];
	private static void precomputation(){
		ones[0] ="";
		zeros[0] = "";
		String sones,szeros;
		// sones = "1";
		// szeros = "0";
		for(int i = 1; i < 41; i++){
			ones[i] = ones[i-1]+"1";
			zeros[i] = zeros[i-1]+"0";
			
		}
		// System.out.println(ones[4]);
	}


	private static long maximise(long X, long Y, long Z){

		long a = (X&Z);
		long b = (Y&Z);
		return (a * b);
	}

	private static long getZ(long X, long Y, long L, long R){
		Vector<Long> vec = new Vector<Long>();
		String r = Long.toBinaryString(R);
		String l = Long.toBinaryString(L);
		if(r.length() > l.length()){

			l = zeros[r.length()-l.length()] + l;
		}
		int size = r.length();
		String z = "";
		// long max_value = Long.MIN_VALUE;
		long small_Z = -1;
		// System.out.println(r+" "+l);
		for(int i = 0; i < size; i++){

			if(r.charAt(i) == l.charAt(i)){
				z = z+r.charAt(i);
				// System.out.println(z);
				continue;
			}
			else{
				if(r.charAt(i) == '1'){
					String newZ = z+"0"+ones[size-i-1];
					// System.out.println(newZ+" "+ones[size-i-1]);
					long newz = Long.parseLong(newZ, 2);
					vec.add(newz);
					// long value = maximise(X, Y, newz);
					// System.out.println(value);
					// if(max_value < value){
					// 	small_Z = newz;
					// 	max_value = value;
					// }
					// System.out.println(small_Z);
					z = z+"1";
				}
				else{
					z +="0";
				}
			}
		}

		long zz = Long.parseLong(z, 2);
		vec.add(zz);
		Collections.sort(vec);
		long maxvalue = -1;
		for(int i = 0; i < vec.size(); i++){

				long f = maximise(X, Y, vec.get(i));
				if(maxvalue < f){
					maxvalue = f;
					small_Z = vec.get(i);
				}

		}
		// System.out.println(vec);
		return small_Z;

	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			precomputation();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				long X, Y, L, R;
				X = Long.parseLong(s[0]);
				Y = Long.parseLong(s[1]);
				L = Long.parseLong(s[2]);
				R = Long.parseLong(s[3]);
				sb.append(getZ(X, Y, L, R)).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}

	}
}