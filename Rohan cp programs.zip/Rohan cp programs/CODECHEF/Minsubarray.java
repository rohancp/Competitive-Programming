import java.util.Scanner;
class Minsubarray{

	private static void build_tree(int arr[], int tree[], int treenode, int s, int e){

		if(s == e){
			tree[treenode] = arr[s];
			return ;
		}
		int mid = (s+e)/2;
		build_tree(arr, tree, (2*treenode), s, mid);
		build_tree(arr, tree, (2*treenode)+1, mid+1, e);
		tree[treenode] = Math.min(tree[2*treenode], tree[(2*treenode)+1]);
	}

	private static void update_tree(int arr[], int tree[], int treenode, int s, int e, int idx,int value){

		if(s == e){
			arr[s] = value;
			tree[treenode] = value;
			return ;
		}
		int mid = (s+e)/2;
		if(idx <= mid){
			update_tree(arr,tree, (2*treenode), s, mid, idx, value);
		}
		else
			update_tree(arr, tree, (2*treenode)+1, mid+1, e, idx, value);
		tree[treenode] = Math.min(tree[2*treenode] , tree[(2*treenode)+1]);
	}

	private static int find_min(int tree[], int treenode, int s, int e, int l, int r){

		if(e < l || s > r)
			return Integer.MAX_VALUE;
		if(s >= l && e <= r)
			return tree[treenode];
		int mid = (s+e)/2;
		int ans1 = find_min(tree, 2*treenode, s, mid, l, r);
		int ans2 = find_min(tree, (2*treenode)+1, mid+1, e, l, r);
		return Math.min(ans1, ans2);
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int q = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int tree[] = new int[4*n];
		build_tree(arr, tree, 1, 0, n-1);
		while(q-- > 0){
			char q_type = input.next().charAt(0);
			if(q_type == 'q'){
				int l = input.nextInt()-1;
				int r = input.nextInt()-1;
				int ans = find_min(tree, 1, 0, n-1, l, r);
				System.out.println(ans);
			}
			else{
				int idx = input.nextInt()-1;
				int value = input.nextInt();
				update_tree(arr, tree, 1, 0, n-1, idx, value);
			}
		}
	}
}