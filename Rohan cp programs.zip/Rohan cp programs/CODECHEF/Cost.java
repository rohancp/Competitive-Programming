import java.util.*;
class Cost {
    public static void main(String args[] )  {

        Scanner input = new Scanner(System.in);
        int tc = input.nextInt();
        while(tc-- > 0){
            
            int green = input.nextInt();
            int purple = input.nextInt();
            int N = input.nextInt();
            int min = Math.min(green,purple);
            int max = Math.max(green,purple);
            int var = min;
            int sum = 0;
            int cost[] = new int[N*2];
            for(int i = 0; i < N*2; i++)
                cost[i] = input.nextInt();
            for(int i = 0; i < N*2; i++)
            {
                if(cost[i] == 1){
                    
                    if(var == min){
                        
                        sum += var;
                        var = max;
                    }
                    else{
                        sum += var;
                        var = min;
                    }
                }
                else
                {
                    var = min;
                }
            }
            System.out.println(sum);
            
        }

    }
}
