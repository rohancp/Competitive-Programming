import java.util.*;
import java.io.*;
class Pair implements Comparable<Pair> {
	int st;
	int ft;
	Pair(int st, int ft){

		this.st = st;
		this.ft = ft;
	}
    public int compareTo(Pair p1) {
				return this.ft - p1.ft;
			}
}
public class Main{
    private static int Max_Activity(ArrayList<Pair> al, int n){

		int count = 1;
		int ftime = al.get(0).ft;
		for(int i = 1; i < n; i++){

			if(ftime <= al.get(i).st){
				count++;
				ftime = al.get(i).ft;
			}
		}
		return count;
	}
	public static void main(String [] args)throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
        ArrayList<Pair> al = new ArrayList<Pair>();     
		for(int i = 0; i < N; i++){
			String s = br.readLine();
            String s1[] = s.split(" ");
           int st = Integer.parseInt(s1[0]);
           int ft = Integer.parseInt(s1[1]);
            al.add(new Pair(st, ft));
		}  
        Collections.sort(al);
		int result = Max_Activity(al, N);
		System.out.println(result);
	}
}