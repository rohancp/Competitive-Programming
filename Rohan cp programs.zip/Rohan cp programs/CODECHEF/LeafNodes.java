import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
class LeafNodes{

	private static void FindLeafNodes(int pre[], int in[], int sprei, int lprei, int sIni, int lIni){

		if(sprei > lprei || sIni > lIni)
				return ;

		// When sIni == lIni i.e. Leaf node is found..

		if(sIni == lIni)
			{
				System.out.print(in[lIni]+" ");
				return ;
			}
		int i = sIni;
		int c = 0;

		// find root element in Inorder Array...

		while(in[i] != pre[sprei]){
			i++;
			c++;
		}
		FindLeafNodes(pre, in, sprei+1, sprei+c, sIni, i-1);
		FindLeafNodes(pre, in, sprei+c+1, lprei, i+1, lIni);
		return ;


	}
	

	public static void main(String[]args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());

		while(tc-- > 0){

			int N = Integer.parseInt(br.readLine());
			String s[] = br.readLine().trim().split("\\s+");
			int pre[] = new int[N];
			int i = 0;
			for(String a : s)
				pre[i++] = Integer.parseInt(a);

			//Create Inorder Array;

			int in[] = new int[N];
			for(i = 0; i < N; i++)
				in[i] = pre[i];
			Arrays.sort(in);
			FindLeafNodes(pre, in,0, N - 1, 0, N - 1);
			System.out.println();
		}
	}
}