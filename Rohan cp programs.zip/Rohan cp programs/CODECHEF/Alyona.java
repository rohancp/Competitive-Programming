import java.util.Scanner;
class Alyona{

	private static void traverse_table(int sheet[][], int LR[][], int k, int row, int col){

		for(int i = 0; i < k; i++){

			int l = LR[i][0];
			int r = LR[i][1];

			if(l ==r){
				System.out.println("Yes");
				continue;
			}
			l--;r--;
			boolean b = false;
			for(int c = 0; c < col; c++){
				int j = l;
				for( ; j <= r-1; j++){

					if(sheet[j][c] <= sheet[j+1][c])
						continue;
					else
						break;
				}
				if(j == r){

					b = true;  
					break;
				}
			}
			if(b)
				System.out.println("Yes");
			else
				System.out.println("No");
		}
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int m = input.nextInt();
		int sheet[][] = new int [n][m];
		for(int i = 0; i < n; i++){

			for(int j = 0; j < m; j++)
				sheet[i][j] = input.nextInt();
		}

		int k = input.nextInt();
		int LR[][] = new int[k][2];
		for(int i = 0; i < k; i++){
			LR[i][0] = input.nextInt(); 
			LR[i][1] = input.nextInt();
		}
		traverse_table(sheet, LR, k, n, m);
	}
}