import java.util.Scanner;
class Node{

	long max, smax;
	Node(long x, long y){
		this.max = x;
		this.smax = y;
	}
}
class Maxpairsum2{

	private static void build_tree(int arr[], Node tree[], int treenode, int start, int end){

		if(start == end){

			tree[treenode] = new Node(arr[start], Integer.MIN_VALUE);
			return ;
		}
		int mid = (start + end)/2;
		build_tree(arr, tree,2*treenode, start, mid);
		build_tree(arr, tree, (2*treenode)+1, mid+1, end);
		Node left = tree[2*treenode];
		Node right = tree[(2*treenode)+1];
		long maxele = Math.max(left.max,right.max);
		long secmax = Math.min(Math.max(left.max, right.smax), Math.max(left.smax, right.max));
		tree[treenode] = new Node(maxele, secmax);

	}
	public static void update_tree(int arr[], Node tree[], int treenode, int start, int end, int idx, int value){

		if(start == end){
			arr[start] = value;
			tree[treenode].max = value;
			return ;
		}
		int mid = (start + end)/2;
		if(idx <= mid)
			update_tree(arr, tree, (2*treenode), start, mid, idx,value);
		else
			update_tree(arr, tree, (2*treenode)+1, mid+1, end, idx, value);
		Node left = tree[2*treenode];
		Node right = tree[(2*treenode)+1];
		long maxele = Math.max(left.max,right.max);
		long secmax = Math.min(Math.max(left.max, right.smax), Math.max(left.smax, right.max));
		tree[treenode].max = maxele;
		tree[treenode].smax = secmax;
	}

	private static Node find_max_Pair(Node tree[], int treenode, int start, int end, int l, int r){

		if( end < l || start > r)
			return null;
		if(start >= l && end <= r)
			return tree[treenode];
		int mid = (start + end)/2;
		Node ans1 = find_max_Pair(tree, 2*treenode, start, mid, l, r);
		Node ans2 = find_max_Pair(tree, (2*treenode)+1, mid+1, end, l, r);
		if(ans1 != null && ans2 != null){

			long maxele = Math.max(ans1.max, ans2.max);
			long secmax = Math.min(Math.max(ans1.max, ans2.smax), Math.max(ans1.smax, ans2.max));
			Node result = new Node(maxele, secmax);
			return result;
		}
		else if(ans1 != null)
			return ans1;
		return ans2;
		
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		Node tree[] = new Node[4*n];
		build_tree(arr, tree, 1, 0, n-1);	
		// System.out.println(tree[1].max+" "+tree[1].smax);
		int query = input.nextInt();
		while(query-- > 0){

			char q_type = input.next().charAt(0);
			if(q_type == 'Q'){

				int l = input.nextInt()-1;
				int r = input.nextInt()-1;
				Node ans = find_max_Pair(tree, 1, 0, n-1, l, r);
				System.out.println(ans.max + ans.smax);
			}
			else{

				int idx = input.nextInt()-1;
				int value = input.nextInt();
				update_tree(arr, tree, 1, 0, n-1, idx, value);
			}
		}
	}
}