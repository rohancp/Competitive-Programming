import java.util.*;
class Akshay{

	public static void main(String [] args){

		Map<Integer, String> map = new HashMap<>();
		Integer i1 = new Integer(2);
		Integer i2 = new Integer(2);
		map.put(i1, "rohan");
		map.put(i2, "roha");
		System.out.println(i1+" "+i2);
	}
}