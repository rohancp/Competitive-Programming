import java.util.Scanner;
class Ratinamaze2{

	private static void PrintSolution(int sol[][], int n){

		for(int i = 0; i < n;i++)
		{
			for(int j = 0; j < n ;j++)
				System.out.print(sol[i][j]+" ");
		}
		System.out.println();
	}

	private static void Rat_Maze(int path[][], int sol[][], int r, int c, int n){

		if(r == n-1 && c == n-1)
		{
			sol[r][c] = 1;
			PrintSolution(sol,n);
			sol[r][c] = 0;
			return ;
		}
		if(r>=n || r<0 || c >=n || c <0 || path[r][c] == 0 || sol[r][c] ==1)
			return ;

		sol[r][c] = 1;
		Rat_Maze(path, sol, r-1,c,n);
		Rat_Maze(path, sol, r+1, c, n);
		Rat_Maze(path, sol, r, c-1,n);
		Rat_Maze(path, sol, r, c+1, n);
		sol[r][c] = 0;
		return ;

	}

	public static void main(String []a){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int path[][] = new int[N][N];
		for(int i = 0; i < N; i++){

			for(int j = 0; j < N; j++)
				path[i][j] = input.nextInt();
		}
		int sol[][] = new int[N][N];
		Rat_Maze(path, sol, 0, 0, N);

	}
}