import java.util.Scanner;

class ReplaceCharacter{

	private static String replaceCharacter(String input, char c1, char c2) {

		if(input.length() == 0)
			return "";
		char ch[] = input.toCharArray();
		if(ch[0] == c1)
			ch[0] = c2;
		input = String.valueOf(ch);
		String s = input.substring(0,1);
		String s2 = replaceCharacter(input.substring(1,input.length()), c1, c2);

		return s+s2;

	}


	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		String s = input.next();
		char c1 = input.next().charAt(0);
		char c2 = input.next().charAt(0);
		String result = replaceCharacter(s, c1, c2);
		System.out.println(result);
	}

}