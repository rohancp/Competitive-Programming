import java.util.Scanner;
import java.util.Arrays;
class AggressiveCows2{

	private static boolean isPlaced(int d, int cow, int pos[], int N){

			int prev_pos = 0;
			cow--;
			for(int i = 1; i < N; i++){

				if(Math.abs(pos[prev_pos] - pos[i]) >= d)
				{
					cow--;
					prev_pos = i;
				}
				if(cow == 0)
					return true;
			}
			return false;
	}
	private static int Min_Difference(int position[],int cow, int N){
		int prev = 0;
		int low = 0;
		Arrays.sort(position);
		int high = position[N-1] - position[0];
		while(high >= low){

			int d = (low+high)/2;
			if(isPlaced(d, cow, position, N))
			{
				low = d+1;
				prev = Math.max(prev, d);
			}
			else
				high = d-1;
		}
		return prev;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int N = input.nextInt();
			int cow = input.nextInt();
			int position[] = new int[N];
			for(int i = 0; i < N; i++)
				position[i] = input.nextInt();
			int result = Min_Difference(position, cow, N);
			System.out.println(result);
		}
	}
}