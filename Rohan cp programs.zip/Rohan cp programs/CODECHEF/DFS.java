import java.util.Scanner;
import java.util.Arrays;
class Graph{

		int adjmat[][];
		
		public Graph(int V){
			adjmat = new int[V][V];

		}
		public void AddEdge(int fv, int sv){

			adjmat[fv][sv] = 1;
			adjmat[sv][fv] = 1;
		}
		public int[][] AdjancyMatrix(){
			return adjmat;
		}

}
class DFS{

	// Dfs traversal 

	private static void print_path(int adjmat[][], int n, int src, boolean visited[]){

		System.out.println(src);
		visited[src] = true;
		for(int i = 0; i < n; i++){
			if(adjmat[src][i] == 1 && !visited[i])
				print_path(adjmat, n, i, visited);
		}
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph  g = new Graph(V);
		for(int i = 0; i < E; i++){

			int fv = input.nextInt();
			int sv = input.nextInt();
			g.AddEdge(fv, sv);
		}
		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		int adjmat[][] = g.AdjancyMatrix();
		print_path(adjmat, V, 0, visited);
	}
}