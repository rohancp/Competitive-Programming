import java.util.Scanner;

class Variation2{

	private static int Merging(int arr[], int s, int l, int mid,int K){
		
		int i,j,c = 0,m;
		i = s;
		j = mid+1;
		m =s;
		int arr2[] = new int[arr.length];
		while( i <= mid && j <= l){
			if(Math.abs(arr[i] - arr[j]) >= K){

				c += (l+1)-j;
			}
			if(arr[i] > arr[j]){
				arr2[m++] = arr[j++];
			}
			else
				arr2[m++] = arr[i++];
		}
		while( i <= mid ){
			arr2[m++] = arr[i++];
		}
		while( j <= l){
			arr2[m++] = arr[j++];
		}
		for(; s <= l;s++ )
			arr[s] = arr2[s];
		return c;

	}

	private static int MergeSort(int arr[], int low , int high, int K){

		if(low < high){

			int mid = (low + high)/2;
			int left_sum = MergeSort(arr, low, mid, K);
			int right_sum = MergeSort(arr, mid+1, high, K);
			int C = Merging(arr, low, high, mid, K);
			return (left_sum + right_sum + C);

		}

		return 0;

	}

	public static void main(String ar[]){

	Scanner input = new Scanner(System.in);
	int N = input.nextInt();
	int K = input.nextInt();
	int arr[] = new int[N];
	for(int i = 0; i < N; i++)
		arr[i] = input.nextInt();

	int result = MergeSort(arr, 0,N-1, K);
	System.out.println(result);

	}
}