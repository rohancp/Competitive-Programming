import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedList;
class Graph{

	LinkedList<Integer> adlist[];
	public Graph(int V){
		adlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adlist[i] = new LinkedList<Integer>();
	}

	public void add_Edge(int fv, int sv){
		adlist[fv].add(sv);
		adlist[sv].add(fv);
	}
	public void _isconnected(int src, boolean visited[]){
		visited[src] = true;
		for(int u : adlist[src]){
			if(!visited[u])
				_isconnected(u,visited);
		}
	}
}
class Isconnected{
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		boolean visited[] = new boolean [V];
		Arrays.fill(visited, false);
		boolean flag = true;
		g._isconnected(0, visited);
		for(int i = 0; i < V; i++){
			if(!visited[i]){
				flag = false;
				break;
			}
		}
		System.out.println(flag);
	}
}