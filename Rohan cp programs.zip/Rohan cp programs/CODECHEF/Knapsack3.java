import java.util.Scanner;
import java.util.Arrays;
class Knapsack3{

	private static int fill_knapsack(int wt[], int v[], int n, int W,int dp[][]){

		for(int i = 1; i <= n; i++){

			for(int w = 1; w <= W; w++){

				if(wt[i-1] <= w)
					dp[i][w] = Math.max(v[i-1] + dp[i-1][w - wt[i-1]], dp[i-1][w]);
				else
					dp[i][w] = dp[i-1][w];
			}
		}
		return dp[n][W];
	}
	private static int fill_knapsack2(int wt[], int v[], int W, int n){

		int dp[] = new int[W+1];
		Arrays.fill(dp, 0);
		for(int i = 0; i < n; i++){

			for(int j = W ; j >= wt[i]; j--){

				dp[j] = Math.max(dp[j], v[i]+dp[j-wt[i]]);
			}
		}
		return dp[W];
	}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int wt[] = new int [n];
		int v[] = new int[n];
		for(int i = 0; i < n; i++)
			wt[i] = input.nextInt();
		for(int i = 0; i < n; i++)
			v[i] = input.nextInt();
		int W = input.nextInt();
		int dp[][] = new int [n+1][W+1];
		for(int i = 0; i <= W; i++)
			dp[0][i] = 0;
		for(int i = 0; i <= n; i++)
			dp[i][0] = 0;
		int ans = fill_knapsack(wt, v, n, W, dp);
		System.out.println(ans);
		ans = fill_knapsack2(wt,v,W, n);
		System.out.println(ans);
		for(int i = 0 ; i <= n; i++)
		{
			for(int j = 0; j <= W; j++)
				System.out.print(dp[i][j]+"  ");
			System.out.println();
		}

	}
}