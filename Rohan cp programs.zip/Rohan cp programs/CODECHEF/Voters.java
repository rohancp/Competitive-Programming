import java.util.Scanner;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Map;
import java.util.Iterator;
class Voters{

		public static TreeSet<Integer> Id(HashMap<Integer, Integer> map){
			
			TreeSet<Integer> t = new TreeSet<Integer>();
			System.out.println(map);
			for(Map.Entry<Integer, Integer> set : map.entrySet()){

				int key = set.getKey();
				if(map.get(key) > 1){

					t.add(key);
				}

			}
			return t;
		}

	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		int L1 = input.nextInt();
		int L2 = input.nextInt();
		int L3 = input.nextInt();
		HashMap<Integer, Integer> map = new HashMap<>();
		for(int i = 0; i < L1; i++){
			int ele = input.nextInt();
			if(map.containsKey(ele)){
				map.put(ele,map.get(ele)+1);
			}
			else
				map.put(ele, 1);
		}
		for(int i =0; i < L2; i++){

			int ele = input.nextInt();
			if(map.containsKey(ele)){
				map.put(ele, map.get(ele)+1);
			}
			else map.put(ele, 1);
		}
		for(int i = 0; i < L3; i++){

				int ele = input.nextInt();
				if(map.containsKey(ele)){
					map.put(ele, map.get(ele)+1);
				}
				else map.put(ele, 1);
		}
		TreeSet<Integer> t = Id(map);
		Iterator<Integer> it = t.iterator();
		System.out.println(t.size());
		while(it.hasNext())
			System.out.println(it.next());
	}
}