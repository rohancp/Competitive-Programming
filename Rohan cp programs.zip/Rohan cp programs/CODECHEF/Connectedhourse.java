import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Iterator;
class Graph{

	LinkedList<Integer> adjlist[];
	public Graph(int V){
		adjlist = new LinkedList[V+1];
		for(int i = 0; i <= V; i++)
			adjlist[i] = new LinkedList<>();
	}

	public void add_edge(int fv, int sv){

		adjlist[fv].add(sv);
		adjlist[sv].add(fv);
	}

	public boolean has_path(int row, int col, int arr[][], int N,int M){

	//1. range exceed.

		if(row > N || col <= 0 || col > M)
			return false;

	//2. check path is or not

		if(arr[row][col] == 0)
			return false;
		return true;
	}

	public void dfs(HashSet<Integer> component, int src, boolean visited[]){
		visited[src] = true;
		component.add(src);
		for(int u : adjlist[src]){
			if(!visited[u])
				dfs(component, u, visited);
		}
	}

	public HashSet<HashSet<Integer>> get_components(int n){
		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		HashSet<HashSet<Integer>> output = new HashSet<>();
		for(int i = 1; i <= n; i++){
			if(!visited[i]){
				HashSet<Integer> set = new HashSet<>();
				dfs(set, i, visited);
				output.add(set);
			}
		}
		return output;
	}

	public int fact(int n){

		int mod = (int)Math.pow(10,9)+7;
		if(n == 0 || n == 1)
			return 1;
		int s = fact(n-1);
		long x =(long)(n*s);
		int ans = (int)(x%mod);
		return ans;
	}
}
class Connectedhourse{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int N = input.nextInt();
			int M = input.nextInt();
			int Q = input.nextInt();
			int arr[][] = new int[N+1][M+1];
			int e = 0;
			for(int i = 0; i < Q; i++){
				int x = input.nextInt();
				int y = input.nextInt();
				arr[x][y] = ++e;
			}
			// for(int i = 1; i <= N; i++){
			// 	for(int j = 1; j <= M; j++)
			// 		System.out.print(arr[i][j]+" ");
			// 	System.out.println();
			// }
			Graph g = new Graph(e);
			int path = 0;
			for(int r = 1; r <= N; r++){
				for(int c = 1; c <= M; c++){
					if(arr[r][c] != 0){

						if(g.has_path(r+1, c-2, arr, N, M)){
							path = 1;
							g.add_edge(arr[r][c], arr[r+1][c-2]);
						}
						if(g.has_path(r+1, c+2, arr, N, M)){
							path = 1;
							g.add_edge(arr[r][c], arr[r+1][c+2]);
						}
						if(g.has_path(r+2, c-1, arr, N, M)){
							path = 1;
							g.add_edge(arr[r][c], arr[r+2][c-1]);
						}
						if(g.has_path(r+2, c+1, arr, N, M)){
							path = 1;
							g.add_edge(arr[r][c], arr[r+2][c+1]);
						}
					}
					
				}
			}
			if(path != 0){
				int ans = 1;
				int mod = (int)Math.pow(10,9)+7;
				HashSet<HashSet<Integer>> component = g.get_components(e);
				Iterator<HashSet<Integer>> it = component.iterator();
				while(it.hasNext()){
					HashSet<Integer> set = it.next();
					int size = set.size();
					int f = g.fact(size);
					long a = (long)(f*ans);
					ans = (int)(a%mod);
					
				}
				System.out.println(ans);
			}
			
			else
				System.out.println(0);
		}
	}
}
/*
9 9 37
1 5
9 7
5 2
2 5
7 8
8 8
3 1
7 1
5 1
4 1
1 4
5 8
5 6
9 6
4 7
1 2
6 1
5 3
6 5
3 5
8 2
3 4
8 4
2 2
9 9
1 6
3 2
1 7
8 1
3 7
2 1
2 3
7 9
1 8
8 7
2 8
9 1
*/