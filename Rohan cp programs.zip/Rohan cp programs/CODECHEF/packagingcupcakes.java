import java.util.*;
class Rohan{
	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		int testcases=input.nextInt();
	int num;
		while(testcases-->0){

		num=input.nextInt();
		
		if(num%2==0){
		System.out.println((num/2)+1);

		}
		else{

		System.out.println((num+1)/2);

		}

}
}

}