import java.util.Scanner;
class Node{

	int even,odd;
}
class Evenodd{

	private static void build_tree(int arr[],Node tree[], int index, int start, int end){

		if(start == end){

		tree[index] = new Node();
		if(arr[start]%2 == 0){
			tree[index].even = 1;
			tree[index].odd = 0;
		}
		else{
			tree[index].even = 0;
			tree[index].odd = 1;
		}
		return ;
		}
		int mid = (start + end)/2;
		build_tree(arr, tree, 2*index, start, mid);
		build_tree(arr, tree, 2*index+1, mid+1, end);
		tree[index] = new Node();
		tree[index].even = tree[2*index].even + tree[2*index+1].even;
		tree[index].odd = tree[2*index].odd + tree[2*index+1].odd;
		return ;
	}
	private static void update_tree(int arr[], Node tree[], int index, int start, int end, int idx, int value){

		if(start == end){
			arr[idx] = value;
			if(value%2 == 0){
				tree[index].even = 1;
				tree[index].odd = 0;
			}
			else{
				tree[index].even = 0;
				tree[index].odd = 1;
			}
			return ;
		}
		int mid = (start + end)/2;
		if(idx <= mid)
			update_tree(arr,tree, 2*index, start, mid, idx, value);
		else
			update_tree(arr, tree, 2*index+1,mid+1, end, idx, value);
		tree[index].odd = tree[2*index].odd + tree[2*index+1].odd;
		tree[index].even = tree[2*index].even + tree[2*index+1].even;
		return ;

	}

	private static Node find_answer(Node tree[], int index, int start , int end, int low, int high){
		if(start > high || low > end)
			return null;
		if(start >= low && high >= end)
			return tree[index];
		int mid = (start+end)/2;
		Node ans1 = find_answer(tree, 2*index, start, mid, low, high);
		Node ans2 = find_answer(tree, 2*index+1, mid+1, end, low, high);
		if(ans1 != null && ans2 != null){
			Node node = new Node();
			node.even = ans1.even + ans2.even;
			node.odd = ans1.odd + ans2.odd;
			return node;
		}
		else if(ans1 != null)
			return ans1;
		return ans2;

	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		Node tree[] = new Node[4*n];
		build_tree(arr, tree, 1, 0, n-1);
		int query = input.nextInt();
		while(query-- > 0){

			int type = input.nextInt();
			if(type == 0){
				int idx = input.nextInt()-1;
				int value = input.nextInt();
				update_tree(arr, tree, 1, 0, n-1, idx, value);
			}
			else {
				int l = input.nextInt()-1;
				int r = input.nextInt()-1;
				Node ans = find_answer(tree, 1, 0, n-1, l, r);
				if(type == 1){
					System.out.println(ans.even);
				}
				else
					System.out.println(ans.odd);
			}
		}
	}
}