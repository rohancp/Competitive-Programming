import java.util.Scanner;
class Equalizer{

	private static int Find_Cost(int a[], int b[], int n){

		 int cost = 0;
		 int i = 0;
		 for(; i < n-1; ){

		 	if(a[i] == b[i]){
		 		i++;
		 		continue;
		 	}
		 	if((a[i] != a[i+1]) && (b[i] != b[i+1])){
		 		int temp = a[i];
		 		a[i] = a[i+1];
		 		a[i+1] = temp;
		 		cost++;
		 		i+=2;
		 		continue;
		 	}
		 	cost++;
		 	i++;
		 }
		 if(a[i] != b[i])
		 	cost++;
		 return cost;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		String s1 = input.next();
		String ss[] = s1.split("");
		int a[] = new int[n];
		int i = 0;
		for(String e : ss)
			a[i++] = Integer.parseInt(e);
		String s2 = input.next();
		int b[] = new int[n];
		ss = s2.split("");
		i = 0;
		for(String e : ss)
			b[i++] = Integer.parseInt(e);
		// for(int aa : a)
		// 	System.out.println(aa);
		// for(int bb : b)
		// 	System.out.println(bb);

		int result = Find_Cost(a, b, n);
		System.out.println(result);
	}
}