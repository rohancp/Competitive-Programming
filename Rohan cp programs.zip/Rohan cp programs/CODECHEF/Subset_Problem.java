import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.lang.StringBuilder;
import java.util.Arrays;
class Subset_Problem{
 
	  public static void CreateSet(Vector<Integer> vec, LinkedHashSet<String> l)
	  {

	  	StringBuilder sb = new StringBuilder();
	  	sb.append("(");
	  	for(int i = 0;i<vec.size();i++)
	  	{
	  		String a = Integer.toString(vec.get(i));
	  		sb.append(a);
	  		if(i!=vec.size()-1)
	  			sb.append(" ");

	  	}
	  	sb.append(")");
	  	l.add(sb.toString());

	  	return ;
	  }


	  //PossibleSubset......

	  public static void PossibleSubset(Vector<Integer> vec, int arr[], int index, LinkedHashSet<String> jj)
	  {

	  	if(index>=arr.length)
	  		return ;

	  	vec.add(arr[index]);
	  	CreateSet(vec, jj);
	  	PossibleSubset(vec, arr, index + 1, jj);
	  	vec.remove(vec.size()-1);
	  	PossibleSubset(vec,arr,index + 1, jj );
	  	return ;
	  }

	  public static LinkedHashSet<String> printSubsets(int input[]){

	  	Vector<Integer> vec = new Vector<>();
	  	LinkedHashSet<String> jj = new LinkedHashSet<>();
	  	PossibleSubset(vec, input, 0,jj);
	  	
	  	return jj;
	  }

	public static void main(String[]args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-->0)
		{

			int N = Integer.parseInt(br.readLine());
			String line = br.readLine();
			String s[] = line.trim().split("\\s+");
			int arr[] = new int[N];
			for(int i = 0;i<N;i++)
				arr[i] = Integer.parseInt(s[i]);
			Arrays.sort(arr);

			LinkedHashSet<String>  l= printSubsets(arr);
			for(String s1 : l)
				System.out.println(s1);
			System.out.println();
		}
	}
}