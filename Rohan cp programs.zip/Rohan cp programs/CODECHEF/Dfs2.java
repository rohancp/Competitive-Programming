import java.util.Scanner;
import java.util.LinkedList;
import java.util.Arrays;
class Graph{

	LinkedList<Integer> adjlist[];
	public Graph(int V){
		adjlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adjlist[i] = new LinkedList<>();
	}
	public void add_Edge(int fv, int sv){
		adjlist[fv].add(sv);
		adjlist[sv].add(fv);
	}

	public void traverse_graph(int src, boolean visited[]){
		System.out.print(src+" ");
		visited[src] = true;
		for(int v : adjlist[src]){
			if(!visited[v])
				traverse_graph(v, visited);
		}
	}

}

class Dfs2{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_Edge(fv, sv);
		}
		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		g.traverse_graph(0, visited);

	}
}