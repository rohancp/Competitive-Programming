import java.util.Scanner;
import java.util.Vector;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;
class Removedup{

	private static Vector<Integer> removeDuplicates(Vector<Integer> vec){

		Set<Integer> set = new HashSet<Integer>();
		Vector<Integer> result = new Vector<Integer>();
		for(int i = 0; i < vec.size(); i++)
		{

			if(!set.contains(vec.get(i))){
				result.add(vec.get(i));
				set.add(vec.get(i));
			}


		}
		return result;



	}

	private static Vector<Integer> removeDuplicatesSecond(Vector<Integer> vec){

		Collections.sort(vec);
		Vector<Integer> result = new Vector<Integer>();
		result.add(vec.get(0));
		for(int i = 1; i < vec.size(); i++){


			if(vec.get(i-1) != vec.get(i))
				result.add(vec.get(i));
		}
		return result;



	}


	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		Vector<Integer> vec = new Vector<Integer>();
		for(int i = 0; i < size; i++)
		{
			int a = input.nextInt();
			vec.add(a);
		}
		// System.out.println(vec);
			Vector<Integer> result = removeDuplicates(vec);
			for(int i = 0; i < result.size(); i++)
				System.out.println(result.get(i));

			System.out.println();
			result  = removeDuplicatesSecond(vec);
			for(int i = 0; i < result.size(); i++)
				System.out.println(result.get(i));

	}

}