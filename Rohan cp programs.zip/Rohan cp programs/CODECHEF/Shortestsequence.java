import java.util.Scanner;
import java.util.Arrays;
class Shortestsequence{

	public static int solve(String s,String t, int m, int n, int dp[][]){
		
		if(dp[m][n] != -1)
			return dp[m][n];
		if(m == 0)
			return 1000000000;
		if( n <= 0)
			return 1;
		
		int k = 0;
		for(; k < n; k++){
			if(t.charAt(k) == s.charAt(0))
				break;
		}
		if(k == n)
			return 1;
dp[m][n] = Math.min(solve(s.substring(1, s.length()), t, m-1, n, dp), 1 + solve(s.substring(1, s.length()), t.substring(k+1, t.length()), m-1, n-k-1, dp));
				return dp[m][n];	
	}
	public static void main(String [] arg){
		Scanner input = new Scanner(System.in);
		String s = input.next();
		String t = input.next();
		int m = s.length();
		int n = t.length();
		int dp[][] = new int[m+1][n+1];
		for(int i = 0; i <= m; i++)
			Arrays.fill(dp[i], -1);
		int ans = solve(s, t, m, n,dp);
		System.out.println(ans);
	}
}