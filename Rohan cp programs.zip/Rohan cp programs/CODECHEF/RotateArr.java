import java.util.Scanner;
class RotateArr{


	private static void Rotate(int arr[], int d){

		int N = arr.length;
		if(d > N)
			d %= N;
		int temp[] = new int[d];
		for(int i = 0; i < d; i++){

			temp[i] = arr[i];
		}
		int i = 0;
		for( i = 0; d < N ;d++)
			arr[i++] = arr[d];
		
		for(int j = 0; j < temp.length; j++)
			arr[i++] = temp[j];

		for(i = 0; i < N ;i++)
			System.out.print(arr[i]+" ");

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr[] = new int[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextInt();
		int d = input.nextInt();
		Rotate(arr,d);

	}
}