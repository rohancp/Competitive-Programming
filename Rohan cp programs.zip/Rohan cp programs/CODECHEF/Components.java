import java.util.Scanner;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Iterator;
class Graph{

	LinkedList<Integer> adjlist[];
	Graph(int V){
		adjlist = new LinkedList[V+1];
		for(int i = 0; i <= V; i++)
			adjlist[i] = new LinkedList<>();
	}
	public void add_edge(int fv, int sv){
		adjlist[fv].add(sv);
		adjlist[sv].add(fv);

	}

	public void dfs(HashSet<Integer> comp, int src, int n, boolean visited[]){

		visited[src] = true;
		comp.add(src);
		for(int u : adjlist[src]){
			if(!visited[u]){
				dfs(comp, u, n, visited);
			}
		}
	}

	public HashSet<HashSet<Integer>> getComponents(int n){

		boolean visited[] = new boolean [n+1];
		Arrays.fill(visited, false);
		HashSet<HashSet<Integer>> output = new HashSet<>();
		for(int i = 1; i <= n; i++){

			if(!visited[i]){
				HashSet<Integer> comp = new HashSet<>();
				dfs(comp, i, n, visited);
				output.add(comp);
			}
		}
		return output;
	}
}
class Components{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){

			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_edge(fv, sv);
		}
		HashSet<HashSet<Integer>> component = g.getComponents(V);
		Iterator<HashSet<Integer>> it = component.iterator();
		while(it.hasNext()){
			HashSet<Integer> p = it.next();
			for(int a : p)
				System.out.print(a+" ");
			System.out.println();
		}
	}
}