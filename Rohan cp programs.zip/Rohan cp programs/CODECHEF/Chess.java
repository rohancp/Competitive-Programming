import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
class Chess{

	static List<String> list = new ArrayList<String>();

	// Now this Method Print the ChessBoard..

	private static void Print_Board(int ChessBoard[][], int N)
	{

		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0;i<N;i++)
		{
			for(int j = 0;j<N;j++)
			{
				if(ChessBoard[i][j] == 1)
				{
					String s = Integer.toString( j + 1);
					sb.append(s).append(" ");
				}
			}
		}
		sb.append("]");
		list.add(sb.toString());
		return ;
	}

	//Now this Method Check Already Queen Exist or Not....

	private static boolean Check_Position(int ChessBoard[][], int N, int row, int col)
	{

			//Now first check vertically..

		for(int i = row - 1;i>=0;i--)
		{
			if(ChessBoard[i][col] == 1)
				return false;
		}

		//Check left Diagonal..

		int i = row - 1;
		int j = col - 1;
		while(i>=0 && j>=0)
		{

			if(ChessBoard[i][j] == 1)
				return false;
			i--;
			j--;
		}

		//Check right Diagonal...

		i = row - 1;
		j = col + 1;

		while(i>=0 && j<N)
		{
			if(ChessBoard[i][j] == 1)
				return false;
			i--;
			j++;
		}
		return true;
	}

	//Now this Method Find Correct Move .....

	private static void Correct_Move(int ChessBoard[][], int N, int row)
	{
		// System.out.println("Rohan");
			if(row == N)
			{
				Print_Board(ChessBoard, N);
				return ;
			}

			for(int i = 0 ;i<N;i++)
			{

				if(Check_Position(ChessBoard, N, row, i))
				{
					ChessBoard[row][i] = 1;
					Correct_Move(ChessBoard, N, row + 1);

					//And now Backtrack...
					ChessBoard[row][i] = 0;

				}
			}
			return ;
	}

		private static void Initialize_Array(int arr[][], int N)
		{
			// System.out.println("Rohan");
			for(int i = 0;i<N;i++)
			{
				for(int j = 0;j<N;j++)
				{
					arr[i][j] = 0;
				}
			}

		}

			public static void main(String[]args)throws IOException{

				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				int tc = Integer.parseInt(br.readLine());
				while(tc-->0)
				{

					int N = Integer.parseInt(br.readLine());
					if(N == 1)
					{
						System.out.println("[1 ]");
						continue;
					}
					else if(N == 2 || N == 3)
					{
						System.out.println("-1");
						continue;
					}

					int ChessBoard[][] = new int[N][N];
					Initialize_Array(ChessBoard,N);
					Correct_Move(ChessBoard,N,0);
					// Collections.sort(list);
					for(String a : list)
						System.out.print(a+" ");
					list.removeAll(list);
					System.out.println();
				}

			}
}