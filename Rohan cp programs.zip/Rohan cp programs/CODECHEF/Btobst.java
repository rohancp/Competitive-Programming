import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
class Node{

	int data;
	Node left, right;
	Node(int data){

		this.data = data;
		left = right = null;

	}

}
class Btobst{

	private static int k = 0;

	private static void Initialize(){

		k = 0;
	}

	private static Node CreateBinaryTree(){

		int data;
         Scanner input = new Scanner(System.in);
         System.out.println("exit press 0 and otherwise enter data");
         data = input.nextInt();
         Node n;
         if(data!=0)
         	 n = new Node(data);
            
         else
               return null;

         System.out.println("Enter left child of "+n.data);

         n.left = CreateBinaryTree();

         System.out.println("Enter right child of "+n.data);

         n.right = CreateBinaryTree();
         return n;

	}

	private static void Inorder(Node root, List<Integer> l){

		if(root != null)
		{
			Inorder(root.left, l);
			l.add(root.data);
			Inorder(root.right, l);
		}

	}

	 private static void SwapArrayElement(int arr[], int i,int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;        
    }
    
    private static int Partition(int arr[], int s, int l)
    {
        int i = s - 1;
        for(int j = s;j<l;j++)
        {
            if(arr[j]<=arr[l])
            {
                i = i+1;
                SwapArrayElement(arr, i,j);
            }
        }
        i = i + 1;
        SwapArrayElement(arr, i, l);
        return i;
    }
    
    private static void QuickSort(int arr[], int s, int l)
    {
        if(s>=l)
            return ;
        int mid = Partition(arr,s,l);
        QuickSort(arr,s,mid-1);
        QuickSort(arr,mid+1,l);
//        return ;
    }


     private static Node binaryTreeToBST(Node root)
    {
	 
    	List<Integer> list = new ArrayList<Integer>();
    	Inorder(root, list);
    	// System.out.println(list);
    	int arr[] = new int[list.size()];
    	int N = arr.length;
    	for(int i = 0; i < N; i++)
    		arr[i] = list.get(i);
    	
    	//Now Apply Quicksort....

    	QuickSort(arr,0,N-1);
    	Initialize();
    	INORDER(root, arr);
    	List<Integer> list2 = new ArrayList<Integer>();
    	Inorder(root,list2);
    	System.out.println(list2);
    	return root;
    }

    private static void INORDER(Node root, int arr[]){

    	if(root != null){

    		INORDER(root.left, arr);
    		root.data = arr[k++];
    		INORDER(root.right, arr);

    	}

    }


	public static void main(String[]args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());

		while(tc-- > 0){

			Node root = CreateBinaryTree();
			binaryTreeToBST(root);
		}
	}
}