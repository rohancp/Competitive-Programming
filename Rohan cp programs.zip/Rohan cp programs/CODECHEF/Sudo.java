import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Sudo{

	public static boolean Check_Position(int Matrix[][], int row, int col, int N, int num)
	{

		//Now check row..
		//Now Check Column...

		for(int i = 0; i<N; i++)
		{
			if(Matrix[row][i] == num)	
			return false;
			if(Matrix[i][col] == num)
				return false;
		}

		//Now Check Small Matrix...

		int row1 = row - (row % 3);
		int col1 = col - (col % 3);
		for(int i = row1; i < row1+3; i++)
		{

			for(int j = col1; j < col1+3; j++)
			{
				if(Matrix[i][j] == num)
					return false;
			}
		}

		return true;
	}

	public static boolean Solve_Sudoku(int Matrix[][], int row, int col, int N)
	{
		// System.out.println("Rohan");
		if(row == N)
			return true;

		if(col == N)
			return Solve_Sudoku(Matrix, row + 1, 0, N);

		if(Matrix[row][col] != 0)
			return Solve_Sudoku(Matrix, row, col + 1, N);

		//Now insert Number...

		for(int i = 1; i<=N; i++)
		{
			if(Check_Position(Matrix, row, col, N, i))
			{
				Matrix[row][col] = i;
				if(Solve_Sudoku(Matrix, row, col + 1, N))
					return true;
				else
				{
					//Now BackTrack...
					Matrix[row][col] = 0;
				}
			}
		}

		return false;
	}


	public static void PrintMatrix(int Matrix[][], int N)
	{

		for(int i = 0; i < 9; i++)
		{

			for(int j = 0; j < 9; j++)
				System.out.print(Matrix[i][j]+" ");
			System.out.println();
		}
	}

	public static void main(String[]args)throws IOException	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int Tc = Integer.parseInt(br.readLine());

		while(Tc-- > 0)
		{

			// for(int i = 0; i < 81; i ++)
			// {
			// 	arr[i] = Integer.parseInt(s[i]);
			// }

			int Matrix[][] = new int[9][9];
			int k = 0;
			for(int i = 0; i < 9; i++)
			{

					String line = br.readLine();
					String s[] = line.trim().split("\\s+");

				for(int j = 0; j < 9; j++)
				{
					Matrix[i][j] = Integer.parseInt(s[i]);
				}
			}
			// PrintMatrix(Matrix, 9);
			boolean result = Solve_Sudoku(Matrix, 0, 0, 9);

			if(result)
			{
				PrintMatrix(Matrix, 9);
			// 	// continue;
			}
			System.out.println();
		}
	}
}