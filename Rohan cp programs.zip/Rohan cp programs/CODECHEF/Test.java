import java.util.*;
import java.io.*;
import java.lang.*;
class Test{



	
	public static void main(String [] args){

		String s1 = Integer.toBinaryString(0);
        String s2 = Integer.toBinaryString((int)Math.pow(10, 12));
		System.out.println(s1.length());
        System.out.println(s2.length());
        long a = (long)Math.pow(10, 12);
        long b = (long)Math.pow(10, 12);
        System.out.println(a&b);

	}
}