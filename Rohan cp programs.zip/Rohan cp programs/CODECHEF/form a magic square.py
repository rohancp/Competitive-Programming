from itertools import *
li=[]
m=100
for i in range(3):
    li.extend(map(int,input().split()))
for i in permutations(range(1,10)):
	if sum(i[:3])==15 and sum(i[3:6])==15 and sum(i[6:9])==15 and sum(i[::3])==15 and sum(i[1::3])==15 and sum(i[2::3])==15 and sum(i[::4])==15 and (i[2]+i[4]+i[6])==15:
		l=[]
		for j in range(0,9):
			n=abs(i[j]-li[j])
			l.append(n)
		m=min(m,sum(l))
print(m)
