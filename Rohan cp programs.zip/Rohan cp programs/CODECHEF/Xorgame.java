import java.util.*;
import java.io.*;
import java.lang.*;
class Xorgame{


		private static int checkSequences(int seqA[], int seqB[]){

			HashMap<Integer, Integer> map = new HashMap<>();
			for(int i = 0; i < seqA.length; i++){

				if(map.containsKey(seqA[i])){

					map.put(seqA[i], map.get(seqA[i]) + 1);
				}else{
					map.put(seqA[i], 1);
				}
			}
			for(int i = 0; i < seqB.length; i++){
				if(map.containsKey(seqB[i]) && map.get(seqB[i]) > 0){
					map.put(seqB[i], map.get(seqB[i]) - 1);
					continue;
				}
				return -1;
			}
			return 1;
		}
	public static void main(String [] args)throws IOException{
		try{

			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				String a[] = br.readLine().split(" ");
				String b[] = br.readLine().split(" ");
				int seqA[] = new int[a.length];
				int seqB[] = new int[b.length];
				for(int i = 0; i < a.length; i++){

					seqA[i] = Integer.parseInt(a[i]);
					seqB[i] = Integer.parseInt(b[i]);
				}

				int ans = checkSequences(seqA, seqB);
				if(ans == 1){
					for(int i = 0; i < seqA.length; i++){
						sb.append(seqA[i]+" ");
					}
				}
				else{
					sb.append(-1);
				}
				sb.append("\n");
			}
			System.out.print(sb.toString());
		}
		catch(Exception e){

			return ;
		}

	}
}