import java.util.*;
import java.io.*;
import java.lang.*;
class TripleSort3{


	private static StringBuilder sorthePermutation(int per[], int pos[], LinkedList<Integer> list, int N, int K){

		int orgK = K;
		StringBuilder numberofOp = new StringBuilder();
		while( (K > 0) && ( list.size() >= 3)){

			// StringBuilder s = new StringBuilder();

			int a = list.removeFirst();
			int b = list.removeFirst();
			int c = list.removeFirst();
			int i1, i2, i3;
			i1 = pos[a];
			i2 = pos[b];
			i3 = pos[c];
			int min_index, mid_index, max_index;
			min_index = Math.min(i1, Math.min(i2, i3));
			max_index = Math.max(i1, Math.max(i2, i3));
			if(min_index < i1 && i1 < max_index)
				mid_index = i1;
			else if(min_index < i2 && i2 < max_index)
				mid_index = i2;
			else
				mid_index = i3;

			int temp = per[max_index];
			per[max_index] = per[mid_index];
			per[mid_index] = per[min_index];
			per[min_index] = temp;

			pos[per[min_index]] = min_index;
			pos[per[mid_index]] = mid_index;
			pos[per[max_index]] = max_index;
			if(pos[c] != c)
				list.addFirst(c);
			if(pos[b] != b)
				list.addFirst(b);
			if(pos[a] != a)
				list.addFirst(a);
			numberofOp.append(min_index).append(" ").append(mid_index).append(" ").append(max_index).append("\n");
			// numberofOp.append(sb.to)
			// numberofOp = numberofOp+min_index+" "+mid_index+" "+max_index+"\n";
			K--;
		}
		if(list.size() == 0){

			int M = orgK - K;
			StringBuilder sb = new StringBuilder();
			sb.append(M).append("\n").append(numberofOp);
			
			return sb;
		}
		StringBuilder ss = new StringBuilder();
		ss.append("-1").append("\n");
		return ss;
	}

	public static void main(String[] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int N = Integer.parseInt(s[0]);
				int K = Integer.parseInt(s[1]);
				s = br.readLine().split(" ");
				int per[] = new int[N+1];
				int pos[] = new int[N+1];
				LinkedList<Integer> list = new LinkedList<Integer>();
				for(int i = 1; i <= N; i++){

					int val = Integer.parseInt(s[i-1]);
					per[i] = val;
					pos[val] = i;
					if(val != i){
						list.add(i);
					}

				}

				if(list.size() <= 2){

					if(list.size() == 0)
					sb.append("0").append("\n");
					else
						sb.append("-1").append("\n");
					continue;
				}

				StringBuilder result = sorthePermutation(per, pos, list, N, K);
				sb.append(result);
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}

	}
}