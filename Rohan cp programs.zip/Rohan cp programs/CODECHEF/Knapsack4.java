import java.util.Scanner;
class Knapsack4{


	private static int fill_Knapsack(int wt[], int v[], int n, int W){

		int dp[][] = new int[2][W+1];
		for(int i = 0; i <= W; i++)
			dp[0][i] = 0;
		dp[1][0] = 0;

		int flag = 1;
		for(int i = 1; i <= n; i++){

			for(int w = 1; w <= W; w++){

				dp[flag][w] = dp[flag ^ 1][w];
				if(w >= wt[i-1])
					dp[flag][w] = Math.max(dp[flag][w], v[i-1] + dp[flag ^ 1][w - wt[i-1]]);
			}
			flag ^= 1;
		}

		return dp[flag ^ 1][W];

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int wt[] = new int[n];
		for(int i = 0; i < n; i++)
			wt[i] = input.nextInt();
		int v[] = new int[n];
		for(int i = 0; i < n; i++)
			v[i] = input.nextInt();
		int W = input.nextInt();
		
		int ans = fill_Knapsack(wt, v, n, W);
		System.out.println(ans);
		
	}
}