import java.util.*;
class Node{
    
    int data;
    int wght;
    public Node(int data, int wght){
        this.data = data;
        this.wght = wght;
    }
}

class Graph{
    
    private LinkedList<Node>[]adjlist;
    public Graph(int V){
    adjlist = new LinkedList[V];
        for(int i = 0; i < V; i++)
            adjlist[i] = new LinkedList<Node>();
    }
    
    public void addEdge(int u, int v, int w){
    
        adjlist[u].add(new Node(v,w));
        adjlist[v].add(new Node(u,w));
    }
    
    private static void printaa(int ar[]){
        for(int a : ar)
            System.out.print(a+" ");
        System.out.println();
    }
    private static void printa2a(boolean v[]){
        for(boolean f : v){
            System.out.print(f+" ");
        }
        System.out.println();
    }
    private static int pickMinimumVertex(int weight[], boolean visited[]){
        int min = Integer.MAX_VALUE;
        int j = min;
        for(int i = 0; i < visited.length; i++){
            if(!visited[i] && min > weight[i]){
                min = weight[i];
                j = i;
            }
        }
        return j;
    }
    
    public void makeMST(int V){
        
        boolean visited[] = new boolean[V];
        int parent[] = new int[V];
        int weight[] = new int[V];
        Arrays.fill(weight,Integer.MAX_VALUE);
        weight[0] = 0;
        parent[0] = -1;
        for(int i = 0; i < V; i++){
        
            int minVertex = pickMinimumVertex(weight, visited);
            
            visited[minVertex] = true;
            for(Node node : adjlist[minVertex]){
                int v2 = node.data;
                int w = node.wght;
                if(!visited[v2]){
                    if(weight[v2] > w){
                        weight[v2] = w;
                        parent[v2] = minVertex;
                    }
                }
            }
            // System.out.println("i = "+i+" , minVertex = "+minVertex);
            // printaa(parent);
        // printaa(weight);
        // printa2a(visited);
        }
        for(int i = 1; i < V; i++){
            System.out.println(Math.min(parent[i],i)+" "+Math.max(parent[i],i)+" "+weight[i]);
        }
    }
}
public class Solution {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int V = s.nextInt();
		int E = s.nextInt();
        Graph g = new Graph(V);
        for(int i = 0; i < E; i++){
            
            int v1 = s.nextInt();
            int v2 = s.nextInt();
            int w = s.nextInt();
            g.addEdge(v1, v2, w);
        }
        g.makeMST(V);
	}
}