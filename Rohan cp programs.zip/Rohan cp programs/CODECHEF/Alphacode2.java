import java.util.Scanner;
class Main{

	private static int FindCode(int arr[], int n){

         int dp[] = new int[n+1];
        int m = (int) Math.pow(10,9) +7;
        dp[0] = dp[1] = 1;
        for(int i = 2; i <=n; i++){
            
            if( arr[i-1]!=0)
            dp[i] = dp[i-1]%m;
            if((arr[i-2] * 10) !=0){
            if((arr[i-2] * 10) + (arr[i-1]) <= 26){
                long a = dp[i];
                long b = dp[i-2];
                int a1 = (int)a%(m);
                int b1 = (int)b%(m);
                dp[i] = (a1+b1)%m;
                
            }}
        }
        return dp[n];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		while(true){

			String s= input.next();
			if( s.equals("0"))
				System.exit(0);
			int arr[] = new int[s.length()];
			String ss[] = s.split("");
			int i = 0;
			for(String a : ss)
				arr[i++] = Integer.parseInt(a);
			int dp[] = new int[s.length()+1];
			int result = FindCode(arr, s.length());
			System.out.println(result);

		}
	}
}