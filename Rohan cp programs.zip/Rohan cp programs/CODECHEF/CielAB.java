import java.util.Scanner;
class CielAB{
	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		int c = a - b;
		if((c+1)%10 == 0)
			System.out.println(c-1);
		else
			System.out.println(c+1);
	}
}