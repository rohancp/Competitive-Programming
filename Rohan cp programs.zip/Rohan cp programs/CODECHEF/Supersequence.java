import java.util.Scanner;
import java.util.Arrays;
class Supersequence{

	private static int find_shortest_sequence(String s, String t, int m,int n, int dp[][]){

		if(m == 0 || n== 0)
			return Math.max(m,n);
		if(dp[m][n] != -1)
			return dp[m][n];
		if(s.charAt(0) == t.charAt(0)){
			dp[m][n] = 1 + find_shortest_sequence(s.substring(1, s.length()), t.substring(1, t.length()), m-1, n-1, dp);
			return dp[m][n];
		}

		int a = find_shortest_sequence(s, t.substring(1, t.length()), m, n-1, dp);
		int b = find_shortest_sequence(s.substring(1, s.length()),t, m-1, n, dp);
		dp[m][n] = 1 + Math.min(a, b);
		return dp[m][n];
	}

	public static void main(String [] ar){

		Scanner input = new Scanner(System.in);
		String s = input.next();
		String t = input.next();
		int m = s.length();
		int n = t.length();
		int dp[][] = new int[m+1][n+1];
		for(int i = 0 ; i <= m; i++)
			Arrays.fill(dp[i], -1);	
		int ans = find_shortest_sequence(s, t, m, n, dp);
		System.out.println(ans);
	}
}