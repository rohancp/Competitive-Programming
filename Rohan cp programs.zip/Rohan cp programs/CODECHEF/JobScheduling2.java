import java.io.*;
import java.util.*;

class Pair implements Comparable<Pair>{

	int start,finish, profit;
	Pair(int s, int f, int p){

		this.start = s;
		this.finish = f;
		this.profit = p;
	}

	public int compareTo(Pair ob){

		return this.finish - ob.finish;
	}
}
class JobScheduling2{

	private static int BinarySearch(int dp[], int l, int h, Vector<Pair> job, int start){

		int index = -1;
		while(l <= h){

			int mid = (l+h)/2;
			if(job.get(mid).finish <= start){

				index = mid;
				l = mid +1;
			}
			else
				h = mid-1;
		}
		return index;
	}


	private static int Max_Profit(Vector<Pair> job, int N){

		int dp_ans[] = new int[N];
		dp_ans[0] = job.get(0).profit;
		for(int i = 1; i < N; i++){

			int include = job.get(i).profit;

			int index = BinarySearch(dp_ans, 0, i, job, job.get(i).start);
			if(index != -1){

				include += dp_ans[index];
			}
			dp_ans[i] = Math.max(include, dp_ans[i-1]);

		}
		return dp_ans[N-1];
	}


	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		Vector<Pair> job = new Vector<Pair>();
		for(int i = 0; i < N; i++){

			String s = br.readLine();
			String b[] = s.split(" ");
			int st =	Integer.parseInt(b[0]);
			int ft = Integer.parseInt(b[1]);
			int p = Integer.parseInt(b[2]);
			job.add(new Pair(st, ft, p));
		}
		Collections.sort(job);
		int result = Max_Profit(job, N);
		System.out.println(result);
	}
}