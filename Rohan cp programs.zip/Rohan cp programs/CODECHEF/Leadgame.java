import java.util.*;
import java.io.*;
import java.lang.*;
class Leadgame{

	public static void main(String []args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			int rohit[] = new int[N];
			int rohan[] = new int[N];
			for(int i = 0; i < N; i++){
				String s[] = br.readLine().split(" ");
				rohit[i] = Integer.parseInt(s[0]);
				rohan[i] = Integer.parseInt(s[1]);
			}
			long winRohit = 0;
			long winRohan = 0;
			int rohan_leader,rohit_leader;
			rohan_leader = rohit_leader = 0;
			for(int i = 0; i < N; i++){
				winRohit += rohit[i];
				winRohan += rohan[i];
				if(winRohit > winRohan){

						if(rohit_leader < (winRohit - winRohan))
							rohit_leader =(int) (winRohit - winRohan);
				}else{
					if(rohan_leader < (winRohan - winRohit))
						rohan_leader = (int)(winRohan - winRohit);
				}
			}
			if(rohit_leader > rohan_leader){
				System.out.println("1 "+rohit_leader);
			}
			else{
				System.out.println("2 "+rohan_leader);
			}
		}
		catch(Exception e){
			return ;
		}
	}
}