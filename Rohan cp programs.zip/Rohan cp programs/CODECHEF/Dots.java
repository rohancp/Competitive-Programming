import  java.util.Scanner;
class Dots{

	static int temp[][] = {{-1,0},{0,-1},{0,1},{1,0}};
    static boolean visited[][];
    
    private static boolean helper(String board[], int row, int col, int i, int j, int k, char ch){
        
        // System.out.print("   "+row+" "+col+" ");
        if(row == i && col == j && k>=4 && visited[row][col] && ch == board[row].charAt(col))return true;
        
        if(row < 0 || col < 0 || row>=board.length || col>=board[0].length()||visited[row][col]
          || ch != board[row].charAt(col))return false;
        
        
        visited[row][col] = true;
        // System.out.println(row+" "+col+ board[row].charAt(col));
        for(int l = 0; l < temp.length; l++){
            int r,c;
            r = row+temp[l][0];
            c = col+temp[l][1];
            // System.out.print(r+" "+c+"   ");
            if(helper(board, r,c,i,j,k+1,ch))return true;
        }
        visited[row][col] = false;
        return false;
    }
	
	private static int solve(String[] board , int n, int m)
	{
        visited = new boolean[n][m];
        for(int i = 0; i < n; i++){
            
            for(int j = 0; j < m; j++){
                
                if(helper(board,i,j,i,j,0,board[i].charAt(j)))return 1;
            }
        }
        return 0;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int m = input.nextInt();
		String board[] = new String[n];
		for(int i = 0; i < n; i++){
			board[i] = input.next();
		}
		System.out.println(solve(board, n, m));
	}
}