import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.ArrayList;
class LongestConsecutiveSubsequence{

	private static ArrayList<Integer> longestSubsequence(int arr[], int N){

		HashSet<Integer> set = new HashSet<>();
		for(int i = 0; i < N; i++)
			set.add(arr[i]);
		int max = 0;
		ArrayList<Integer> result = new ArrayList<Integer>();
		
		for(int i = 0 ; i < N; i++){
			

			if(!set.contains(arr[i]-1)){
				int current_max = 0;
			ArrayList<Integer> al = new ArrayList<>();
				int a = arr[i];
				while(set.contains(a)){
					al.add(a);
					current_max++;
					a++;
				}
				if(current_max > max){

					result  = al;
					max = current_max;
				}
			}
		}
		
		return result;


	}

		public static void main(String [] args)throws IOException{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int size = Integer.parseInt(br.readLine());
			String s[] = br.readLine().trim().split("\\s+");
			int i = 0;
			int arr[] = new int[size];
			for(String ele : s)
				arr[i++] = Integer.parseInt(ele);
			ArrayList<Integer> result = longestSubsequence(arr, size);
			Collections.sort(result);
			for(int a : result)
				System.out.print(a+" ");
			System.out.println();
		}
}