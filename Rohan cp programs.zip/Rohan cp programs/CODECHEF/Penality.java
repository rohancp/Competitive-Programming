import java.util.*;
import java.io.*;
import java.lang.*;
class Penality{


	private static int winningTeam(int arr[], int n){

		int agoal,bgoal;
		agoal = bgoal = 0;
		int teamA,teamB;
		teamA = teamB = n;
		int i = 0;
		boolean flag = true;
		for(; i < arr.length; i++){

				if(i %2 == 0){
					agoal = agoal + arr[i];
					teamA--;
				}
				else{
					bgoal = bgoal + arr[i];
					teamB--;
				}
				if(agoal > (bgoal+teamB) || bgoal > (agoal+teamA)){
					return i+1;
					// break;
				}
		}
		return  i;
	}

	public static void main(String [] args){

		try{
			StringBuilder sb = new StringBuilder();
			Scanner input = new Scanner(System.in);
			int tc = input.nextInt();
			while(tc-- > 0)
			{

				int n = input.nextInt();
				String s[] = input.next().split("");
				int arr[] = new int[2*n];
				for(int i = 0; i < s.length; i++){

					arr[i] = Integer.parseInt(s[i]);
				}
				int ans = winningTeam(arr, n);
				sb.append(ans+"\n");
			}
			System.out.println(sb.toString());

		}
		catch(Exception e){
			return ;
		}
	}
}