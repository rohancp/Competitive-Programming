import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;
class MarcCakewalk{

	private static long Find(Integer arr[], int n){

		Arrays.sort(arr,Collections.reverseOrder());

		long sum = 0;
		for(int i = 0; i < n; i++){

			sum = sum +(arr[i]*(int)Math.pow(2,i));
		}
		return sum;

	}


	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		Integer arr[] = new Integer[N];
		for(int i = 0; i < N; i++)
			arr[i] = input.nextInt();
		long result = Find(arr, N);
		System.out.println(result);
	}
}