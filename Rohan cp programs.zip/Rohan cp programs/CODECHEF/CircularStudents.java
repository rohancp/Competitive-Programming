import java.util.Scanner;
class CircularStudents{

	public static void main(String[] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int i = input.nextInt();
			int p = input.nextInt();
			System.out.println((i+p)%12);
		}
	}
}