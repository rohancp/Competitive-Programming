import java.util.Scanner;
class Staircasedp{

	private static long Stair(long dp[], int n){

		if(n < 0)
			return 0;
		if( n == 0 || n == 1)
			return 1;
		if(dp[n] != 0)
			return dp[n];
		long output = Stair(dp, n-1) + Stair(dp, n-2) + Stair(dp, n-3);
		dp[n] = output;
		return output;
	}

	private static long Stair2(int n){

		long dp[] = new long[n+1];
		dp[0] = 1;
		dp[1] = 1;
		dp[2] = 2;

		for(int i = 3; i <= n; i++){

			dp[i] = dp[i-1] + dp[i-2] + dp[i-3];
		}
		return dp[n];

	}
	public static void main(String []args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		long arr[] = new long[n+1];
		long result = Stair(arr, n);
		System.out.println(result);
		System.out.println(Stair2(n));
		

	}
}