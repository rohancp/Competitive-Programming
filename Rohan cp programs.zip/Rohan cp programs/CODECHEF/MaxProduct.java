import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class MaxProduct{


	private static int maxSubarrayProduct(int arr[], int size){

		int current_product = 1;
		int maximum_product = 1;
		for(int i = 0; i < size; i++){

				current_product *= arr[i];
				if(current_product > maximum_product)
					maximum_product = current_product;
				if(current_product == 0)
					current_product = 1;
		}
		return maximum_product;


	}

	public static void main(String[]args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int size = Integer.parseInt(br.readLine());
		int arr[] = new int[size];
		String s[] = br.readLine().trim().split("\\s+");
		int i = 0;
		for(String a : s)
			arr[i++] = Integer.parseInt(a);
		int result = maxSubarrayProduct(arr, size);
		System.out.println(result);

	}
	
}