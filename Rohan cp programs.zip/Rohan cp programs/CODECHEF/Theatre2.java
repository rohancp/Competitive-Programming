import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.*;
class Theatre2{


	private static int getMovieIndex(String movie){

		switch(movie){

			case "A": return 0;
			case "B": return 1;
			case "C":return 2;
			default : return 3;
		}
	}

	private static int getShowtimeIndex(int showtime){

		switch(showtime){

			case 12 : return 0;
			case 3 : return 1;
			case 6 : return 2;
			default : return 3;
		}
	}

	private static ArrayList<Integer> getMaxProfit(int arr[][]){
		int sum = 0;
		boolean movies[] = new boolean[4];
		boolean showtime[] = new boolean[4];
		Arrays.fill(movies, false);
		Arrays.fill(movies, false);
		int price[] = {100,75,50,25};
		int k = 0;
		while(true && (k < 4)){
			int movieindex,showtimeindex,count;
			movieindex = showtimeindex = -1;
			count = 0;
			for(int i = 0; i < 4; i++){
				if(movies[i]){
					continue;
				}
				for(int j =0; j < 4; j++){
					if(showtime[j]){
						continue;
					}
					if(count < arr[i][j]){
						movieindex = i;
						showtimeindex = j;
						count = arr[i][j];
					}
				}
			}
			if(movieindex == -1)break;
			movies[movieindex] = true;
			showtime[showtimeindex] = true;
			sum = sum + (count*price[k++]);
		}
		ArrayList<Integer> list = new ArrayList<>();
		list.add(sum);
		list.add(k);
		return list;
	}
	public static void main(String args[])throws IOException{

			try{
		StringBuilder sb = new StringBuilder();
		BufferedReader br  = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		int totalp = 0;
		// BigInteger totalp  = new BigInteger("0");
		while(tc-- > 0){
			int arr[][] = new int[4][4];
			int N = Integer.parseInt(br.readLine());
			while(N-- > 0){
			String input[] = br.readLine().split(" ");
			int row = getMovieIndex(input[0]);
			int col = getShowtimeIndex(Integer.parseInt(input[1]));
			arr[row][col] = arr[row][col]+1;
			}
			ArrayList<Integer> ans = getMaxProfit(arr);
			int result = ans.get(0);
			int watchmovies = ans.get(1);
			if(watchmovies < 4){
				watchmovies = 4-watchmovies;
				result = result -(watchmovies*100);
			}
			totalp = totalp+result;
			System.out.println(result);
		}
		System.out.println(totalp);
		// sb.append(totalp);
		// System.out.println(sb.toString());
	}catch(Exception e){
		return ;
	}
	}
}