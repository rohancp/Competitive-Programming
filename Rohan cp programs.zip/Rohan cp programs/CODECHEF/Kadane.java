import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Kadane{


	private static int LargestSum(int arr[], int n){

		int current_max = 0;
		int best_max = 0;
		for(int i = 0; i < n; i++)
		{
			current_max += arr[i];
			if(current_max < 0)
				current_max = 0;
			else if(current_max > best_max)
				best_max = current_max;
		}
		return best_max;

	}

	public static void main(String []args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int size = Integer.parseInt(br.readLine());
		int arr[] = new int[size];
		String s[] = br.readLine().trim().split("\\s+");
		int i = 0;
		for(String a : s)
			arr[i++] = Integer.parseInt(a);
		int result = LargestSum(arr, size);
		System.out.println(result);


	}
}