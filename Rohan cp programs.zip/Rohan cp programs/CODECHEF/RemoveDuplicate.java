import java.util.Scanner;
class RemoveDuplicate{

	private static String removeConsecutiveDuplicates(String s){

		if(s.length() == 1)
			return s;
		char ch[] = s.toCharArray();
		if(ch[0] == ch[1]){
			s = s.substring(1,s.length());
			return removeConsecutiveDuplicates(s);
		}
		String small = s.substring(0,1);
		String l = removeConsecutiveDuplicates(s.substring(1,s.length()));
		return (small + l);
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		String s = input.next();
		String result = removeConsecutiveDuplicates(s);
		System.out.println(result);

	}
}