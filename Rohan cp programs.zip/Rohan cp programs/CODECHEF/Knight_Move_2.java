import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Knight_Move_2
{

	static int Row[] = {-1,1,2,2,1,-1,-2,-2};

	static int Col[] = {-2,-2,-1,1,2,2,-1,1};

	//Find Correct position in Chess Board.....

	public static int Correct_Position(int board[][], int size, int row, int col)
	{
		
		if(row>=0 && row<size && col>=0 && col<size && board[row][col] == -1)
			return 1;
		return 0;
	}

	//Show Or Display Chess Board...

	public static void Show_Board(int board[][], int size)
	{

			System.out.println();
			for(int i = 0;i<size;i++)
			{
				for(int j = 0;j<size;j++)
					System.out.print(board[i][j]+" ");
				System.out.println();
			}
			return ;
	}

	//Knight Moving Method........

		public static int Correct_Move(int board[][], int size, int move_no, int row, int col)
		{

			if(move_no - 1 == size*size)
			{
				Show_Board(board,size);
				return 1;
			}

			for(int i = 0;i<8;i++)
			{
				int a_r = row + Row[i];
				int b_c = col + Col[i];
				if(Correct_Position(board,size,a_r, b_c) == 1)
				{
					board[a_r][b_c] = move_no;

					if(Correct_Move(board, size, move_no + 1,a_r, b_c) == 1)
							return 1;
					else
						board[a_r][b_c] = -1;
				}
			}

				return 0;
		}


		//Main Method....

	public static void main(String[]args)throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the size of the Chess Board: ");
		
		int N = Integer.parseInt(br.readLine());

		if(N<5)
		{
			System.out.println("Knight can't Move!!..."+"\n"+"Bye Bye!!...");
			return ;
		}
		int board[][] = new int[N][N];

		//Initialization.....

		for(int i = 0;i<N;i++)
		{

			for(int j = 0;j<N;j++)
				board[i][j] = -1;
		}		
		board[0][0] = 1;
		Correct_Move(board, N, 2, 0, 0);
	}
}