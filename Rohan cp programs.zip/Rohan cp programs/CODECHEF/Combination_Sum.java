import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Iterator;
class Combination_Sum{

	// static int count = 0;

	static LinkedHashSet<String> hs = new LinkedHashSet<String>();
	// print List..

	public static void Print_List(Vector<Integer> vec)
	{

		StringBuffer sb = new StringBuffer();
		sb.append("(");
		for(int i = 0;i<vec.size();i++)
		{
			String a = Integer.toString(vec.get(i));
			sb.append(a);
			if(i!=vec.size()-1)
				sb.append(" ");
		}
		sb.append(")");
		hs.add(sb.toString());

	}

	//find combination...

	public static void Combination(Vector<Integer> vec, int arr[], int index, int Sum, int val)
	{
		// System.out.print("Rohan");
			if(Sum > val || index>=arr.length)
				return ;
			if(val == Sum)
			{
				// count++;
				Print_List(vec);
				return ;
			}
			Sum = Sum + arr[index];
			if(Sum>val)
			{
				Sum = Sum - arr[index];
				return ;
			}
			vec.add(arr[index]);

			// call Recursion..

			Combination(vec, arr, index, Sum, val);

			Sum = Sum - arr[index];  //Backtrack...
			vec.remove(vec.size()-1);

			//call again Recursion...

			Combination(vec, arr, index + 1, Sum, val);
			return ;

	}

	//this is main method.....

	public static void main(String[]args)throws IOException
	{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-->0)
		{

			int N = Integer.parseInt(br.readLine());
			int arr[] = new int[N];
			String line = br.readLine();
			String s[] = line.trim().split("\\s+");
			for(int i = 0;i<N;i++)
				arr[i] = Integer.parseInt(s[i]);
			Arrays.sort(arr);
			int Sum = Integer.parseInt(br.readLine());

			Vector<Integer> vec = new Vector<Integer>();
			Combination(vec, arr, 0, 0, Sum);
			if(hs.size() == 0)
				System.out.print("Empty");
			else
			{
				Iterator<String> it = hs.iterator();
				while(it.hasNext())
					System.out.print(it.next());
				hs.removeAll(hs);
			}
			System.out.println();
		}
	}
}