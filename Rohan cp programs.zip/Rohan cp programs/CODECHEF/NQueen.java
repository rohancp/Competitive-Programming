import java.util.Scanner;
public class NQueen {
        
    private static boolean Find_correct_position(int chessboard[][], int n, int row, int col){
        
            //check vertical..
        
            for(int i = row - 1; i >= 0; i--){
                
                if(chessboard[i][col] == 1)
                    return false;
            }
        //check left diagonal..
        
        int i = row - 1;
        int j = col - 1;
        while( (i >= 0) && (j >=  0))
        {
            if(chessboard[i][j] == 1)
                return false;
            i--;j--;
            
        }
        
        //check right diagonal..
        i = row - 1;
        j = col +1;
        
        while( i >= 0 && j < n){
            
            if(chessboard[i][j] == 1)
                return false;
            i--;j++;
        }
        
        return true;
        
    }
    
    private static void printSolution(int chessboard[][], int n){
        
        
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
                System.out.print(chessboard[i][j]+" ");
        }
        System.out.println();
    }
    
    public static void Find_All_Position(int chessboard[][], int row , int n){
        
        if(row == n)
        {
            printSolution(chessboard,n);
            return ;
        }
        for(int col = 0; col < n ; col++){
            
            boolean position = Find_correct_position(chessboard, n, row, col);
            if(position){
                chessboard[row][col] = 1;
                Find_All_Position(chessboard, row+1, n);
                chessboard[row][col] = 0;
            }
        }
    }
	
public static void placeNQueens(int n){
		
	if( n ==1 || n == 2 || n ==  3)
        return ;
    int chessboard[][] = new int[n][n];
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            chessboard[i][j] = 0;
    }
    Find_All_Position(chessboard, 0, n);
  
	}	
    public static void main(String [] args){

    Scanner input = new Scanner(System.in);
    int n = input.nextInt();
    placeNQueens(n);

    }
}
