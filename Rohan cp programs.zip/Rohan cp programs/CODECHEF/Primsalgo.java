import java.util.Scanner;
import java.util.Arrays;
class Graph{

	int edges[][];
	public Graph(int V){
		edges = new int[V][V];
	}

	public void add_Edge(int fv, int sv, int weight){
		edges[fv][sv] = weight;
		edges[sv][fv] = weight;
	}

	public int get_min_vertex(boolean visited[], int weight[], int V){

		int minvertex = -1;
		for(int i = 0; i < V; i++){
			if(!visited[i] && (minvertex == -1 || weight[minvertex] > weight[i]))
				minvertex = i;
		}
		return minvertex;
	}

	public void print_edge(int src, int des, int weight){

		System.out.println(src+" "+des+" "+weight);
	}
	public void find_Mst(int V){
		int parent[] = new int[V];
		int weight[] = new int[V];
		boolean visited[] = new boolean[V];
		Arrays.fill(visited, false);
		Arrays.fill(weight, Integer.MAX_VALUE);
		weight[0] = 0;
		parent[0] = -1;
		for(int i = 0; i < V-1; i++){
			int minvertex = get_min_vertex(visited, weight, V);
			visited[minvertex] = true;
			for(int j = 0 ; j < V; j++){
				if(edges[minvertex][j] != 0 && !visited[j]){
					if(weight[j] > edges[minvertex][j]){
						weight[j] = edges[minvertex][j];
						parent[j] = minvertex;
					}
				}
			}
		}

		for(int i =1; i < V; i++){
			if(parent[i] < i)
				print_edge(parent[i], i, weight[i]);
			else
				print_edge(i, parent[i], weight[i]);
		}
	}
}
class Primsalgo{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			int w = input.nextInt();
			g.add_Edge(fv, sv, w);
		}
		g.find_Mst(V);

	}
}