import java.util.Scanner;
import java.util.Arrays;
class Interstingsequence{
	private static int Minimum_Cost(int arr[], int k, int l, int n){
		int min = Integer.MAX_VALUE;
		Arrays.sort(arr);
		int a,b;
		a = arr[0];
		b = arr[n-1];
		for(; a <= b; a++){
			int inc = 0;
			int dec = 0;
			for(int i = 0; i < n; i++){

				if(arr[i] < a){
					inc = inc + Math.abs(arr[i] - a);
				}
				else if(arr[i] > a){
					dec = dec + Math.abs(arr[i] - a);
				}
			}
			if(dec > inc)
				continue;
			int cost = (dec*k) + (inc - dec) * l;
			min = Math.min(cost, min);
		}
		return min;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int k = input.nextInt();
		int l = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		int result = Minimum_Cost(arr, k, l, n);
		System.out.println(result);

	}
}