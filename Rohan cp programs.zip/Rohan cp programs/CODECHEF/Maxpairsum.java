import java.util.Scanner;
class Node{

	long max_pair_sum, so_far_max;
	Node(long x, long y){
		this.max_pair_sum = x;
		this.so_far_max = y;
	}
}
class Maxpairsum{

	private static void build_tree(int arr[],Node tree[], int treenode, int start, int end){

		if(start == end){
			tree[treenode] = new Node(0, arr[start]);
			return ;
		}
		int mid = (start+end)/2;
		build_tree(arr, tree, 2*treenode, start, mid);
		build_tree(arr, tree, (2*treenode)+1, mid+1, end);

		long max_pair_1 = (tree[2*treenode].so_far_max) + (tree[(2*treenode)+1].so_far_max);
		long max_pair_2 = Math.max(tree[2*treenode].max_pair_sum, tree[(2*treenode)+1].max_pair_sum);
		long max_ele = Math.max(tree[2*treenode].so_far_max , tree[(2*treenode)+1].so_far_max);
		tree[treenode] = new Node(Math.max(max_pair_1, max_pair_2), max_ele);

	}

	private static void update_tree(int arr[], Node tree[], int treenode, int start, int end, int idx, int value){

		if(start == end){
			arr[start] = value;
			tree[treenode].so_far_max = value;
			return ;
		}
		int mid = (start+end)/2;
		if(idx <= mid)
			update_tree(arr, tree, 2*treenode, start, mid, idx, value);
		else
			update_tree(arr, tree, (2*treenode)+1, mid+1, end, idx, value);

		long max1 = tree[2*treenode].so_far_max + tree[(2*treenode)+1].so_far_max;
		long max2 = Math.max(tree[2*treenode].max_pair_sum, tree[(2*treenode)+1].max_pair_sum);
		long max3 = Math.max(max1, max2);
		long max_ele = Math.max(tree[2*treenode].so_far_max , tree[(2*treenode)+1].so_far_max);

		tree[treenode].so_far_max = max_ele;
		tree[treenode].max_pair_sum = max3;
	}

	private static Node find_max_Pair(Node tree[], int treenode, int start, int end, int l, int r){

		if(end < l || start > r)
			return null;
		if(start >= l && end <= r)
			return tree[treenode];
		int mid = (start + end)/2;
		Node ans1 = find_max_Pair(tree, (2*treenode), start, mid, l, r);
		Node ans2 = find_max_Pair(tree, (2*treenode)+1, mid+1, end, l, r);
		if(ans1 != null && ans2 != null){

			long max1 = ans1.so_far_max + ans2.so_far_max;
			long max2 = Math.max(ans1.max_pair_sum, ans2.max_pair_sum);
			long max3 = Math.max(max1, max2);
			long max_ele = Math.max(ans1.so_far_max , ans2.so_far_max);
			Node ans;
			ans = new Node(max3, max_ele);
			return ans;
		}
		else if(ans1 != null)
			return ans1;
		return ans2;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		Node tree[] = new Node[4*n];
		build_tree(arr, tree, 1, 0, n-1);	
		int query = input.nextInt();
		while(query-- > 0){

			char q_type = input.next().charAt(0);
			if(q_type == 'Q'){

				int l = input.nextInt()-1;
				int r = input.nextInt()-1;
				Node ans = find_max_Pair(tree, 1, 0, n-1, l, r);
				System.out.println(ans.max_pair_sum);
			}
			else{

				int idx = input.nextInt()-1;
				int value = input.nextInt();
				update_tree(arr, tree, 1, 0, n-1, idx, value);
			}
		}

	}
}