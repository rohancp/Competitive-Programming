import java.util.Scanner;
import java.util.Arrays;
class Connectingdots{
	static char ch[][];
	static int N,M;
	static boolean visited[][];
	private static boolean find_cycle(int row, int col, int i, int j, int k, char s){
		// System.out.println(row+" "+col);
		if(row == i && col == j && k >= 3 && visited[row][col] && s == ch[row][col]){
			// System.out.println("Rohan "+row+" "+col+" "+k);
			return true;
		}
		if(row < 0 || row >= N || col >= M || col < 0 || visited[row][col] || s != ch[row][col])
			return false;
		if(s == ch[row][col]){
			visited[row][col] = true;
			// System.out.println(row+" "+col);
			if(find_cycle(row, col+1, i, j, k+1, s))
				return true;
			if(find_cycle(row+1, col, i, j, k+1, s))
				return true;
			if(find_cycle(row, col-1, i, j, k+1, s))
				return true;
			if(find_cycle(row-1, col, i, j, k+1, s))
				return true;
			visited[row][col] = false;
		}
		return false;
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		N = input.nextInt();
		M = input.nextInt();
		ch = new char[N][M];
		visited = new boolean [N][M];
		for(int i = 0; i < N; i++){
			String s = input.next();
			ch[i] = s.toCharArray();
		}
		for(int i = 0; i < N; i++)
			Arrays.fill(visited[i], false);
		for(int i = 0; i < N; i++){
			for(int j = 0; j < M; j++){
				boolean result = find_cycle(i, j, i, j, 0, ch[i][j]);
				if(result){
					// System.out.println(i+" "+j);
					System.out.println(1);
					System.exit(0);
				}
			}
		}
		System.out.println(0);
	}
}