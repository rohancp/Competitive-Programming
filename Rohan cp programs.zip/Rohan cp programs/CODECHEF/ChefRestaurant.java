import java.util.Scanner;
import java.util.Vector;
import java.util.Collections;
import java.util.Comparator;
class Pair{

	int first,second;

	public Pair(int x, int y){

		this.first = x;
		this.second = y;
	}

}
class Compare{

	public static void compare(Vector<Pair> intervals){

		Collections.sort(intervals, new Comparator<Pair>(){

			public int compare(Pair ob1, Pair ob2){


				return ob1.first - ob2.first;
			}
		});
	}
}

class ChefRestaurant{

	private static int Lower_bound(Vector<Pair> vec, int low , int high, int value){

		while(low < high){

			int mid = (low+high)/2;
			if(value <= vec.get(mid).first)
					high = mid;
			else
				low = mid+1;
		}
		return low;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int N = input.nextInt();
			int M = input.nextInt();
			Vector<Pair> intervals = new Vector<Pair>();
			while(N-- > 0){
				int first = input.nextInt();
				int second = input.nextInt();
				Pair p = new Pair(first, second);
				intervals.add(p);
			}
			Compare cmp = new Compare();
			cmp.compare(intervals);
			
			while(M-- > 0){

				int value = input.nextInt();
				int position = Lower_bound(intervals, 0, intervals.size(), value);
				if(position == 0 ){
						System.out.println(intervals.get(position).first - value);
				}
				else{

					int ans = -1;
					System.out.println(position);
					if(intervals.get(position-1).second > value)
						ans = 0;
					else if(intervals.size() > position)
						ans = intervals.get(position).first - value;
					// else if(intervals.get(position-1).second > value)
					// 	ans = 0;
					System.out.println(ans);
				}
			
			}
		}
	}
}