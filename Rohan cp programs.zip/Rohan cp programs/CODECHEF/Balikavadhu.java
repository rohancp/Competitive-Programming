import java.util.Scanner;
import java.util.Arrays;
class Balikavadhu{

	private static int blessings(String s1, String s2, int k, int sum, int i){

		if(k == i)
			return sum;

		if(s1.isEmpty() || s2.isEmpty())
			return 0;

		if(s1.charAt(0) == s2.charAt(0)){

			int op1 = blessings(s1.substring(1,s1.length()), s2.substring(1, s2.length()), k, sum + s1.charAt(0), i+1);
			int op2 = blessings(s1.substring(1,s1.length()), s2.substring(1, s2.length()), k, sum, i);
			return Math.max(op1, op2);
		}
		int op1 = blessings(s1, s2.substring(1, s2.length()), k, sum, i);
		int op2 = blessings(s1.substring(1, s1.length()), s2, k, sum, i);
		return Math.max(op1, op2);
	}


	private static int vadhu(String s1, String s2, int k, int dp[][][], int m, int n){

		if(k == 0)
			return 1;
		if(m == 0 || n == 0 || s1.length() < k || s2.length() < k)
			return 0;
        if(dp[m][n][k] != -1 )
            return dp[m][n][k];
		if(s1.charAt(0) == s2.charAt(0))
		{
			int op1 = vadhu(s1.substring(1, s1.length()), s2.substring(1, s2.length()), k-1 , dp, m-1, n-1);
			int op2 = vadhu(s1.substring(1, s1.length()), s2.substring(1, s2.length()), k, dp, m-1, n-1);
			if(op1 != 0)
			{
				if(op1 != 1)
					op1 += s1.charAt(0);
				else
					op1 = s1.charAt(0);
			}
			dp[m][n][k] = Math.max(op1, op2);
            
			return dp[m][n][k];
		}
		int op1 = vadhu(s1, s2.substring(1, s2.length()), k, dp, m, n-1);
		int op2 = vadhu(s1.substring(1, s1.length()), s2, k, dp, m-1, n);
		dp[m][n][k] = Math.max(op1, op2);
		return dp[m][n][k];
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			String s1 = input.next();
			String s2 = input.next();
			int k = input.nextInt();
			int m = s1.length();
			int n = s2.length();
			int dp[][][] = new int[m+1][n+1][k+1];
			for(int i = 0; i <= m; i++){

					for(int j = 0; j <= n; j++)
						Arrays.fill(dp[i][j],-1);
				}
			int ans = vadhu(s1, s2, k, dp, m, n);
			System.out.println(ans);
			
		}
	}
}