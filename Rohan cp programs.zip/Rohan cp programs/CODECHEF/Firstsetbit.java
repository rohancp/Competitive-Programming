import java.util.Scanner;
class Firstsetbit{

	private static int FindSetBit(int N){

		int i = 0;
		int v = 0;
		while(v == 0){

			v = N&(1<<i);
			i++;

		}

		return v;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int result = FindSetBit(N);
		System.out.println(result);

	}
}