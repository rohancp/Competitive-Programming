import java.util.Scanner;
import java.util.Arrays;
class Distnictsubsequence{

	public static int find_distnict(String str){

		int dp1[] = new int[256];
		int n = str.length();
		int dp2[] = new int[n+1];
		Arrays.fill(dp1, -1);
		final int MOD = (int)Math.pow(10,9)+7;
		dp2[0] = 1;
		for(int i = 1; i <= n; i++){

				long x1 =(long) (2 * dp2[i-1]);
			dp2[i] = (int)(x1%MOD);
			if(dp1[str.charAt(i-1)] != -1){
				int v = (dp2[i] - dp2[dp1[str.charAt(i-1)]])%MOD;
				if(v < 0)
					dp2[i] = ((v%MOD)+MOD)%MOD;
				else
					dp2[i] = v;
			}
			dp1[str.charAt(i-1)] = (i-1);
		} 
		return dp2[n];
	}

	public static void main(String [] ar){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			String s = input.next();
			int ans = find_distnict(s);
			System.out.println(ans);
		}
	}
}