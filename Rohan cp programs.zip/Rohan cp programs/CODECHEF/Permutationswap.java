import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Iterator;
class Graph{

	LinkedList<Integer> adjlist[];
	public Graph(int V){
		adjlist = new LinkedList[V+1];
		for(int i = 0; i <= V; i++)
			adjlist[i] = new LinkedList<>();
	}

	public void add_edge(int fv, int sv){

		adjlist[fv].add(sv);
		adjlist[sv].add(fv);
	}

	public void dfs(HashSet<Integer> component, int src, boolean visited[]){

		visited[src] = true;
		component.add(src);
		for(int u : adjlist[src]){
			if(!visited[u])
				dfs(component, u, visited);
		}
	}

	public HashSet<HashSet<Integer>> get_components(int n){
		boolean visited[] = new boolean[n+1];
		Arrays.fill(visited, false);
		HashSet<HashSet<Integer>> output = new HashSet<>();
		for(int i = 1; i <= n; i++){

			if(!visited[i]){
				HashSet<Integer> component = new HashSet<>();
				dfs(component, i, visited);
				output.add(component);
			}
		}
		return output;
	}

	public boolean p_to_q(HashSet<HashSet<Integer>> component, int Q[], int P[]){

		Iterator<HashSet<Integer>> it = component.iterator();
		while(it.hasNext()){

			HashSet<Integer> set_values = new HashSet<>();
			HashSet<Integer> set = new HashSet<>();
			set = it.next();
			Iterator<Integer> it2 = set.iterator();
			while(it2.hasNext()){
			set_values.add(P[it2.next()]);
			}
			it2 = set.iterator();
			while(it2.hasNext()){
				int ele = Q[it2.next()];
				if(!set_values.contains(ele))
					return false;
			}
		}
		return true;
	}
}
class Permutationswap{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){
			int V = input.nextInt();
			int E = input.nextInt();
			int P[] = new int[V+1];
			for(int i = 1; i <= V; i++)
				P[i] = input.nextInt();
			int Q[] = new int[V+1];
			for(int i = 1; i <= V; i++)
				Q[i] = input.nextInt();
			Graph g = new Graph(V);
			for(int i = 0; i < E; i++){

				int fv = input.nextInt();
				int sv = input.nextInt();
				g.add_edge(fv, sv);
			}
			HashSet<HashSet<Integer>> component = g.get_components(V);
			boolean result = g.p_to_q(component, Q, P);
			if(result)
				System.out.println("YES");
			else
				System.out.println("NO");
		}
	}
}