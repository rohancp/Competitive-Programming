import java.util.Scanner;
import java.util.Map;
import java.util.Vector;
import java.util.HashMap;
class PalindromeString{

	private static void CheckPalindromeString(String ss){

		char ch[] = ss.toCharArray();
		Map<Character, Vector<Integer>> map = new HashMap<>();
		int N = ss.length();
		for(int i = 0; i < N; i++){

			if(map.containsKey(ch[i])){
				Vector<Integer> vec = map.get(ch[i]);
				vec.add(i);
				map.put(ch[i],vec);
			}
			else{
				Vector<Integer> vec = new Vector<Integer>();
				vec.add(i);
				map.put(ch[i],vec);
			}

		}
			int count = 0;

		for(Map.Entry<Character, Vector<Integer>> t : map.entrySet()){

			Vector<Integer> vec = t.getValue();
			if(vec.size()%2 != 0){
				count++;
			}
			if(count == 2){

				System.out.println("-1");
				return ;
			}

		}

		int arr[] = new int[N];
		int s = 0, l = N -1;
		for(Map.Entry<Character, Vector<Integer>> m : map.entrySet()){

			Vector<Integer> vec = m.getValue();
			int i = 0;
			if(vec.size()%2 != 0){

				arr[N/2] = vec.get(0);
				i++;
			}
			for(; i < vec.size(); )
			{
				arr[s] = vec.get(i);
				arr[l] = vec.get(i+1);
				i = i+2;
				s++;l--;
			}
		}
		for(int i = 0 ; i < N; i++)
		{
			System.out.print((arr[i]+1)+" ");
		}
	}

	public static void main(String[]args){

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- >  0){

			String s = input.next();
			CheckPalindromeString(s);

		}
	}
}