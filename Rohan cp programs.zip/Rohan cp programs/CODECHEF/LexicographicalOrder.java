import java.util.Scanner;
class LexicographicalOrder{

	private static int count = 0;

	private static void Find_L_O(String ans, int n){

		if (count == n) {
				
				return ;
		}
		System.out.println(ans);
		count++;
		for(int i = 0; i <= 9; i++){

			if(Integer.parseInt(ans + Integer.toString(i)) <= n)
				Find_L_O(ans + Integer.toString(i), n);
			else
				return ;
			
		}

	}


	private static void lexicographicalOrder(int num){

		for(int i = 1; i <= 9; i++)
		{

			Find_L_O(Integer.toString(i), num);
		}
		

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();

		lexicographicalOrder(n);

	}
}