import java.util.Scanner;
class Turnoff{
	private static int Find(int N){
		int i = 0;
		int v = 0;
		while( v == 0)
		{
			v = N&(1<<i);
			i++;
		}
		v = v ^ N;
		return v;
	}
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int result = Find(N);
		System.out.println(result);

	}
}