import java.util.*;
import java.io.*;
import java.lang.*;
class ListofBooks{

	public static void main(String [] args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int M = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int N = Integer.parseInt(br.readLine());
			LinkedList<Integer> listofBooks = new LinkedList<Integer>();
			for(int i = 0; i < M; i++){
				listofBooks.add(Integer.parseInt(s[i]));
			}
			for(int i = 0; i < N; i++){
			int r_index = Integer.parseInt(br.readLine())-1;
			System.out.println(listofBooks.remove(r_index));
			}
		}catch(Exception e){
			return ;
		}
	}
}