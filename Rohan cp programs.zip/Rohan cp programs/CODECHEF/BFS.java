import java.util.Scanner;
import java.util.Arrays;
import java.util.Queue;
import java.util.LinkedList;
class Graph{

	int adjmat[][];
	public Graph(int V){
		adjmat = new int[V][V];
	}
	public void AddEdge(int fv, int sv){

			adjmat[fv][sv] = 1;
			adjmat[sv][fv] = 1;
		}
		public int[][] AdjancyMatrix(){
			return adjmat;
		}
}

class BFS{

	private static void print_path(int adjmat[][], int src, int n){

		boolean visited[] = new boolean[n];
		Arrays.fill(visited, false);
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(src);
		visited[src] = true;
		while(!queue.isEmpty()){
			int v = queue.poll();
			System.out.print(v+" ");
			for(int i = 0; i < n; i++){
				if(adjmat[v][i] == 1 && !visited[i]){
					queue.add(i);
					visited[i] = true;
				}
			}
		}
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.AddEdge(fv, sv);
		}
		print_path(g.AdjancyMatrix(), 0, V);

	}
}