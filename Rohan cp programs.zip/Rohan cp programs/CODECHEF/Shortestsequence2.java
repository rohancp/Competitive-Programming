import java.util.Scanner;
class Shortestsequence2{

	private static int solve(String s, String t){
		int m = s.length();
		int n = s.length();
		int dp[][] = new int[m+1][n+1];
		for(int i = 0; i <= m; i++)
			dp[i][0] = 1;
		for(int i = 0; i <= n; i++)
			dp[0][i] = 1000000000;
		for(int i = 1; i <= m; i++){

			for(int j = 1; j <= n; j++){

				int k;
				for(k = j-1; k >= 0 ; k--){

					if(t.charAt(k) == s.charAt(i-1))
						break;
				}
				if(k == -1)
					dp[i][j] = 1;
				else
					dp[i][j] = Math.min(dp[i - 1][j], dp[i - 1][k] + 1);
			}
		}
		
		return dp[m][n];

	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		String s = input.next();
		String t = input.next();
		int ans = solve(s, t);
		System.out.println(ans);
	}
}