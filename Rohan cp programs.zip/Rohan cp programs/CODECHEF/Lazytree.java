import java.util.Scanner;
class Lazytree{

	private static void build_Segmenttree(int arr[], int tree[], int index, int start, int end){

		if(start == end){
			tree[index] = arr[start];
			return ;
		}
		int mid = (start + end)/2;
		build_Segmenttree(arr, tree, 2*index, start, mid);
		build_Segmenttree(arr, tree, 2*index+1,mid+1,end);
		tree[index] = Math.min(tree[2*index], tree[2*index+1]);
		return ;
	}

	private static void update(int tree[], int lazytree[],int index, int start, int end, int low, int high, int value){

		if(start > end)
			return ;
		if(lazytree[index] != 0){
			tree[index] += lazytree[index];
			if(start != end){
				lazytree[2*index] += lazytree[index];
				lazytree[2*index+1] += lazytree[index];
			}
			lazytree[index] = 0;
		}

		//no overlap..
		if(start > high || end < low)
			return ;

		//completely overlapp..
		if(start >= low && high >= end){
			tree[index] += value;
			if(start != end){
				lazytree[2*index] += value;
				lazytree[2*index+1] += value;
			}
			return ;
		}

		// partially overlapp..
		int mid = (start + end)/2;
		update(tree, lazytree, 2*index, start, mid, low, high, value);
		update(tree, lazytree, 2*index+1, mid+1, end, low, high, value);
		tree[index] = Math.min(tree[2*index], tree[2*index+1]);
	}

	private static int find_min(int tree[], int lazytree[], int index, int start, int end, int low, int high){
		if(start > end)
			return Integer.MAX_VALUE;
		if(lazytree[index] != 0){
			tree[index] += lazytree[index];
			if(start != end){
				lazytree[2*index] += lazytree[index];
				lazytree[2*index+1] += lazytree[index];
			}
			lazytree[index] = 0;
		}
		if(start > high || low > end)
			return Integer.MAX_VALUE;
		if(start >= low && high >= end)
			return tree[index];
		int mid = (start + end) / 2;
		int ans1 = find_min(tree, lazytree, 2*index, start, mid, low, high);
		int ans2 = find_min(tree, lazytree, 2*index+1, mid+1, end, low, high);
		tree[index] = Math.min(tree[2*index], tree[2*index+1]);
		return Math.min(ans1, ans2);
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int arr[] = {1,3,-2,4};
		int segtree[] = new int[4*4];
		int lazytree[] = new int[4*4];
		build_Segmenttree(arr, segtree, 1, 0, 3);
		update(segtree, lazytree, 1, 0, 3, 0, 3, 3);
		System.out.println("segment Tree");
		System.out.println(segtree[1]+" "+segtree[2]+" "+segtree[3]+" "+segtree[4]+" "+segtree[5]+" "+segtree[6]+" "+segtree[7]);
		System.out.println("Lazy tree");
		System.out.println(lazytree[1]+" "+lazytree[2]+" "+lazytree[3]+" "+lazytree[4]+" "+lazytree[5]+" "+lazytree[6]+" "+lazytree[7]);
		update(segtree, lazytree, 1, 0, 3, 0, 1, 2);
		System.out.println("segment Tree");
		System.out.println(segtree[1]+" "+segtree[2]+" "+segtree[3]+" "+segtree[4]+" "+segtree[5]+" "+segtree[6]+" "+segtree[7]);
		System.out.println("Lazy tree");
		System.out.println(lazytree[1]+" "+lazytree[2]+" "+lazytree[3]+" "+lazytree[4]+" "+lazytree[5]+" "+lazytree[6]+" "+lazytree[7]);
		int ans = find_min(segtree, lazytree, 1, 0, 3, 1, 2);
		System.out.println("segment Tree");
		System.out.println(segtree[1]+" "+segtree[2]+" "+segtree[3]+" "+segtree[4]+" "+segtree[5]+" "+segtree[6]+" "+segtree[7]);
		System.out.println("Lazy tree");
		System.out.println(lazytree[1]+" "+lazytree[2]+" "+lazytree[3]+" "+lazytree[4]+" "+lazytree[5]+" "+lazytree[6]+" "+lazytree[7]);
		
	}
}