import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;
class Pair{
	int v,w;
	Pair(int x, int y){

		this.v = x;
		this.w = y;
	}
	
}
class FractionalKnapsack{

	public static int Max_Value(Pair arr[], int item, int weight){


		int value = 0;
		for(int i = 0; i < item; i++){
			if(weight == 0)
				break;

			if(arr[i].w <= weight){

				value = arr[i].v+value;
				weight -= arr[i].w;

			}
			else{

				value += ((arr[i].v/arr[i].w)*weight);
				break;
			}
		}
		return value;
	}

	public static void main(String [] args){
			Scanner input = new Scanner(System.in);
			int item = input.nextInt();
			int weight = input.nextInt();
			Pair []arr = new Pair[item];
			for(int i = 0; i < item; i++){
				int v = input.nextInt();
				int w = input.nextInt();
				arr[i] = new Pair(v, w);
			}
			
			Arrays.sort(arr, new Comparator<Pair>(){

			@Override
			public int compare(Pair p1, Pair p2){

				int v1 = (p1.v/p1.w);
				int v2 = (p2.v/p2.w);
				return v2 - v1;

			}
		});
			int result = Max_Value(arr, item, weight);
			System.out.println(result);
	}
}