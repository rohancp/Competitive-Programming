import java.util.Scanner;
import java.util.Arrays;
class SpreadSheet{

	private static void table(int lr[][], int k, int dp2[]){


		for(int i = 0; i < k; i++){

			int l = lr[i][0];
			int r = lr[i][1];
			if(l == r){
				System.out.println("Yes");
				continue;
			}
			
			int min = dp2[r];
			if(min <= l)
				System.out.println("Yes");
			else
				System.out.println("No");
		}
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int m = input.nextInt();
		int sheet[][] = new int[n+1][m+1];
		int dp1[] = new int[m+1];
		int dp2[] = new int[n+1];

		Arrays.fill(dp1, 1);
		dp2[1] = 1;
		for(int i = 1; i <= n; i++){

			int min = Integer.MAX_VALUE;
			for(int j = 1; j <= m; j++){

				sheet[i][j] = input.nextInt();
				if(i == 1)
					continue;
				if(sheet[i-1][j] <= sheet[i][j]){

					dp1[j] = dp1[j];
				}
				else
					dp1[j] = i;
				min = Math.min(min, dp1[j]);
			}
			if( i != 1)
				dp2[i] = min;
		}
		int k = input.nextInt();
		int lr[][] = new int[k][2];
		for(int i = 0; i < k; i++){

			lr[i][0] = input.nextInt();
			lr[i][1] = input.nextInt();
		}

		table(lr, k, dp2);
	}
}