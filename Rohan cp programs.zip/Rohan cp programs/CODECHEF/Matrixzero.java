import java.util.Scanner;
import java.util.Arrays;
class Matrixzero{

	
	private static int findMaxSquareWithAllZeros(int arr[][]){

		int r = arr.length;
		int c = arr[0].length;

		int dp[][] = new int [r][c];
		int max = 0;
		for(int i = 0; i < c; i++){

			if(arr[0][i] == 1)
				dp[0][i] = 0;

			else
				dp[0][i] = 1;
		}		
		for(int i = 0; i < r; i++){

			if(arr[i][0] == 1)
				dp[i][0] = 0;
			else
				dp[i][0] = 1;
		}

		for(int i = 1; i < r; i++){


			for(int j = 1; j < c; j++){


				if(arr[i][j] == 0){

					int min = Math.min(dp[i-1][j-1], Math.min(dp[i-1][j], dp[i][j-1]));
					dp[i][j] = min  + 1;
				}
				else
					dp[i][j] = 0;
			}
		}
		// System.out.println();

		for(int i = 0; i < r; i++){

			for(int j = 0; j < c; j++){
				// System.out.print(dp[i][j]);
				max = Math.max(max, dp[i][j]);
			}
			// System.out.println();
		}
		return max;

	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int r = input.nextInt();
		int c = input.nextInt();
		int mat[][] = new int[r][c];
		for(int i = 0; i < r; i++){

			for(int j = 0; j < c; j++){

				mat[i][j] = input.nextInt();
			}
		}
		int result = findMaxSquareWithAllZeros(mat);
		System.out.println(result);
	}
}