import java.util.*;
import java.io.*;
import java.lang.*;
class TripleSort5{


	private static String getsort(int N, int K, int arr[],int pos[],  boolean visited[]){

		int count = 0;
		boolean flag = false;
		StringBuilder sb = new StringBuilder();
		Vector<Integer> vec = new Vector<Integer>();
		for(int i = 1; i <= N; i++){

			if(visited[i])	continue;
			int index1 = i;
			int index2 = arr[index1];
			int index3 = pos[index1];
			if(index2 == index3){

				vec.add(index1);
				vec.add(index2);
				visited[index1] = visited[index2] = true;
				continue;
			}
			arr[index3] = arr[index2];
			arr[index2] = index2;
			arr[index1] = index1;

			pos[index1] = index1;
			pos[index2] = index2;
			pos[arr[index3]] = index3;
			if(arr[index3] == index3){

				visited[index3] = true;
			}
			visited[index1] = visited[index2] = true;
			sb.append(index1).append(" ").append(index2).append(" ").append(index3).append("\n");
			count++;
			if(count > K){
				
				return "-1";
			}

		}
		

			if(vec.size()%4 != 0){
				return "-1\n";
				// return sb;
			}
			else{
                     for(int i=0;i<vec.size();i=i+4){
                         int idx1=vec.get(i);
                         int idx2=vec.get(i+1);
                         int idx3=vec.get(i+2);
                         int idx4=vec.get(i+3);
                         
                         sb.append(idx1+" "+idx3+" "+idx2+"\n");
                         sb.append(idx2+" "+idx4+" "+idx3+"\n");
                         
                         count+=2;
                         if(count>K){
                            return "-1\n";
                         }
                     }
                 }
		
			StringBuilder sb2 = new StringBuilder();
			sb2.append(count).append("\n").append(sb.toString());
		return sb2.toString();

	}

	public static void main(String [] args)throws IOException {

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int N = Integer.parseInt(s[0]);
				int K = Integer.parseInt(s[1]);
				int arr[] = new int[N+1];
				s = br.readLine().split(" ");
				boolean visited[] = new boolean[N+1];
				int pos[] = new int[N+1];
				for(int i = 1; i <= N; i++){

					arr[i] = Integer.parseInt(s[i-1]);
					pos[arr[i]] = i;
					if(arr[i] == i)
						visited[i] = true;
				}

				String result = getsort(N, K, arr, pos, visited);
				sb.append(result).append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}