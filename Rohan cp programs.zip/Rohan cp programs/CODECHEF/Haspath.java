import java.util.Scanner;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Arrays;
class Graph{

	LinkedList<Integer> adjlist[];
	public Graph(int V){
		adjlist = new LinkedList[V];
		for(int i = 0; i < V; i++)
			adjlist[i] = new LinkedList<Integer>();
	}
	public void add_edge(int fv, int sv){
		adjlist[fv].add(sv);
		adjlist[sv].add(fv);
	}

	public boolean bfs_has_path(int src, int end, int n){
		boolean visited[] = new boolean[n];
		Arrays.fill(visited, false);
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(src);
		visited[src] = true;
		while(!queue.isEmpty()){
			int v = queue.poll();
			for(int u : adjlist[v]){
				if(u == end)
					return true;
				if(!visited[u]){
					queue.add(u);
					visited[u] = true;
				}
			}
		}
		return false;
	}
}

class Haspath{

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Graph g = new Graph(V);
		for(int i = 0; i < E; i++){
			int fv = input.nextInt();
			int sv = input.nextInt();
			g.add_edge(fv, sv);
		}
		int src = input.nextInt();
		int end = input.nextInt();
		boolean b = g.bfs_has_path(src, end, V);
		System.out.println(b);
	}
}