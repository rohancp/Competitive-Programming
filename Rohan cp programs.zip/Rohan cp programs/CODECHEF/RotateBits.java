import java.io.*;
class RotateBits
{
static BufferedReader xy=new BufferedReader(new InputStreamReader(System.in));
static int tot_bits = 32;
//This function is used to rotate the number n by d bits in the left direction
static int rotateLeft(int n, int d)
{
    int c=(n << d) | (n >> (tot_bits - d));
    return c;
}
//This function is used to rotate the number n by d bits in the right direction
static int rotateRight(int n, int d) 
{
    int c=(n >> d) | (n << (tot_bits - d));
    return c;
}
public static void main(String arg[]) throws IOException
{
    System.out.println("Enter the number");
    int num = Integer.parseInt(xy.readLine());
    System.out.println("Enter the number of bits by which it is to be shifted");
    int bits = Integer.parseInt(xy.readLine());
    System.out.print("Left Rotation of " + num +
                          " by " + bits + " is ");
    System.out.print(rotateLeft(num, bits));  
    System.out.print("\nRight Rotation of " + num +
                             " by " + bits + " is ");
    System.out.print(rotateRight(num, bits));
}
}