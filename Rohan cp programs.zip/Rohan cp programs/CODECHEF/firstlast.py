t=int(input())
while t>0:
    n=input()
    a=int(n[0])+int(n[-1])
    print(a)
    t-=1
    
