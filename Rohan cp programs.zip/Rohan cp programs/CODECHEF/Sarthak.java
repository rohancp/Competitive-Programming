import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.lang.StringBuilder;
class Sarthak{

	static LinkedHashSet<String> l = new LinkedHashSet<>();

	  //CreateSet.....

	  public static void CreateSet(Vector<Integer> vec)
	  {

	  	StringBuilder sb = new StringBuilder();

	  	for(int i = 0;i<vec.size();i++)
	  	{
	  		String a = Integer.toString(vec.get(i));
	  		sb.append(a);
	  		if(i!=vec.size()-1)
	  			sb.append(" ");

	  	}
	  	l.add(sb.toString());

	  	return ;
	  }
	  //PossibleSubset......

	  public static void PossibleSubset(Vector<Integer> vec, int arr[], int index)
	  {

	  	if(index>=arr.length)
	  		return ;

	  	vec.add(arr[index]);
	  	CreateSet(vec);
	  	PossibleSubset(vec, arr, index + 1);
	  	vec.remove(vec.size()-1);
	  	PossibleSubset(vec,arr,index + 1 );
	  	return ;
	  }
	public static void main(String[]args)throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			String line = br.readLine();
			String s[] = line.trim().split("\\s+");
			int arr[] = new int[N];
			for(int i = 0;i<N;i++)
				arr[i] = Integer.parseInt(s[i]);
			Vector<Integer> vec = new Vector<Integer>();
			PossibleSubset(vec, arr, 0);
			for(String s1 : l)
				System.out.println(s1);
	}
}