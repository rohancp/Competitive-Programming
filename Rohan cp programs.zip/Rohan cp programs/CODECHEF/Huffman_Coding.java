import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.LinkedList;
class NODE implements Comparable{
    
    int data;
    NODE left,right;
    char ch;
    NODE(int data, char ch){
        
        this.data = data;
        this.left = this.right = null;
        this.ch = ch;
    }

    public int get_data(){
        return data;
    }
    @Override
    public int compareTo(Object o) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        int d = ((NODE)o).get_data();
        return this.data-d;
    }
    
}


public class Huffman_Coding{
    
    private static NODE Find_Huffman_Code(HashMap<Character , NODE > hmap){
        
        NODE root = null;
//        int a = 1;
        while(hmap.size() != 1){
            
            List<NODE> list = new LinkedList<>();
            for(Map.Entry<Character, NODE> set : hmap.entrySet())
                list.add(set.getValue());
            Collections.sort(list);
            NODE one,two;
            one = list.get(0);
            two = list.get(1);
            root = new NODE(one.data + two.data, one.ch);
            root.left = one;
            root.right = two;
            char key = one.ch;
            hmap.remove(one.ch);
            hmap.remove(two.ch);
            hmap.put(key,root);
//            System.out.println(root.data + " "+ hmap);
            
        }
        return root;
    }
    
    private static void PreOrder(LinkedList<String> lhmap, String str, NODE tree){
        
        if(tree.ch != '.')
        {
            lhmap.add(str);
            return ;
        }
        PreOrder(lhmap, str + "0", tree.left);
        PreOrder(lhmap, str + "1", tree.right);
        
    }
    
    private static void SetCodeAlpha(NODE tree){
        
        if(tree.left == null && tree.right == null)
            return ;
        tree.ch = '.';
        SetCodeAlpha(tree.left);
        SetCodeAlpha(tree.right);
        
        
    }
    public static void main(String[] args)throws IOException {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tc = Integer.parseInt(br.readLine());
        while(tc-- > 0){
            
            String s = br.readLine();
            char ch[] = s.toCharArray();
            String s1[] = br.readLine().trim().split("\\s+");
            int N = s.length();
            int arr[] = new int[N];
            HashMap<Character, NODE> hmap = new HashMap<>();
            for(int a = 0; a < N; a++){
                
                arr[a] = Integer.parseInt(s1[a]);
                NODE node = new NODE(arr[a],ch[a]);
                hmap.put(ch[a], node);
            }
           NODE root = Find_Huffman_Code(hmap);
           SetCodeAlpha(root);
           LinkedList<String> lhmap = new LinkedList<>();
           PreOrder(lhmap, "", root);
           for(String p : lhmap)
               System.out.print(p+" ");
           System.out.println();
        }
    }
}