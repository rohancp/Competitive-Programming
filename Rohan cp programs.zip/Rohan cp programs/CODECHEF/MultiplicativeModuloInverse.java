import java.util.Scanner;
class Triplet{

	public int x,y, gcd;
}
class MultiplicativeModuloInverse{

	public static Triplet extended_euclid_algo(int a, int b){

		if(b == 0){

			Triplet ans = new Triplet();
			ans.gcd = a;
			ans.x = 1;
			ans.y = 0;
			return ans;

		}
		Triplet smallans = extended_euclid_algo(b, a%b);
		Triplet ans = new Triplet();
		ans.gcd = smallans.gcd;
		ans.x = smallans.y;
		ans.y = smallans.x-(a/b)*smallans.y;
		return ans;
	}

	public static int mMInverse(int a, int m){
		Triplet ans = extended_euclid_algo(a, m);
		return ans.x;
	}

	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int m = input.nextInt();
		int ans = mMInverse(a, m);
		System.out.println(ans);
	}
}