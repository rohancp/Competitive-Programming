import java.util.Scanner;
class CountInversion{

	private static long Merging(int arr[], int mid, int l, int h){

		int i = l;
		int j = mid+1;
		int k = l;
		int B[] = new int[arr.length];

		long count = 0;
		while( i <= mid && j <= h){

			if(arr[i] <= arr[j]){

				B[k++] = arr[i++];
			}
			else{
				B[k++] = arr[j++];
				count += (mid+1) - i;
			}
		}

		while( i <= mid){

			B[k++] = arr[i++];
		}

		while( j <= h){
			B[k++] = arr[j++]; 
		}

		for( ; l <= h; l++)
			arr[l] = B[l];
		return count;

	}


private static long MergeSort(int arr[], int l, int h){

	if( l < h){

		int mid = (l+h)/2;
		long lf = MergeSort(arr, l, mid);
		long rf = MergeSort(arr, mid+1, h);
		long mer = Merging(arr, mid, l, h);
		return (lf + rf + mer);
	}
	return 0;
}

	private static long solve(int[] A,int n){
		
			return MergeSort(A, 0, n-1);
		
	}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int arr[] = new int[n];
		for(int i = 0; i < n; i++)
			arr[i] = input.nextInt();
		long result = solve(arr, n);
		System.out.println(result);
	}
}