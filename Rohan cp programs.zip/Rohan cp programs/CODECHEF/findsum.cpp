#include<stdio.h>
int main()
{
	int t_c,n,a,b;
	scanf("%d\n",&t_c);
	while(t_c-->0){
		scanf("%d\n",&n);
		a=n%10;
		n=n/10;
		b=0;
		while(n>0){
			b=n%10;
			n=n/10;
		}
		printf("%d\n",a+b);
	}
	return 0;
}
