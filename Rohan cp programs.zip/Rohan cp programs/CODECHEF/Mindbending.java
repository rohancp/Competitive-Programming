import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Mindbending{


		private static int[] Mind_bending(int arr[], int size){

			int p[] = new int[arr.length];
			int lp,rp;
			lp = rp = 1;
			for(int i = 0; i < size; i++){

				p[i] = lp;
				lp *= arr[i];
			}
			for(int i = size-1; i >= 0; i--){
				p[i] = p[i] *rp;
				rp *= arr[i];
			}
			return p;



		}
	
	public static void main(String [] args) throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){

			int size = Integer.parseInt(br.readLine());
			String s[] = br.readLine().trim().split("\\s+");
			int i = 0 ;
			int arr[] = new int[size];
			for(String ele : s)
				arr[i++] = Integer.parseInt(ele);

			int ans[] = Mind_bending(arr, size);

			for(i = 0; i < size; i++)
				System.out.print(ans[i]+" ");
			System.out.println();
		}
	}
}