import java.util.Scanner;
import java.util.Arrays;
class Largestpiece{
	static int N;
	static int cake[][];
	static boolean visited[][];
	static int k = 0;

	private static boolean find_piece(int row, int col){
		if(row < 0 || row >= N || col < 0 || col >=N || visited[row][col])
			return false;
		if(1 == cake[row][col]){
			k++;
			visited[row][col] = true;
			if(find_piece(row, col+1))
				return true;
			if(find_piece(row+1, col))
				return true;
			if(find_piece(row, col-1))
				return true;
			if(find_piece(row-1, col))
				return true;
			// visited[row][col] = false;
		}
		return false;
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		N = input.nextInt();
		cake = new int[N][N];
		for(int i = 0; i < N; i++){
			int j = 0;
			String s = input.next();
			String sr[] = s.split("");
			for(String a : sr)
				cake[i][j++] = Integer.parseInt(a);
		}
		visited = new boolean [N][N];
		int max = 0;
		for(int i = 0; i < N; i++)
			Arrays.fill(visited[i], false);
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				k = 0;
				if(cake[i][j] == 1 && !visited[i][j])
				{find_piece(i, j);
				max = Math.max(max, k);}
			}
		}
		System.out.println(max);
	}	
}