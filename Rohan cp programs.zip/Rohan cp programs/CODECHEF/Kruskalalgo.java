import java.util.Scanner;
import java.util.Arrays;
class Edges implements Comparable<Edges>{
	int src;
	int des;
	int weght;
	public Edges(int src, int des, int weght){
		this.src = src;
		this.des = des;
		this.weght = weght;
	}
	public int compareTo(Edges ob){
		if(this.weght == ob.weght)
			return 0;
		else if(this.weght > ob.weght)
			return 1;
		return -1;
	}
}
class Kruskalalgo{
	public static int getParent(int v,int parent[]){
		if(parent[v] == v)
			return v;
		return getParent(parent[v], parent);
	}
	public static Edges[] make_mst(int V, int E, Edges edges[]){
		int parent[] = new int[V];
		for(int i = 0; i < V; i++)
			parent[i] = i;
		Edges mst[] = new Edges[V-1];
		int count_edges = 0;
		int i = 0;
		while(count_edges != V-1){

			int srcparent = getParent(edges[i].src, parent);
			int desparent = getParent(edges[i].des, parent);
			if(srcparent != desparent){
				mst[count_edges] = new Edges(edges[i].src, edges[i].des, edges[i].weght);
				count_edges++;
				parent[srcparent] = desparent;
			}
			i++;
		}
		return mst;
	}
	public static void main(String [] args){
		Scanner input = new Scanner(System.in);
		int V = input.nextInt();
		int E = input.nextInt();
		Edges edges[] = new Edges[E];
		for(int i = 0; i < E; i++){ 
			int s = input.nextInt();
			int d = input.nextInt();
			int w = input.nextInt();
			edges[i] = new Edges(s, d, w);
		}
		Arrays.sort(edges);
		Edges MST[] = make_mst(V, E, edges);
		for(int i = 0; i < V-1; i++){
			System.out.println(MST[i].src+" "+MST[i].des+" "+MST[i].weght);
		}
	}
}