import java.util.Scanner;
import java.util.Arrays;
class HasanTrip{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		double x[],y[],f[];
		x = new double[n];
		y = new double[n];
		f = new double[n];
		for(int i = 0; i < n; i++){

			x[i] = input.nextDouble();
			y[i] = input.nextDouble();
			f[i] = input.nextDouble();	

		}

		double dp[] = new double[n];
		Arrays.fill(dp, -Double.MAX_VALUE);

		
		dp[0] = f[0];
		for(int i = 1; i < n; i++){

			for(int j = 0; j < i; j++){

				dp[i] = Math.max(dp[i], dp[j] - Math.sqrt((x[j]-x[i])*(x[j]-x[i]) + (y[j]-y[i])*(y[j]-y[i])));
			}
			dp[i] += f[i];
		}
		System.out.format("%.6f",dp[n-1]);
	}
}



