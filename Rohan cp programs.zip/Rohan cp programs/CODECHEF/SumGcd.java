import java.io.*;
import java.util.*;
class SumGcd{

	private static int GCD(int a,int b){

		if(b == 0)
			return a;
		return GCD(b, a % b);
	}


	private static int MaxSum(int arr[], int N){

		if(N == 2)
			return arr[0] + arr[1];
		Arrays.sort(arr);
		int GCD_C = arr[N-1];
		int result = arr[0];
		for(int i = 1; i < N-1; i++)
			result = GCD(result, arr[i]);

		return result + GCD_C;


	}

	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		while(tc-- > 0){


			int N = Integer.parseInt(br.readLine());
			String s[] = br.readLine().trim().split("\\s+");
			int arr[] = new int[N];
			int i = 0;
			for(String a : s)
				arr[i++] = Integer.parseInt(a);

				int result = MaxSum(arr, N);
				System.out.println(result);
		}

	}

}