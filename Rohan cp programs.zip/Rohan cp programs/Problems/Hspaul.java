import java.util.*;
import java.io.*;
import java.lang.*;
class Hspaul{

	private static int size = (int)(1e7);
	private static boolean prime[];
	private static void sieve(){

		prime = new boolean[size+1];
		Arrays.fill(prime, true);

		prime[0] = prime[1] = false;
		for(int i = 2; i * i <= size; i++){

			if(prime[i]){

				for(int j = i*i; j <= size; j += i)
					prime[j] = false;
			}
		}
	}

	private static boolean  isprime(int n){

		return prime[n];
	}

	private static long[] make_fun(){

		sieve();
		// System.out.println("ROhan");
		Vector<Integer> primes = new Vector<Integer>();
		boolean visit[] = new boolean[size+1];
		Arrays.fill(visit, false);
		for(int i = 1; i*i < size; i++){

			for(int j = 1; (j*j*j*j) < size; j++){

				int num = (i*i)+(j*j*j*j);
				if(num > size)continue;
				// System.out.println(num);
				if(isprime(num)){
					if(visit[num])
						continue;
					primes.add(num);
					visit[num] = true;
				}
			}
		}
		// Collections.sort(primes);
		long sum[] = new long[size+1];

		for(int a : primes){
			 sum[a] = 1;
		}
		for(int i = 1; i <= size; i++){

			sum[i] += sum[i-1];
		}
		return sum;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			long sum[] = make_fun();
			while(tc-- > 0){
				int n = Integer.parseInt(br.readLine());
				sb.append(sum[n]).append("\n");
			}			
				System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}