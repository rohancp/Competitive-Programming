import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Appleman{

	public static void main(String [] args)throws IOException{

			// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n  = Integer.parseInt(br.readLine());
			char ch[][] = new char[n][n];
			for(int i = 0; i < n; i++){

				String s = br.readLine();
				for(int j = 0; j < n; j++){
					ch[i][j] = s.charAt(j);
				}
			}

			int count = 0;
			for(int i = 0; i < n; i++){

				
				for(int j = 0; j < n; j++){

					count= 0;
					//left...

					if((j > 0) && (ch[i][j-1] == 'o')){
						count++;
					}
					// top
					if((i > 0) && (ch[i-1][j] == 'o'))
						count++;
					// right;
					if((j < n-1) && (ch[i][j+1] == 'o'))
						count++;
					// down..
					if((i < n-1) && (ch[i+1][j] == 'o'))
						count++;
					if(count == 1 || count == 3){
						break;
					}
				}
				if(count ==  1 || count == 3)
					break;
			}
			if(count == 1 || count == 3)
				System.out.println("NO");
			else
				System.out.println("YES");

		// }catch(Exception e){

		// 	return ;
		// }
	}
}