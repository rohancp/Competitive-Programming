import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Chatroom{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s = br.readLine();
			String str = "";
			for(int i = 0; i < s.length(); i++){

				if(str.length() == 0 && s.charAt(i) == 'h')
					str = "h";
				else if(str.length() == 1 && s.charAt(i) == 'e')
					str +="e";
				else if((str.length() == 2 || str.length() == 3) && s.charAt(i) =='l')
					str +="l";
				else if(str.length() == 4 && s.charAt(i) == 'o')
					str +="o";
				if(str.equals("hello"))
					break;
				// System.out.println(str);
			}
			if(str.equals("hello"))
				System.out.println("YES");
			else{
				System.out.println("NO");
			}

		}catch(Exception e){

			return ;
		}
	}
}