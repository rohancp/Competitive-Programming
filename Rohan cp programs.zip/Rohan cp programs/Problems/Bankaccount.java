import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Bankaccount{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s = br.readLine();
			if(Integer.parseInt(s)  >= 0)
				System.out.println(s);
			else{

				if(s.length() == 2)
					System.out.println(s);
				else{

					String s1,s2;
					s1 = s.substring(0, s.length()-1);
					s2 = s.substring(0, s.length()-2)+s.substring(s.length()-1,s.length());
					System.out.println(Math.max(Integer.parseInt(s1), Integer.parseInt(s2)));
				}
			}

		}catch(Exception e){

			return ;
		}
	}
}