import java.util.*;
import java.io.*;
import java.lang.*;

class Feynman{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			while(true){

				int N = Integer.parseInt(br.readLine());
				if(N == 0)break;
				long ans = 0;
				while(N >= 1){
					ans += (N*N);
					N -= 1;
				}
				sb.append(ans).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}