import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Divsum1{

	private static int _gcd(int A, int B){

		if(B == 0)	return A;
		return _gcd(B, A%B);
	}

	static int MAX = (int)(10e6);
	static int smalldiv[];
	private static void sieve(){

		smalldiv = new int[MAX + 1];
		for(int i =1; i <= MAX; i++)
			smalldiv[i] = i;

		for(int i = 2; i * i <= MAX; i++){

			if(smalldiv[i] == i){

				for(int j = i * i; j <= MAX; j += i){

					if(smalldiv[j] == j)
						smalldiv[j] = i;
				}
			}
		}
		return ;
	}

	private static long power(long a, long n){

		long result = 1;

		while(n != 0){

			if((n&1) == 1){

				result = result * a;
			}
			a = a*a;
			n >>= 1;
		}
		return result;
	}

	private static long _numberOf_div(int n){

		if(n == 1)	return 1;

		int count = 1;
		long result = 1;
		while(n != 1){

			if(smalldiv[n] == smalldiv[n/smalldiv[n]])
				count++;
			else{
				long smallans = (power(smalldiv[n], count+1)-1)/(smalldiv[n]-1);
				result = result * smallans;
				count = 1;
			}
			n /= smalldiv[n];
		}
		return result;
	}

	public static void main(String [] args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			sieve();
			while(tc-- > 0){

				// String s[] = br.readLine().split(" ");
				int A = Integer.parseInt(br.readLine());
				// // int B = Integer.parseInt(s[1]);
				// int gcd = _gcd(A, B);
				long ans = _numberOf_div(A)-A;
				sb.append(ans).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}