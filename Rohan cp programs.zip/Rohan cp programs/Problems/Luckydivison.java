import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Luckydivison{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			int arr[] = {4,7,44,77,47,74,444,477,447,474,744,777,747,774};
			int i;
			for(i = 0; i < arr.length;i++){

				if(n==arr[i]){
					System.out.println("YES");
					break;
				}
			}
			if(i == arr.length){

				for(i = 0; i < arr.length; i++){

					if(n%arr[i] == 0){
						System.out.println("YES");
						break;
						}
				}
			}

			if(i == arr.length)
				System.out.println("NO");


		}catch(Exception e){

			return ;
		}
	}
}