import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class BearandRaspberry{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n = Integer.parseInt(s[0]);
			int c = Integer.parseInt(s[1]);
			s = br.readLine().split(" ");
			int max = 0;
			for(int i = 1; i < n; i++){
				max = Math.max(max, Integer.parseInt(s[i-1]) - c - Integer.parseInt(s[i]));
			}
			System.out.println(max);

		}catch(Exception e){

			return ;
		}
	}
}