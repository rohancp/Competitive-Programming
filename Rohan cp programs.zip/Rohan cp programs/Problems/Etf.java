import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Etf{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			//  Euler's Totient Function.....

			/*
			Euler's totient function is also known as phi function
			counts the number of integers b/w 1 to n inclusive.
			which are co-prime to n. Two numbers are coprime if their
			greatest common divisors equals to 1.
			*/

			int phi[] = new int[1001];
			for(int i = 0; i < 1001; i++){
				phi[i] = i;
			}

			for(int i = 2; i <= 1000; i++){

				if(phi[i] == i){

					phi[i]--;
					for(int j = i+i; j <= 1000; j += i){

						phi[j] -= phi[j]/i;
					}
				}
			}

			for(int i = 1; i <= 25; i++){

				System.out.println(i+" > "+phi[i]);
			}

		}catch(Exception e){

			return ;
		}
	}
}