import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class FermethodPt{


	private static int power(int a, int n, int p){

		int res=1;
		a = a % p;
		while(n > 0){

			if((n&1) == 1)
				res = (res * a) % p;
			a = (a * a) % p;
			n >>= 1;
		}
		return res;
	}



	private static boolean isPrime(int num, int k){

		if(num <= 1)	return false;

		if(num <= 3)	return	true;

		while(k > 0){

			int a = 2 +(int)(Math.random()%(num-4));

			if(power(a, num-1, num) != 1)
				return false;
			k--;
		}
		return true;
	}

	public static void main(String [] args)throws IOException{

		try{

			//  Check number is prime or not using fermet method.....

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			
			int k = 4;

			System.out.println(isPrime(2, k));
			System.out.println(isPrime(3, k));
			System.out.println(isPrime(15, k));


		}catch(Exception e){

			return ;
		}
	}
}