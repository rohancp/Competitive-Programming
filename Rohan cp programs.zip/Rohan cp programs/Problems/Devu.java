import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Devu{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n = Integer.parseInt(s[0]);
			int d = Integer.parseInt(s[1]);
			s = br.readLine().split(" ");
			int count = 0;
			int i;
			for(i = 0; (i < n) && (d > 0) && ((d - Integer.parseInt(s[i])) >= 0); i++){

				d = d - Integer.parseInt(s[i]);
				if( 10 <= d)
					count += 2;
				else if(5 <= d)
					count +=1;
				d -= 10;
			}
			if(5 <= d)
			count += (d/5);
			if(i == n)
			{
				System.out.println(count);
			}
			else
				System.out.println("-1");

		}catch(Exception e){

			return ;
		}
	}
}