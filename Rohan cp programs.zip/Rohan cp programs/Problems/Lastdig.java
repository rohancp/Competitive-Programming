import java.util.*;
import java.io.*;
import java.lang.*;

class Lastdig{


	private static int binpow(int a, long b){

		int result = 1;
		a = a %10;
		while(b > 0){

			if((b & 1) == 1){
				result = (result * a)%10;
			}
			a = (a*a)%10;
			b >>= 1;
		}
		return result;
	}

	public static void main(String [] args)throws IOException{

		Scanner input = new Scanner(System.in);
		int tc = input.nextInt();
		while(tc-- > 0){

			int a = input.nextInt();
			long b = input.nextLong();
			System.out.println(binpow(a, b));
		}
	}
}