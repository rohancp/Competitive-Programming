import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Candy3{

	public static void main(String [] args)throws IOException{

		try{

			Scanner input = new Scanner(System.in);
			int tc = input.nextInt();
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = input.nextInt();
				long sum = 0;
				// long arr[] = new long[n];
				for(int i = 0; i < n; i++){
					long a = input.nextLong();
					sum = (sum + a)%n;
				}				
				if(sum == 0){
					sb.append("YES");
				}
				else{
					sb.append("NO");
				}
				sb.append("\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){

			return ;
		}
	}
}