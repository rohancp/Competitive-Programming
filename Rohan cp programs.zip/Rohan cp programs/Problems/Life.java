import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Life{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			while(true){

				int tc = Integer.parseInt(br.readLine());
				if(tc == 42)break;
				System.out.println(tc);
			}

		}catch(Exception e){

			return ;
		}
	}
}