import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Lunchrush{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n,k;
			n = Integer.parseInt(s[0]);
			k = Integer.parseInt(s[1]);
			int max = Integer.MIN_VALUE;
			while(n-- > 0){

				s = br.readLine().split(" ");
				int f,t;
				f = Integer.parseInt(s[0]);
				t = Integer.parseInt(s[1]);
				if(t > k){
					max = Math.max(max, f-(t-k));
					continue;
				}
				max = Math.max(max, f);
			}
			System.out.println(max);

		}catch(Exception e){

			return ;
		}
	}
}