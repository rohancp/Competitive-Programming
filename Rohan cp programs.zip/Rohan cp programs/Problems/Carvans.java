import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Carvans{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc--> 0){


				int n= Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				long arr[] = new long[n];
				for(int i = 0; i < n; i++){

					arr[i] = Long.parseLong(s[i]);
				}

				long max = arr[0];
				long count = 1;
				for(int i = 1; i < n; i++){

					if(max >= arr[i])
					{
						max= arr[i];
						count++;
					}
				}
				sb.append(count).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}