import java.util.*;
import java.io.*;
import java.lang.*;

class Alphacode{


	private static long getString(String s){

		
        int n = s.length();
        if(n == 1)
            return 1;
        long dp[] = new long[n];
        int m = Integer.parseInt(s.substring(0,2));
        
        //if m > 20 and m is multiple of 10 then..
        if(m%10 == 0 && 20 < m)
            return 0;
        else{
            if(m%10 == 0 || m >26)
                dp[0] = dp[1] = 1;
            else{
                dp[0] = 1;
                dp[1] = 2;
            }
        }
        
        for(int i = 2; i < n; i++){
            m = Integer.parseInt(s.substring(i-1,i+1));
            if(m == 0 || (m%10==0 && m > 20))
                return 0;
            if(m < 10 || m > 26){
                dp[i] = dp[i-1];
                continue;
            }
            else if(m%10 == 0){
                dp[i] = dp[i-2];
                continue;
            }
            dp[i] = dp[i-1] + dp[i-2];
        }
        return dp[n-1];
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			while(true){

				String s = br.readLine();
				if(s.equals("0"))
					break;
				long result = getString(s);
				sb.append(result).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}