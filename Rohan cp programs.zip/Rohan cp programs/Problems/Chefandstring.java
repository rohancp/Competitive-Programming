import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Chefandstring{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				String s = br.readLine();
				long sum = 0;
				int length = s.length()-1;
				for(int i = 0; i < length; ){

					if(s.charAt(i) == s.charAt(i+1)){
						i++;
						continue;
					}
					sum += 1;
					i += 2;
				}
				sb.append(sum).append("\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}