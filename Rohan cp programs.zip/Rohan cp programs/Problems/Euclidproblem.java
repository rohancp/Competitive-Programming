import java.util.*;
class Euclidproblem{

	static long x, y;
	private static long extended(long A, long B){

		if(B == 0){
			x = 1;
			y = 0;
			return A;
		}
		long gcd = extended(B, A%B);
		long temp = x;
		x = y;
		y = temp - ((A/B)*y);
		return gcd;
	}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		while(input.hasNext()){
			long A = input.nextLong();
			long B = input.nextLong();
			long gcd = extended(A, B);
			System.out.println(x+" "+y+" "+gcd);

		}
	}
}