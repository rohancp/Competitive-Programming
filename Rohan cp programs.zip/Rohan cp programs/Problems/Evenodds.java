import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Evenodds{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			long n, k;
			n = Long.parseLong(s[0]);
			k = Long.parseLong(s[1]);
			long odd = (k*2)-1;
			if(n >= odd)
				System.out.println(odd);
			else{

				long even = k - (n-k);
				if((n&1) == 1)
					System.out.println(even-1);
				else
					System.out.println(even);
			}

		}catch(Exception e){

			return ;
		}
	}
}