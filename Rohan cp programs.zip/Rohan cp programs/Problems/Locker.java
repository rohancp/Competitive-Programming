import java.util.*;
import java.io.*;
import java.lang.*;

class Locker{

	private static int mod = (int)(1e9)+7;


	private static long power_of_3(long n){

		long result = 1, base = 3;
		while(n > 0){

			if((n&1) == 1){
				result = (result * base)%mod;
			}
			base = (base * base)%mod;
			n >>= 1;
		}
		return result;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			HashMap<Long, Long> map = new HashMap<Long, Long>();
			while(tc-- > 0){

				long n = Long.parseLong(br.readLine());
				if(n == 1){
					sb.append(1).append("\n");
					continue;
				}
			long c = n % 3;
			long nn ;
			long ans;
			if(c == 2){

				nn = (n-2)/3;
			}
			else if(c == 1){

				nn = (n-4)/3;
			}else{
				nn = n/3;
			}

			if(map.containsKey(nn))
				ans = map.get(nn);
			else{
				ans = power_of_3(nn);
				map.put(nn, ans);
			}
			if(n%3 == 2){
				ans = (ans*2)%mod;
			}
			else if(n%3 == 1){
				ans = (ans*4)%mod;
			}
			sb.append(ans).append("\n");
		}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}