import java.util.*;
import java.io.*;
import java.lang.*;

class Flow{

	private static long GCD(long a, long b){

		if(b == 0)return a;
		return GCD(b, a%b);
	}

	private static long LCM(long a, long b, long gcd){
		return (a*b)/gcd;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){


				String s[] = br.readLine().split(" ");
				long A = Long.parseLong(s[0]);
				long B = Long.parseLong(s[1]);
				long gcd = GCD(A, B);
				long lcm = LCM(A, B, gcd);
				sb.append(gcd).append(" ").append(lcm).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}