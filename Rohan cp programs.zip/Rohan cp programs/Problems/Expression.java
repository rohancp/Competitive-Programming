import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Expression{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int a = Integer.parseInt(br.readLine());
			int b = Integer.parseInt(br.readLine());
			int c = Integer.parseInt(br.readLine());
			int ans1,ans2,ans3,ans4,ans5,ans6;
			ans1 = a+b+c;
			ans2 = (a+b)*c;
			ans3 = a*(b+c);
			ans4 = a*b*c;
			ans5 = (a*b)+c;
			ans6 = a+(b*c);
			int max = Math.max(ans1, ans2);
			max = Math.max(max, ans3);
			max = Math.max(max, ans4);
			max = Math.max(max, ans5);
			max = Math.max(max, ans6);
			System.out.print(max);

		}catch(Exception e){

			return ;
		}
	}
}