import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Dubstep{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String st[] = br.readLine().split("WUB");
			StringBuilder sb = new StringBuilder();
			for(String str : st){

				if(str.length() == 0)
					continue;
				else
					sb.append(str).append(" ");
			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}