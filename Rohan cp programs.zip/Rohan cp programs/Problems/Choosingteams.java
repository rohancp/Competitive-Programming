import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Choosingteams{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			String s[] = br.readLine().split(" ");
			int n,k;
			n = Integer.parseInt(s[0]);
			k = Integer.parseInt(s[1]);
			s = br.readLine().split(" ");
			int arr[]= new int[n];
			for(int i = 0; i < n; i++){
				arr[i] = Integer.parseInt(s[i]);
			}
			int count = 0;
			Arrays.sort(arr);
			for(int i = 0; n-i >= 3; i += 3){

				if((arr[i]+k > 5) || (arr[i+1]+k > 5) || (arr[i+2]+k > 5)){

					break;
				}
				// continue;
				count++;
			}
			System.out.println(count);


		}catch(Exception e){

			// System.out.println(e);
			return ;
		}
	}
}