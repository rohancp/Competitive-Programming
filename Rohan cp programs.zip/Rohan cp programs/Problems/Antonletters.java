import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Antonletters{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s = br.readLine();
			// String str[] = s.split("\\{|\\}|\\,");
			Set<Character> set  = new HashSet<Character>();
			for(int i=0; i < s.length(); i++){

				if(s.charAt(i) == '{' || s.charAt(i) == '}' || s.charAt(i) ==' ' || s.charAt(i) == ',')	continue;
				set.add(s.charAt(i));

			}
			System.out.println(set.size());
		}catch(Exception e){

			return ;
		}
	}
}