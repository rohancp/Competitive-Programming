import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Helpfulmaths{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s = br.readLine();
			Vector<Integer> vec = new Vector<Integer>();

			for(int i = 0; i< s.length(); i += 2)
				vec.add(Integer.parseInt(s.charAt(i)+""));
			
			Collections.sort(vec);
			String result="";
			result = ""+vec.get(0);
			for(int i =1; i < vec.size(); i++){
				result += "+"+vec.get(i);
			}
			System.out.println(result);

		}catch(Exception e){

			return ;
		}
	}
}