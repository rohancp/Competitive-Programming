import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
 class Lcmsum{

	static int size = (int)(10e6);
	static int etf[];
	static long sum[];

	private static void etf(){

		etf = new int[size+1];
		sum = new long[size+1];
		for(int i =1; i <= size; i++)
			etf[i] = i;

		for(int i = 2; i <= size; i++){

			if(etf[i] == i){

				etf[i]--;
				for(int j = i+i; j <= size; j += i)
					etf[j] -= etf[j]/i;
			}
		}

		sum[1] = 1;
		for(int i = 2; i <= size; i++){

			sum[i] = 1;
			sum[i] += (i*etf[i]);

			for(int j = i+i; j <= size; j += i)
				sum[j] += (i * etf[i]);
		}
		return ;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			etf();

			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				long ans = (sum[n] + 1) * n;
				// System.out.println(sum[n]+" "+etf[n]);
				ans /= 2;
				sb.append(ans).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}