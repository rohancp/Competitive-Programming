import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Crt{


	private static int inv(int a, int m){

		int m0 = m, t, q; 
        int x0 = 0, x1 = 1; 
      
        if (m == 1) 
        return 0; 
      
        // Apply extended Euclid Algorithm 
        while (a > 1) 
        { 
            // q is quotient 
            q = a / m; 
      
            t = m; 
      
            // m is remainder now, process 
            // same as euclid's algo 
            m = a % m;a = t; 
      
            t = x0; 
      
            x0 = x1 - q * x0; 
      
            x1 = t; 
        } 
      
        // Make x1 positive 
        if (x1 < 0) 
        x1 += m0; 
      
        return x1; 
	}

	private static int getValue_of_x(int num[], int rem[], int size){

		int prod = 1;
		for(int i = 0; i < size; i++){
			prod *= num[i];
		}

		int result = 0;
		for(int i = 0; i < size; i++){

			int ppi = prod/num[i];
			result += rem[i] * inv(ppi, num[i])* ppi;
		}

		return result % prod;

	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int size = Integer.parseInt(br.readLine());
			int num[] = new int[size];
			int rem[] = new int[size];
			String s[] = br.readLine().split(" ");
			String s2[] = br.readLine().split(" ");
			for(int i = 0; i < size;i ++){

				num[i] = Integer.parseInt(s[i]);
				rem[i] = Integer.parseInt(s2[i]);
			}
			int x = getValue_of_x(num, rem, size);
			System.out.println(x);

		}catch(Exception e){

			return ;
		}
	}
}