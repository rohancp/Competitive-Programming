import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Evenmatrix{


	private static StringBuilder get_DeliciousMatrix(int N){

		StringBuilder sb = new StringBuilder();

		LinkedList<Integer> list[] = new LinkedList[N];
		for(int i=0; i < N; i++){

			list[i] = new LinkedList<Integer>();
		}
		int a = 1;
		for(int i = 0; i < N; i++){

			for(int j = 0; j < N; j++){

				if((i&1) == 1){
					list[i].addLast(a++);
				}
				else
					list[i].addFirst(a++);
			}
		}

			for(int i = 0; i < N; i++){

				LinkedList<Integer> l = list[i];
				StringBuilder sb2 = new StringBuilder();
				for(int aa : l){

					sb2.append(aa).append(" ");
				}
				sb.append(sb2).append("\n");
			}
			return sb;

	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder result = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				result.append(get_DeliciousMatrix(N)).append("\n");

			}
			System.out.println(result);

		}catch(Exception e){

			return ;
		}
	}
}