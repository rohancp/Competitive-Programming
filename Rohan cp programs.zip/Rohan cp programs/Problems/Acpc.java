import java.util.*;
import java.io.*;
import java.lang.*;

class Acpc{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			while(true){
				String s[] = br.readLine().split(" ");
				int a = Integer.parseInt(s[0]);
				int b= Integer.parseInt(s[1]);
				int c = Integer.parseInt(s[2]);
				if(a == 0 && b == 0 && c == 0)
					break;
				if(c-b == b-a){
					// ap terms
					sb.append("AP ").append(c+(c-b)).append("\n");
				}
				else{

					sb.append("GP ").append(c*(c/b)).append("\n");
				}

			}

			System.out.println(sb.toString());
		}catch(Exception e){

			return ;
		}
	}
}