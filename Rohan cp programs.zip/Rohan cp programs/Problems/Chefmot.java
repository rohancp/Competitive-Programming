import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Chefmot{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int S = Integer.parseInt(s[0]);
				int N = Integer.parseInt(s[1]);
				int coins = 0;
				if(S <= N){

						if((S == 1) || (S&1) != 1)
							coins = 1;
						else{
							coins =2;
						}
				}
				else{

						coins= (S/N);
						S %=N;
						if(S == 0){
							sb.append(coins).append("\n");
							continue;
						}
						if((S == 1) || (S&1) != 1)
							coins +=1;
						else
							coins +=2;
				}
				sb.append(coins).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}