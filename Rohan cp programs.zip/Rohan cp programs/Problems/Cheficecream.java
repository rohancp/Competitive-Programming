import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Cheficecream{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				Map<Integer, Integer> map = new HashMap<Integer, Integer>();
				map.put(5, 0);
				map.put(10, 0);
				map.put(15, 0);
				int i = 0;
				for(i = 0; i < N; i++){
					
					int a = Integer.parseInt(s[i]);
					// System.out.println(a+"\n");
					if(a == 5){

						map.put(a, map.get(a)+1);
						
					}
					else if(a == 10){
						map.put(a, map.get(a)+1);
						if(map.get(5) >= 1){

							map.put(5, map.get(5)-1);
							
						}
						else
							break;
					}

					else{

						map.put(a, map.get(a)+1);
						if(map.get(10) >= 1){
							map.put(10, map.get(10)-1);
							
						}
						else if(map.get(5) >= 2){

							map.put(5, map.get(5)-2);
							
						}
						else
							break;
					}
					// System.out.println(map.get(5));
					// System.out.println(map.get(10));
					// System.out.println(map.get(15));
				}

				if(i == N){
					sb.append("YES");
				}
				else
					sb.append("NO");
				sb.append("\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}