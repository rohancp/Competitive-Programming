import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Etf2{


	private static int etf[];

	private static void preComputeEtf(int size){

		etf = new int [size+1];
		for(int i = 0; i <= size; i++){
			etf[i] = i;
		}

		for(int i = 2; i <= size; i++){

			if(etf[i] == i){

				etf[i]--;

				for(int j = i+i; j <= size; j +=i)
					etf[j] -= etf[j]/i;
			}
		}
		return ;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			preComputeEtf((int)Math.pow(10, 6));
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				sb.append(etf[n]).append("\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}