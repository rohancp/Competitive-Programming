import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;

// class Strength implements Comparable<Strength>{

// 	int x, y;

// 	// constructor...
// 	public Strength(int x, int y){

// 		this.x = x;
// 		this.y = y;
// 	}

// 	public int compareTo(Strength s) 
//     { 
//         return this.x - s.x; 
//     } 



// }
public class Dragons implements Comparable<Dragons>{

	int x1, y1;

	// constructor...
	public Dragons(int x1, int y1){

		this.x1 = x1;
		this.y1 = y1;
	}

	public int compareTo(Dragons s) 
    { 
        return this.x1 - s.x1; 
    } 

	public static void main(String [] args)throws IOException{

		// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			String s[] = br.readLine().split(" ");
			int sn = Integer.parseInt(s[0]);
			int n = Integer.parseInt(s[1]);
			ArrayList<Dragons> list = new ArrayList<Dragons>();
			while(n-- > 0){

				s = br.readLine().split(" ");
				int x,y;
				x = Integer.parseInt(s[0]);
				y = Integer.parseInt(s[1]);
				list.add(new Dragons(x, y));
			}
			Collections.sort(list);
			boolean win = true;
			// for
			for(int i = 0; i < list.size(); i++){

				// System.out.println("ROhan");
				// System.out.println(list.get(i).x+" "+list.get(i).y);
				if(sn > list.get(i).x1)
					sn += list.get(i).y1;
				else{
					win = false;
					break;
				}
			}
			if(win)
				System.out.println("YES");
			else
				System.out.println("NO");

		// }catch(Exception e){

		// 	return ;
		// }
	}
}