import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import java.lang.Math.*;
class Eof{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		while(input.hasNextLine()){
			String s = input.nextLine();
			String aa[] = s.split(" ");
			out.print(aa[0]+" "+aa[1]+" "+aa[2]+" "+aa[3]);
			if(s.isEmpty())
				System.exit(0);
			
		}
	}
}