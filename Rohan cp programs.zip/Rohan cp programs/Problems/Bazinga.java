
import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Bazinga{

	static boolean isprime[];
	static int size = (int)Math.pow(10, 5);

	private static Vector<Long> sieve(){


		isprime = new boolean[size+1];
		Arrays.fill(isprime, true);
		isprime[0] = isprime[1] = false;
		for(int i = 2; i *i <= size; i++){

			if(isprime[i]){

				for(int j = i*i; j <=  size; j += i)
					isprime[j] = false;
			}
		}
		Vector<Integer> vec = new Vector<Integer>();
		vec.add(2);
		for(int i = 3; i <= size ; i+=2){

			if(isprime[i])
				vec.add(i);
			if(vec.size()== 2001)
				break;
		}
		// System.out.println(vec);
		int count = 0;
		Vector<Long> results = new Vector<Long>();
		for(int i = 0; i < vec.size(); i++){

			for(int j = i+1; j < vec.size(); j++){
				results.add((long)vec.get(i) *(long) vec.get(j));
				if(results.size() == 2000000)
					break;
			}
			if(results.size() == 2000000)
				break;
		}
		Collections.sort(results);
		// System.out.println(results);
		// System.out.println(count);
		// System.out.println(results.get(2-1));
		// System.out.println(results.get(3-1));
		// System.out.println(results.get(5-1));
		// System.out.println(results.get(2000000-1));
		return results;
	}

	public static void main(String [] args)throws IOException{

		try{
			Vector<Long> result = sieve();
			// System.exit(0);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int k = Integer.parseInt(br.readLine());
				sb.append(result.get(k-1)).append("\n");
			}			
			System.out.println(sb);

		}catch(Exception e){

			return ;
		}
	}
}