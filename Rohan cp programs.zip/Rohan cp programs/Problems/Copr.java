import java.util.*;
import java.io.*;
import java.lang.*;
class Copr{


	private static long gcd(long a, long b){

		if(b == 0)	return a;
		return gcd(b, a%b);
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				long a = Long.parseLong(s[0]);
				long b = Long.parseLong(s[1]);
				if(gcd(a, b) == 1){
					long ans = (a*b - a - b)+1;
					sb.append(ans).append("\n");
				}
				else
					sb.append("-1").append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}