import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
public class Ebony{

 public static void main(String[] args)
 {
  
  MyScannercf1 sc=new MyScannercf1();
  int a=sc.nextInt();
  int b=sc.nextInt();
  int c=sc.nextInt();
  int flag=0;
  int i=0;
  
  for(i=0;i<=10000;i++)
  {
   if((c-i*b)%a==0)
   {
    if(((c-i*b)/a)<0)
     break;
    System.out.println("Yes");
    
    flag=1;
    break;
   }
  }
  if(flag==0)
   System.out.println("No");
  
 }

}
class MyScannercf1
{
 BufferedReader br;
 StringTokenizer st;
 MyScannercf1()
 {
  br=new BufferedReader(new InputStreamReader(System.in));
 }
 String next()
 {
  
  while(st==null || !st.hasMoreTokens())
  {
   try
   {
    st=new StringTokenizer(br.readLine());
   }
   catch(Exception e)
   {
    e.printStackTrace();
   }
  }
  return st.nextToken();
  
 }
 int nextInt()
 {
  return Integer.parseInt(next());
 }
 long nextLong()
 {
  return Long.parseLong(next());
 }
 double nextDouble()
 {
  return Double.parseDouble(next());
 }
 String nextLine()
 {
  String str="";
  try
  {
   str=br.readLine();
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
  return str;
  
 }
}