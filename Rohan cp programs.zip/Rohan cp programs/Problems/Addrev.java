import java.util.*;
import java.io.*;
import java.lang.*;

class Addrev{

	private static int reverseNumber(int n){

		int rev = 0;
		while(n != 0){
			rev = (rev*10) + (n%10);
			n /= 10;
		}
		return rev;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int a = Integer.parseInt(s[0]);
				int b = Integer.parseInt(s[1]);
				a = reverseNumber(a);
				b = reverseNumber(b);
				int result = reverseNumber(a+b);
				sb.append(result).append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}