import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Divisorsfactorial{

	static int mod = (int)(10e9)+7;

	static boolean isprime[] = new boolean[1001];

	static void sieve(){

		Arrays.fill(isprime, true);
		isprime[0] = isprime[1] = false;

		for(int i = 2; i * i <= 1000; i++){

			if(isprime[i]){

				for(int j = i*i; j <= 1000; j += i)
					isprime[j] = false;
			}
		}
	}

	static Vector<Integer> numberofprimes(int n){

		Vector<Integer> primes = new Vector<Integer>();

		for(int i = 2; i <= n; i++){

			if(isprime[i])
				primes.add(i);
		}
		return primes;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			sieve();

			int n =Integer.parseInt(br.readLine());
			Vector<Integer> primes = numberofprimes(n);
			// System.out.println(primes);
			long result = 1;
			for(int p : primes){

				long count = 0;

				while((n/p) != 0){

					count += (n/p);
					p *= p;
				}
				result = (result * (count+1))%mod;
			}
			System.out.println(result);

		}catch(Exception e){

			return ;
		}
	}
}