import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Chefideal{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			Random random = new Random();
			int num = random.nextInt(3)+1;
			System.out.println(num);
			int num2 = Integer.parseInt(br.readLine());
			int num3 = 6-num-num2;
			System.out.println(num3);
			System.out.flush();

		}catch(Exception e){

			return ;
		}
	}
}