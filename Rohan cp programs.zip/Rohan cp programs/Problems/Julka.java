import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Julka{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			for(int i = 0; i < 10; i++){
				String s = br.readLine();
				String s2 = br.readLine();
				BigInteger tog = new BigInteger(s);
				BigInteger k = new BigInteger(s2);
				BigInteger dif;
				dif = tog.subtract(k);
				BigInteger two = new BigInteger("2");
				BigInteger half = dif.divide(two);
				BigInteger klaudia;
				klaudia = half.add(k);
				System.out.println(""+klaudia+"\n"+""+half);
			}

		}catch(Exception e){

			return ;
		}
	}
}