import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Coinchange{


	private static int numberOf_ways(int arr[], int dp[][], int V, int i){

		if(V == 0)	return 1;

		if(i >= arr.length || V < 0)	return 0;

		if(dp[V][i] != -1)
			return dp[V][i];

		int ans1 = numberOf_ways(arr, dp, V-arr[i], i);
		int ans2 = numberOf_ways(arr, dp, V, i+1);
		dp[V][i] = ans1+ans2;
		return dp[V][i];
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int arr[] = new int[n];
			for(int i = 0; i <  n; i++){

				arr[i] = Integer.parseInt(s[i]);
			}
			int v = Integer.parseInt(br.readLine());
			int dp[][] = new int[v+1][n];
			for(int i =0 ; i < dp.length; i++){
				Arrays.fill(dp[i], -1);
			}
			int ans = numberOf_ways(arr, dp, v, 0);
			System.out.println(ans);

		}catch(Exception e){

			return ;
		}
	}
}