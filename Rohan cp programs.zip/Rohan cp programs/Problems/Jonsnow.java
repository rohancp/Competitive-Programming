/*
    @Rohan
    Basic Template
    key->brahmastra
*/
import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import java.lang.Math.*;
class Main {
    public static void main(String[] args) throws IOException {
        try{
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        InputReader in = new InputReader(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        Solver solver = new Solver();
        solver.solve(1, in, out);
        out.close();
    }catch(Exception e){
        return ;
    }
    }

    static class Solver {

        private static void prints(int dp[],PrintWriter out){
            int n = dp.length;
            for(int i = 0; i < 20; i++){
                out.println(i+" "+dp[i]);
            }
        }
        public void solve(int testNumber, InputReader sc, PrintWriter out) {
                
                int n = sc.nextInt();
                int k = sc.nextInt();
                int x = sc.nextInt();
                int dp1[] = new int[1024];
                int dp2[] = new int[1024];
                for(int i = 0; i < n; i++){
                    int a = sc.nextInt();
                    dp1[a]++;
                }
                // prints(dp1, out);
                for(int i = 0; i < k; i++){
                    int f = 1;
                    for(int j = 0; j < 1024; j++){
                        if(dp1[j] != 0){
                            // out.println(j);
                            if(f == 1){
                                int count = (1+dp1[j])/2;
                                dp2[x ^ j] += count;
                                // out.println(x^j);
                                if((dp1[j] & 1) == 1)
                                    f =2;
                            }
                        
                        else{
                            f = 1;
                            if(dp1[j] == 1){ dp2[j]++;continue;}
                            int count = dp1[j]/2;
                            dp2[x ^ j] += count;
                            if(((dp1[j] - 1) & 1) == 1)
                                f = 2;
                        }
                    }
                }
                    for(int j = 0; j < 1024; j++){
                        dp1[j] = dp2[j];
                        dp2[j] = 0;
                    }
            }
            // prints(dp1, out);
            // System.exit(0);
            int min,max;
            min = max = 0;
            for(int i = 0; i < 1024; i++){
                if(dp1[i] != 0){
                    min = i;
                    break;
                }
            }
            for(int i = 1023; i >= 0; i--){
                if(dp1[i] != 0){
                    max = i;
                    break;
                }
            }
            out.print(max+" "+min);
        }
    }

    static class InputReader {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private InputReader.SpaceCharFilter filter;
        private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        public InputReader(InputStream stream) {
            this.stream = stream;
        }

        public int read() {
            if (numChars == -1)
                throw new InputMismatchException();

            if (curChar >= numChars) {
                curChar = 0;
                try {
                    numChars = stream.read(buf);
                } catch (IOException e) {
                    throw new InputMismatchException();
                }

                if (numChars <= 0)
                    return -1;
            }
            return buf[curChar++];
        }

        public String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }

        public int nextInt() {
            int c = read();

            while (isSpaceChar(c))
                c = read();

            int sgn = 1;

            if (c == '-') {
                sgn = -1;
                c = read();
            }

            int res = 0;
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));

            return res * sgn;
        }

        public long nextLong() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            long res = 0;
            
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));
                return res * sgn;
        }

        public double nextDouble() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            double res = 0;
            while (!isSpaceChar(c) && c != '.') {
                if (c == 'e' || c == 'E')
                    return res * Math.pow(10, nextInt());
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            if (c == '.') {
                c = read();
                double m = 1;
                while (!isSpaceChar(c)) {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    m /= 10;
                    res += (c - '0') * m;
                    c = read();
                }
            }
            return res * sgn;
        }

         public String readString() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            StringBuilder res = new StringBuilder();
            do {
                res.appendCodePoint(c);
                c = read();
            } 
            while (!isSpaceChar(c));
            
            return res.toString();
        }

        public boolean isSpaceChar(int c) {
            if (filter != null)
                return filter.isSpaceChar(c);
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }
        public String next(){
            return readString();
        }

        public interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);
        }
    }
}