import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Eights{

	static long getValue(long k){

		long ans;
		// arithmetic progression formula...
		ans = 192 + (k-1)*250;
		return ans;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				long k = Long.parseLong(br.readLine());
				sb.append(getValue(k)).append("\n");
			}

			System.out.println(sb.toString());
		}catch(Exception e){

			return ;
		}
	}
}