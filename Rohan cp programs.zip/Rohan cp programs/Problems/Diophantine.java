import java.util.Scanner;
class Diophantine{

	private static int x,y,x0,y0;

	private static int extended_Euclidean(int a, int b){

		if(b == 0){

			x = 1;
			y = 0;
			return a;
		}
		int gcd = extended_Euclidean(b, a%b);
		int temp = x;
		x = y;
		y = temp - ((a/b)*y);
		return gcd;
	}

	private static boolean find_any_solution(int a, int b, int c){

		int gcd = extended_Euclidean(Math.abs(a), Math.abs(b));
		if((c % gcd) != 0)
			return false;

		x0 = (x *(c/gcd));
		y0 = (y * (c/gcd));

		if(a < 0)
			x0 *=-1;
		if(b < 0)
			y0 *= -1;
		return true;
	}
	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		boolean result = find_any_solution(a, b, c);
		if(result){
			System.out.println(x0+" "+y0);
		}else
		System.out.println("Solution doesn't exist!!....");

	}
}