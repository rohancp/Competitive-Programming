import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Comdiv{


	private static int _gcd(int A, int B){

		if(B == 0)	return A;
		return _gcd(B, A%B);
	}

	static int MAX = (int)(10e6);
	static int smalldiv[];
	private static void sieve(){

		smalldiv = new int[MAX + 1];
		for(int i =1; i <= MAX; i++)
			smalldiv[i] = i;

		for(int i = 2; i * i <= MAX; i++){

			if(smalldiv[i] == i){

				for(int j = i * i; j <= MAX; j += i){

					if(smalldiv[j] == j)
						smalldiv[j] = i;
				}
			}
		}
		// System.out.println(smalldiv[100000]+" "+smalldiv[50000]);
		// System.out.println(smalldiv[25000]+" "+smalldiv[12500]);
		// System.out.println(smalldiv[6250]+" "+smalldiv[3125]);
		// System.out.println(smalldiv[625]+" "+smalldiv[125]);
		// System.out.println(smalldiv[25]+" "+smalldiv[5]);
		return ;
	}

	private static int _numberOf_div(int n){

		if(n == 1)	return 1;

		int count = 1;
		int result = 1;
		while(n != 1){

			if(smalldiv[n] == smalldiv[n/smalldiv[n]])
				count++;
			else{
				result = result * (count + 1);
				count = 1;
			}
			n /= smalldiv[n];
		}
		return result;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			sieve();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int A = Integer.parseInt(s[0]);
				int B = Integer.parseInt(s[1]);
				int gcd = _gcd(A, B);
				int ans = _numberOf_div(gcd);
				sb.append(ans).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}