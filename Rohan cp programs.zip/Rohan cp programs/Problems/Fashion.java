import java.util.*;
import java.io.*;
import java.lang.*;

class Fashion{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb  = new StringBuilder();
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				int men[], women[];
				men = new int[N];
				women = new int[N];
				String s[] = br.readLine().split(" ");
				String ss[] = br.readLine().split(" ");
				for(int i = 0; i < N; i++){

					men[i] = Integer.parseInt(s[i]);
					women[i] = Integer.parseInt(ss[i]);
				}
				Arrays.sort(men);
				Arrays.sort(women);
				long result = 0;
				for(int i = 0; i < N; i++){

					long aa = men[i] * women[i];
					result += aa;
				}
				sb.append(result).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}