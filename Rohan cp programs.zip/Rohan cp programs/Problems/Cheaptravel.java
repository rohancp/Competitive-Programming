import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Cheaptravel{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n,m,a,b;
			n = Integer.parseInt(s[0]);
			m = Integer.parseInt(s[1]);
			a = Integer.parseInt(s[2]);
			b = Integer.parseInt(s[3]);
			if (m * a <= b)
        		System.out.println(n*a);
    		else 
        		System.out.println((n/m)*b + Math.min((n%m)*a, b));
		}catch(Exception e){

			return ;
		}
	}
}