import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Factmul{


	private static long mod = 109546051211L;

	private static long mulmod(long a, long b){

		long result = 0;
		a = a%mod;
		while(b > 0){

			if((b&1) == 1)
				result = (result + a)%mod;
			a = (a*2)%mod;
			b >>=1;
		}
		return result;

	}
	private static long finans(int n){


		long fact,prod;
		fact = prod = 1;
		for(int i = 1; i <= n; i++){

			fact = mulmod(fact, i);
			prod = mulmod(prod, fact);
			if(prod == 0)
				return 0L;
		}
		return prod;

	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			long ans = finans(n);
			System.out.println(ans);

		}catch(Exception e){

			return ;
		}
	}
}