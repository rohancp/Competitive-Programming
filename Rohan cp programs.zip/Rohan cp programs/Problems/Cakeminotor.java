import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Cakeminotor{

	public static void main(String [] args)throws IOException{

		// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int r = Integer.parseInt(s[0]);
			int c = Integer.parseInt(s[1]);
			int arr[][] = new int[r][c];
			for(int i = 0; i < r; i++){
				s= br.readLine().split("");
				for(int j = 0; j < c; j++){

					if(s[j].equals("S"))
						arr[i][j] = -1;
					else 
						arr[i][j] = 1;

				}
			}
			for(int i = 0; i < r; i++){

				boolean flag = true;
				for(int j = 0; j < c; j++){

					if(arr[i][j] == -1){
						flag = false;
						break;
					}
				}
				if(flag){
					for(int j= 0; j < c;j++){
						arr[i][j] = 0;
					}
				}
			}

			for(int i = 0; i < c; i++){

				boolean flag = true;

				for(int j = 0; j < r; j++){

					if(arr[j][i] == -1)
					{
						flag = false;
						break;
					}
				}
				if(flag){

					for(int j= 0; j < r;j++){
						arr[j][i] = 0;
					}
				}
			}

			int count = 0;
			for(int i = 0; i < r; i++){

				for(int j= 0; j < c; j++){

					if(arr[i][j] == 0)
						count++;
				}
			}
			System.out.println(count);


		// }catch(Exception e){

		// 	return ;
		// }
	}
}