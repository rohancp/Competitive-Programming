import java.util.Scanner;
import java.math.BigInteger;
class Bigmod{

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		BigInteger a, b, c;
		StringBuilder sb = new StringBuilder();
		while(input.hasNext()){

			a = input.nextBigInteger();
			b = input.nextBigInteger();
			c = input.nextBigInteger();
			System.out.println(a.modPow(b, c).toString());
		}

	}
}