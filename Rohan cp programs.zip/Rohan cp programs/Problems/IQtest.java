import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class IQtest{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			ArrayList<Integer> even = new ArrayList<Integer>();
			ArrayList<Integer> odd = new ArrayList<Integer>();
			for(int i = 0; i < n; i++){

				int ele = Integer.parseInt(s[i]);
				if((ele&1) == 1)
					odd.add(i+1);
				else
					even.add(i+1);
			}
			int ans = (even.size() > odd.size())? odd.get(0) :even.get(0);
			System.out.println(ans);

		}catch(Exception e){

			return ;
		}
	}
}