import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Gforce{

	static int MAX = (int)(10e7);
	static boolean isprime[];
	static int sum[];
	static int phi[];
	static int fact[];
	static int mod = (int)(10e9)+7;
	static void preCompute(){

		isprime = new boolean[MAX + 1];
		sum = new int[MAX + 1];
		phi = new int[MAX + 1];
		fact = new int[MAX + 1];

		Arrays.fill(isprime, true);

		isprime[0] = isprime[1] = false;

		for(int i = 4; i <= MAX; i += 2)
			isprime[i] = false;

		for(int i = 3; i *i <= MAX; i += 2){

			if(isprime[i]){

				for(int j = i*i; j <= MAX; j += i)
					isprime[j] = false;
			}
		}

	for(int i = 1; i <= MAX; i++){

		if(isprime[i])
			sum[i] = sum[i-1] + 1;
		else
			sum[i] = sum[i-1];
	}

	phi[1] = 1;
		for(int i = 2; i <= MAX; i += 2)
			phi[i] = i/2;

		for(int i = 3; i <= MAX; i += 2){

			if(phi[i] == 0){

				phi[i] = i-1;

				for(int j = i << 1; j <= MAX; j+=i){

					if(phi[j] == 0)
						phi[j] = j;
					phi[j] = phi[j]/i * (i - 1);
				}
			}
		}

		fact[0] = fact[1] = 1;

		for(int i = 2; i <= MAX; i++){

			long f = (i*(long)fact[i-1])%mod;
			fact[i] = (int)f;
		}
	}


	static long power(long a, long n){

		long result = 1;

		while(n != 0){

			if((n&1) == 1)
				result = (result * a)%mod;
			a = (a* a)%mod;
			n >>= 1;
		}
		return result;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			preCompute();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				long fn = sum[n] - phi[n];
				if(fn < 0)
					sb.append(1).append("\n");
				else{

					fn = power(phi[n], fact[n]);
					sb.append(fn).append("\n");
				}

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}