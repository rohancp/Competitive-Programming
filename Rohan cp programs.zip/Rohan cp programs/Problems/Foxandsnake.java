import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Foxandsnake{

	public static void main(String [] args)throws IOException{

		// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n,m;
			n = Integer.parseInt(s[0]);
			m = Integer.parseInt(s[1]);
			String s1 = "";
			String s2= "";
			for(int i = 0; i < m; i++){
				s1+="#";
				if((i+1) == m){
					s2 +="#";
					continue;
				}
				s2 +=".";
			}
			String s3 = "";
			// System.out.println(s1+" "+s2);
			for(int i = s2.length()-1; i >= 0; i--){
				s3 +=s2.charAt(i);
			}
			// System.out.println(s1);
			// System.out.println(s2);
			// System.out.println(s3);
			StringBuilder sb = new StringBuilder();
			for(int i = 1; i <= n; i++){

				int a = i;
				if(a%4 == 1)
					sb.append(s1);
				else if(a%4 == 2)
					sb.append(s2);

				else if(a%4 == 3)
					sb.append(s1);
				else if(a%4 == 0)
					sb.append(s3);
				sb.append("\n");

			}
			System.out.print(sb.toString());

		// }catch(Exception e){

		// 	return ;
		// }
	}
}