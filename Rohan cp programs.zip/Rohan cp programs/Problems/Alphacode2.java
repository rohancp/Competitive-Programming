import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Alphacode2{

	private static int mod = 7 +(int)(1e9);

	private static long possible_strings(String str){

		if(str.length() == 1){

			if(str.charAt(0) == '0')	return 0;
			return 1;
		}

		long dp[] = new long[str.length()];
		int n = Integer.parseInt(str.substring(0, 2));
		if(n >  26  && n%10 == 0)	return 0;

		if(n > 26 || n%10 == 0)
			dp[0] = dp[1] = 1;
		else
		{
			dp[0] = 1;
			dp[1] = 2;
		}

		for(int i = 2; i < str.length(); i++){

			 n = Integer.parseInt(str.substring(i-1, i+1));
			if(n == 0 || (n > 26  && n%10 == 0))	return 0;

			if(n < 10 || n > 26){
                dp[i] = dp[i-1];
                continue;
            }
            else if(n%10 == 0){
                dp[i] = dp[i-2];
                continue;
            }
            dp[i] = (dp[i-1] + dp[i-2])%mod;

		}
		return dp[str.length()-1];
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			while(true){


				String s = br.readLine();
				if(s.equals("0"))
					break;
				sb.append(possible_strings(s)).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}