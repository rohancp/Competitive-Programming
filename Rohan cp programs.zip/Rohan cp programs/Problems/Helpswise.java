/*
    @Rohan
    Basic Template
    key->brahmastra
*/
import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import java.lang.Math.*;
class Main {
    public static void main(String[] args) {
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        InputReader in = new InputReader(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        Solver solver = new Solver();
        solver.solve(1, in, out);
        out.close();
    }

    
    static class Solver {

        static int  min(int a, int b, int c){
        return Math.min(a, Math.min(b, c));
    }

    static boolean iscorrect(int a1, int a2, int a3, int a4){

        if(a1 > 9 || a2 > 9 || a3 > 9 || a4 > 9)
            return false;

        // pairwise distnict..
        if(a1 == a3 || a1 == a4 || a4 == a2 || a2 == a3 || a3 == a4 || a1 == a2)
            return false;
        return true;
    }
        public void solve(int testNumber, InputReader sc, PrintWriter out) {
            int r1 = sc.nextInt();
            int r2 = sc.nextInt();
            int c1 = sc.nextInt();
            int c2 = sc.nextInt();
            int d1 = sc.nextInt();
            int d2 = sc.nextInt();
            if(r1 >= 19 || r2 >= 19 || c1 >= 19 || c2 >= 19 || d1 >= 19 || d2 >= 19){
                out.print(-1);return ;
            }
            int a1,a2,a3,a4;
            int min = min(d1, c1, r1)-1;
            int i = 1;
            a1 = a2 = a3 = a4 = 0;
            boolean flag = false;
            while( i <= min){
                a1 = i;
                a2 = d1 - i;
                a3 = r1 - a1;
                a4 = c1 - a1;
                if(iscorrect(a1, a2, a3, a4)){
                    int row1,row2, col1, col2, dia1, dia2;
                    row1 = a1 + a3;
                    row2 = a4 + a2;
                    col1 = a1 + a4;
                    col2 = a3 + a2;
                    dia1 = a1 + a2;
                    dia2 = a3 + a4;
                    if(row1 == r1 && row2 == r2 && col1 == c1 && col2 == c2 && dia1 == d1 && dia2 == d2){
                        flag= !flag;
                        break;
                    }
                }
                i++;
            }
            if(flag){
                out.print(a1+" "+a3+"\n"+a4+" "+a2);
            }else{
                out.print(-1);
            }       
        }
    }

    static class InputReader {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private InputReader.SpaceCharFilter filter;
        private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        public InputReader(InputStream stream) {
            this.stream = stream;
        }

        public int read() {
            if (numChars == -1)
                throw new InputMismatchException();

            if (curChar >= numChars) {
                curChar = 0;
                try {
                    numChars = stream.read(buf);
                } catch (IOException e) {
                    throw new InputMismatchException();
                }

                if (numChars <= 0)
                    return -1;
            }
            return buf[curChar++];
        }

        public String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }

        public int nextInt() {
            int c = read();

            while (isSpaceChar(c))
                c = read();

            int sgn = 1;

            if (c == '-') {
                sgn = -1;
                c = read();
            }

            int res = 0;
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));

            return res * sgn;
        }

        public long nextLong() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            long res = 0;
            
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));
                return res * sgn;
        }

        public double nextDouble() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            double res = 0;
            while (!isSpaceChar(c) && c != '.') {
                if (c == 'e' || c == 'E')
                    return res * Math.pow(10, nextInt());
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            if (c == '.') {
                c = read();
                double m = 1;
                while (!isSpaceChar(c)) {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    m /= 10;
                    res += (c - '0') * m;
                    c = read();
                }
            }
            return res * sgn;
        }

         public String readString() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            StringBuilder res = new StringBuilder();
            do {
                res.appendCodePoint(c);
                c = read();
            } 
            while (!isSpaceChar(c));
            
            return res.toString();
        }

        public boolean isSpaceChar(int c) {
            if (filter != null)
                return filter.isSpaceChar(c);
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }
        public String next(){
            return readString();
        }

        public interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);
        }
    }
}