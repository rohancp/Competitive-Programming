import java.util.*;
import java.io.*;
import java.lang.*;

class Cequ{

	private static int gcd(int a, int b){

		if(b == 0)return a;
		return gcd(b, a % b);
	}

	private static boolean find_any_solution(int a, int b, int c){

		int gcd = gcd(a, b);
		// System.out.println(gcd);
		if((c % gcd ) != 0)
			return false;
		return true;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			int tc = Integer.parseInt(br.readLine());
			int i = 1;
			while(tc-- > 0){
				String s[] = br.readLine().split(" ");
				int a = Integer.parseInt(s[0]);
				int b = Integer.parseInt(s[1]);
				int c = Integer.parseInt(s[2]);
				boolean result = find_any_solution(a, b, c);
				if(result){
					sb.append("Case ").append(i).append(": Yes");
				}else{
					sb.append("Case ").append(i).append(": No");
				}
				sb.append("\n");i++;

			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}