import java.util.Scanner;
public class Diophantine2{

	private static int x, y;
	private static int g;
	private static int extended_Euclidean(int a, int b){

		if(b == 0){

			x = 1;
			y = 0;
			return a;
		}
		int gcd = extended_Euclidean(b, a % b);
		int temp = x;
		x = y;
		y = temp - ((a/b)*y);
		return gcd;
	}

	private static boolean find_any_solution(int a, int b, int c){

		g = extended_Euclidean(Math.abs(a), Math.abs(b));
		// System.out.println(g);
		if(Math.abs(c)%g != 0)	return false;
		
		x = x * (Math.abs(c)/g);
		y = y * (Math.abs(c)/g);

		if(a < 0)
			x *=-1;
		if(b < 0)
			y *=-1;
		return true;
	}

	private static void shift_solution(int a, int b, int cnt){

		x += (cnt * b);
		y -= (cnt * a);
	}
	private static int find_all_solution(int a, int b, int c, int minx, int maxx, int miny, int maxy){


			if(!find_any_solution(a, b, c))
				return 0;
			
			a /=g;
			b /=g;

			int sign_a = (a < 0)? -1 : 1;
			int sign_b = (b < 0)? -1 : 1;

			shift_solution(a, b, (minx - x)/b);
			if( x < minx)
				shift_solution(a, b, sign_b);
			if(x > maxx)
				return 0;
			int lx1 = x;

			shift_solution(a, b, (maxx - x) / b);
    		if (x > maxx)
        		shift_solution(a, b, -sign_b);
   			int rx1 = x;

   			shift_solution(a, b, -(miny - y) / a);
    		if (y < miny)
        		shift_solution(a, b, -sign_a);
    		if (y > maxy)
        		return 0;
    		
    		int lx2 = x;

    		shift_solution(a, b, -(maxy - y) / a);
    		if (y > maxy)
        		shift_solution(a, b, sign_a);
    		int rx2 = x;


    		if(lx2 > rx2){
    			int temp = rx2;
    			rx2 = lx2;
    			lx2 = temp;
    		}

    		int lx = Math.max(lx1, lx2);
    		int rx = Math.min(rx1, rx2);

    		if (lx > rx)
        		return 0;
        	return (rx - lx) / Math.abs(b) + 1;
	}

	public static void main(String [] args){


		Scanner input = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();
		int tc = input.nextInt();
		int i = 1;
		while(tc-- > 0){
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		int x1 = input.nextInt();
		int x2 = input.nextInt();
		int y1 = input.nextInt();
		int y2 = input.nextInt();

		int result = find_all_solution(a, b, c, x1, x2, y1, y2);
		sb.append("Case ").append(i).append(": ");
		sb.append(result).append("\n");
		i++;
	}
	System.out.print(sb.toString());
	}
}