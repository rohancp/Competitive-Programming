import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Beautifulmatrix{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int matrix[][] = new int[6][6];
			int row = -1,col = -1;
			for(int i = 0;i < 5; i++){

				String s[] = br.readLine().split(" ");
				for(int j =1; j <= 5; j++){

					matrix[i+1][j] = Integer.parseInt(s[j-1]);
					if(matrix[i+1][j] == 1){

						col = j;
						row = i+1;
					}
				}
			}
			int ans = Math.abs(3-row);
			ans += Math.abs(3-col);
			System.out.println(ans);

		}catch(Exception e){

			return ;
		}
	}
}