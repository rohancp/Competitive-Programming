import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Bitonic{


	private static void print(int arr[]){

		for(int i= 0; i < arr.length; i++)
			System.out.print(arr[i]+" ");
		System.out.println();
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int arr[] = new int[n];
			for(int i = 0; i < n; i++){

				arr[i] = Integer.parseInt(s[i]);
			}

			int dp1[] = new int[n];
			int dp2[] = new int[n];
			Arrays.fill(dp1, 1);
			Arrays.fill(dp2, 1);
			for(int i = 1; i < n; i++){

				int max = 0;

				for(int j = i-1; j >= 0; j--){

					if(arr[j] < arr[i])
						max = Math.max(max, dp1[j]);
				}

				dp1[i] +=max;

			}
			for(int i = n-2; i >=0; i--){


				int max= 0;
				for(int j = i+1; j <n; j++){

					if(arr[i] > arr[j])
						max = Math.max(dp2[j], max);
				}
				dp2[i] += max;
			}
			int max= 0;
			for(int i = 0; i < n; i++){

				max = Math.max(max, dp1[i]+dp2[i]-1);
			}
			System.out.println(max);

		}catch(Exception e){

			return ;
		}
	}
}