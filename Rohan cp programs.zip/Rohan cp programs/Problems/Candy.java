import java.util.*;
import java.io.*;
import java.lang.*;

class Candy{


	private static long make_packets_equal(int arr[], long sum, int N){

			long move = 0;
			if(sum %N == 0){

				long a = sum/N;
				for(int i = 0; i < N; i++){
					if(arr[i] > a)
						move += Math.abs(arr[i] - a);
				}
			}
			else
				move = -1;
			return move;
	}

	public static void main(String [] args)throws IOException{

		try{

			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			while(true){

				int N = Integer.parseInt(br.readLine());
				if(N == -1)break;
				int arr[] = new int[N];
				long sum = 0;
				for(int i = 0; i < N; i++){
					arr[i] = Integer.parseInt(br.readLine());
					sum += arr[i];
				}
				long result = make_packets_equal(arr, sum, N);
				sb.append(result).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}