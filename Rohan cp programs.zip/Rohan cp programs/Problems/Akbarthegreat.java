import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import static java.lang.Math.*;
 class Graph{
    int V;
    LinkedList<Integer> [] adjlist;
    public Graph(int V){
        this.V = V;
        adjlist = new LinkedList[V+1];
        for(int i = 0; i <= V; i++)
            adjlist[i] = new LinkedList<Integer>();
    }

    public void addEdge(int u, int v){
        adjlist[u].add(v);
        adjlist[v].add(u);
    }

    public void printgraph(PrintWriter out){
        for(int i = 1; i <= V; i++){

            out.print(i+" - > ");
            for(int j : adjlist[i])
                out.print(j+" ");
            out.println();
        }
    }
    boolean Dfs(int city, int sol, int strength, int protect[]){

        // mean this city is already protect by any other soldier.
        if(protect[city] != -1) return false;
        protect[city] = sol;
        if(strength == 0)   return true;

        for(int des : adjlist[city]){

            if(protect[des] == -1){
                if(!Dfs(des, sol, strength - 1, protect))   return false;
            }
            // if this city is already protected by any other soldier.
           else if(protect[des] != sol) return false;
            // this is protect by same soldier so no probelm.
            // if(protect[des] == sol) continue;

            

        }
        return true;
 
    }
 }
class Main implements Runnable {
    static class InputReader {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private SpaceCharFilter filter;
        private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 
        public InputReader(InputStream stream) {
            this.stream = stream;
        }
        
        public int read() {
            if (numChars==-1) 
                throw new InputMismatchException();
            
            if (curChar >= numChars) {
                curChar = 0;
                try {
                    numChars = stream.read(buf);
                }
                catch (IOException e) {
                    throw new InputMismatchException();
                }
                
                if(numChars <= 0)               
                    return -1;
            }
            return buf[curChar++];
        }
     
        public String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }
        public int nextInt() {
            int c = read();
            
            while(isSpaceChar(c)) 
                c = read();
            
            int sgn = 1;
            
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            
            int res = 0;
            do {
                if(c<'0'||c>'9') 
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c)); 
            
            return res * sgn;
        }
        
        public long nextLong() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            long res = 0;
            
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));
                return res * sgn;
        }
        
        public double nextDouble() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            double res = 0;
            while (!isSpaceChar(c) && c != '.') {
                if (c == 'e' || c == 'E')
                    return res * Math.pow(10, nextInt());
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            if (c == '.') {
                c = read();
                double m = 1;
                while (!isSpaceChar(c)) {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    m /= 10;
                    res += (c - '0') * m;
                    c = read();
                }
            }
            return res * sgn;
        }
        
        public String readString() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            StringBuilder res = new StringBuilder();
            do {
                res.appendCodePoint(c);
                c = read();
            } 
            while (!isSpaceChar(c));
            
            return res.toString();
        }
     
        public boolean isSpaceChar(int c) {
            if (filter != null)
                return filter.isSpaceChar(c);
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }
     
        public String next() {
            return readString();
        }
        
        public interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);
        }
    }
    public static void main(String args[]) throws Exception {
        new Thread(null, new Main(),"Main",1<<27).start();
    } 
    public void run() {
        InputReader sc = new InputReader(System.in);
        PrintWriter out = new PrintWriter(System.out);
         try{
        int tc = sc.nextInt();
        // out.println(tc);
        StringBuilder sb = new StringBuilder();
        while(tc-- > 0){
            int N = sc.nextInt();
            int R = sc.nextInt();
            int M = sc.nextInt();
            Graph g = new Graph(N);
            for(int i = 1; i <= R; i++){
                int u = sc.nextInt();
                int v = sc.nextInt();
                g.addEdge(u, v);
            }
            // g.printgraph(out);
            boolean flag = true;
            int protect[] = new int[N+1];
            Arrays.fill(protect, -1);
            // out.println(M);
            int count = 0;
            for(int i = 1; i <= M; i++){
                count++;
                int k = sc.nextInt();
                int strength = sc.nextInt();
                // out.println(k +" "+strength);
                boolean b = g.Dfs(k, k, strength, protect);
                // for(int j = 1; j <= N; j++)
                //     out.println(j+" -> "+protect[j]);
                // out.println("NEw");
                // out.println(b);
                if(!b){
                    flag = false;
                    break;
                }
            }
            // out.println(count);
            if(flag)
                sb.append("Yes");
            else
                sb.append("No");
            sb.append("\n");
        }
        out.print(sb);
        }catch(Exception e){
            out.println(e);
        }
       out.close();
    }
}