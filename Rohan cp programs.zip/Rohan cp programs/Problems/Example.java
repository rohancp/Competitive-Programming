import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Example{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			float y = 7.23f;
			int x = (int)y;
			System.out.println(x);

		}catch(Exception e){

			return ;
		}
	}
}