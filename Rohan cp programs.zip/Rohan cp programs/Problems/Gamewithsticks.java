import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Gamewithsticks{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n = Integer.parseInt(s[0]);
			int m = Integer.parseInt(s[1]);
			int mm = Math.min(n,m);
			if((mm&1) ==1)
				System.out.println("Akshat");
			else
				System.out.println("Malvika");

		}catch(Exception e){

			return ;
		}
	}
}