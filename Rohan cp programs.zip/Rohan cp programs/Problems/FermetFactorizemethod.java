import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;

// this algorithms applicable only on odd numbers...

	// n = a^2 - b^2;
	// a -> ceil(n);
	
class FermetFactorizemethod{

	private static void fermet(int n){

		if(n%2 == 0)	return ;

		int a = (int)Math.ceil(Math.sqrt(n));
		if(a*a == n){System.out.println(a);return;}
		int b;
		while(true){

			int b1 = a*a -n;
			b = (int)Math.sqrt(b1);
			if(b*b == b1)
				break;
			a +=1;
		}
		System.out.println((a+b)+" "+(a-b));
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			fermet(n);

		}catch(Exception e){

			return ;
		}
	}
}