import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class EvenArrays{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				int arr[] = new int[n];
				int zeroones = 0;
				int oneszero = 0;
				for(int i = 0; i < n; i++){

					arr[i] = Integer.parseInt(s[i]);
					if((i&1) != (arr[i]&1)){

						if((i&1) == 0)
							zeroones++;
						else
							oneszero++;
					}
				}
				if(oneszero != zeroones){
					sb.append("-1\n");
					continue;
				}
				sb.append(oneszero).append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}