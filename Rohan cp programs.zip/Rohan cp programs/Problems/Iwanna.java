import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Iwanna{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int p = Integer.parseInt(s[0]);
			int arr[] = new int[n+1];
			for(int  i = 1; i <= p; i++){

				int a = Integer.parseInt(s[i]);
				arr[a] = 1;
			}
			s= br.readLine().split(" ");
			p = Integer.parseInt(s[0]);
			for(int i = 1; i <= p; i++){

				int a = Integer.parseInt(s[i]);
				arr[a] = 1;
			}
			 int i ;
			for(i = 1; i <= n; i++){

				if(arr[i] == 0)	break;
			}
			if(i-1 != n)
				System.out.println("Oh, my keyboard!");
			else
				System.out.println("I become the guy.");

		}catch(Exception e){

			return ;
		}
	}
}