import java.util.*;
import java.io.*;
import java.lang.*;

class Factrl{


	private static int trailingZeros(int n){

		int count = 0;
		while(n != 0){

			count += (n/5);
			n /= 5;
		}
		return count;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				sb.append(trailingZeros(n)).append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}