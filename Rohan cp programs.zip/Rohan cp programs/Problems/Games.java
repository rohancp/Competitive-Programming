import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Games{

	public static void main(String [] args)throws IOException{

		try{

			// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			Scanner input = new Scanner(System.in);
			int n = input.nextInt();
			int arr[] = new int[n];
			int arr2[] = new int[101];
			for(int i = 0; i < n; i++){

				arr[i] = input.nextInt();
				int a = input.nextInt();
				arr2[a]++;
			}
			int count = 0;
			for(int i = 0; i < n; i++){

				int a = arr[i];
				count += arr2[a];
			}
			System.out.println(count);

		}catch(Exception e){

			return ;
		}
	}
}