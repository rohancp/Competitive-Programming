import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Lpalindromes{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s = br.readLine();
				int len = s.length();
				String a = s.substring(0, len/2);
				int c = 0;
				if(len%2 == 1)
					c = 1;
				String b = s.substring((len/2)+c, len);
				char ch1[] = a.toCharArray();
				char ch2[] = b.toCharArray();
				Arrays.sort(ch1);
				Arrays.sort(ch2);
				int i = 0;
				for( ;i < a.length(); i++){
					if(ch1[i] != ch2[i])
						break;
				}
				if(i != a.length())
					sb.append("NO");
				else
					sb.append("YES");
				sb.append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}