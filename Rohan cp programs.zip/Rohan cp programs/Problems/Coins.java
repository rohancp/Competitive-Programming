import java.util.*;
import java.io.*;
import java.lang.*;

class Coins{


	private static long coins_change(long dp[], int n){

		if(n < 10)
			return n;
		
		if( n < 1000000){

			if(dp[n] != 0)
				return dp[n];

			long ans1 = coins_change(dp, n/2) + coins_change(dp, n/3) + coins_change(dp, n/4);
			dp[n] = Math.max(n, ans1);
			return dp[n];
		}
		long ans1 = coins_change(dp, n/2) + coins_change(dp, n/3) + coins_change(dp, n/4);
	return Math.max(n, ans1);

	}
	public static void main(String [] args)throws IOException{

		try{

			// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			Scanner input = new Scanner(System.in);
			while(input.hasNext()){
				int n = input.nextInt();
			long dp[] = new long[1000000];
			long result = coins_change(dp, n);
			System.out.println(result);
}
		}catch(Exception e){

			return ;
		}
	}
}