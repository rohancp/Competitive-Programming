import java.util.*;
import java.io.*;
import java.lang.*;

public class Almostprime{

	private static int size = (int)(3e3);
	private static int prime[];
	private static int sum[];
	private static void sieve(){

		prime = new int[size+1];
		sum = new int[size+1];
		for(int i = 2; i <= size; i++){

			if(prime[i] == 0){
				prime[i]++;
				for(int j = i+i; j <= size; j+=i)
					prime[j]++;
			}
		}
		for(int i =1; i <= size; i++){

			if(prime[i] == 2)
				sum[i]++;
			sum[i] += sum[i-1];
		}

	}
	public static void main(String [] args)throws IOException{

			try{
				sieve();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			System.out.println(sum[n]);

		}catch(Exception e){

			return ;
		}
	}
}