import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class EvenArrays{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int n = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				int arr[] = new int[n];
				int countones = 0;
				for(int i = 0; i < n; i++){

					arr[i] = Integer.parseInt(s[i]);
					if((arr[i]&1) == 1)
						countones++;
				}

				int countodd = n/2;
				if(countodd >= countones){
					sb.append(countones);
				}
				else{
					sb.append("-1");
				}
				sb.append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}