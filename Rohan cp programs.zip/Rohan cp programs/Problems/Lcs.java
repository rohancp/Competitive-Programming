/*
    @Rohan
    Basic Template
    key->brahmastra
*/
import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import java.lang.Math.*;
class Main {
    public static void main(String[] args) throws IOException {
        try{
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        InputReader in = new InputReader(inputStream);
        PrintWriter out = new PrintWriter(outputStream);
        Solver solver = new Solver();
        solver.solve(1, in, out);
        out.close();
    }catch(Exception e){
        return ;
    }
    }

    static class Solver {

        private static int lcs(String s1, String s2){
            if(s1.isEmpty() || s2.isEmpty())    return 0;

            String one,two;
            one = s1.substring(1, s1.length());
            two = s2.substring(1, s2.length());
            if(s1.charAt(0) == s2.charAt(0))    return 1 + lcs(one, two);
            return Math.max(lcs(s1, two), lcs(one, s2));
        }
        private static int findmax(int dp[][], String s1, String s2, int m, int n){
            if(m == 0 || n == 0) {dp[m][n] = 0;return 0;}
            if(dp[m][n] != -1) return dp[m][n];

            String one,two;
            one = s1.substring(1, s1.length());
            two = s2.substring(1, s2.length());
            if(s1.charAt(0) == s2.charAt(0)){
                dp[m][n] = 1 + findmax(dp, one, two, m-1, n-1);
                return dp[m][n];
            }
            int ans1 = findmax(dp, s1, two, m, n-1);
            int ans2 = findmax(dp, one, s2, m-1, n);
            dp[m][n] = Math.max(ans1, ans2);
            return dp[m][n];
        }
        private static int lcs2(String s1, String s2, PrintWriter out){
            int m = s1.length();
            int n = s2.length();
            int dp[][] = new int[m+1][n+1];
            for(int i = 0; i <=m; i++)
                Arrays.fill(dp[i], -1);
            
             int ans = findmax(dp, s1, s2, m, n);
             for(int i = 0; i <= m; i++){
                for(int j = 0; j <= n; j++)
                    out.print(dp[i][j]+" ");
                out.println();
            }
            return ans;
        }
        public void solve(int testNumber, InputReader sc, PrintWriter out) {
                String s1 = sc.next();
                String s2 = sc.next();
                out.print(lcs2(s1, s2, out));
        }
    }

    static class InputReader {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private InputReader.SpaceCharFilter filter;
        private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        public InputReader(InputStream stream) {
            this.stream = stream;
        }

        public int read() {
            if (numChars == -1)
                throw new InputMismatchException();

            if (curChar >= numChars) {
                curChar = 0;
                try {
                    numChars = stream.read(buf);
                } catch (IOException e) {
                    throw new InputMismatchException();
                }

                if (numChars <= 0)
                    return -1;
            }
            return buf[curChar++];
        }

        public String nextLine() {
            String str = "";
            try {
                str = br.readLine();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return str;
        }

        public int nextInt() {
            int c = read();

            while (isSpaceChar(c))
                c = read();

            int sgn = 1;

            if (c == '-') {
                sgn = -1;
                c = read();
            }

            int res = 0;
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));

            return res * sgn;
        }

        public long nextLong() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            long res = 0;
            
            do {
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            while (!isSpaceChar(c));
                return res * sgn;
        }

        public double nextDouble() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            double res = 0;
            while (!isSpaceChar(c) && c != '.') {
                if (c == 'e' || c == 'E')
                    return res * Math.pow(10, nextInt());
                if (c < '0' || c > '9')
                    throw new InputMismatchException();
                res *= 10;
                res += c - '0';
                c = read();
            }
            if (c == '.') {
                c = read();
                double m = 1;
                while (!isSpaceChar(c)) {
                    if (c == 'e' || c == 'E')
                        return res * Math.pow(10, nextInt());
                    if (c < '0' || c > '9')
                        throw new InputMismatchException();
                    m /= 10;
                    res += (c - '0') * m;
                    c = read();
                }
            }
            return res * sgn;
        }

         public String readString() {
            int c = read();
            while (isSpaceChar(c))
                c = read();
            StringBuilder res = new StringBuilder();
            do {
                res.appendCodePoint(c);
                c = read();
            } 
            while (!isSpaceChar(c));
            
            return res.toString();
        }

        public boolean isSpaceChar(int c) {
            if (filter != null)
                return filter.isSpaceChar(c);
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }
        public String next(){
            return readString();
        }

        public interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);
        }
    }
}