import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Dreamoonstairs{


	static int getanswer(int n, int m){

		if( m > n)return -1;

		int i = 1;
		while( n > (i*m)*2){
			i++;
		}
		return i*m;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n = Integer.parseInt(s[0]);
			int m = Integer.parseInt(s[1]);
			int ans = getanswer(n, m);
			System.out.println(ans);
		}catch(Exception e){

			return ;
		}
	}
}