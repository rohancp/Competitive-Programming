import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Gcdextreme{

	static int MAX = (int)(10e6);
	static int phi[];
	static long S[];
	private static void preCompute(){

		phi = new int[MAX+1];
		phi[1] = 1;
		S = new long[MAX+1];
		
		for(int i = 2; i <= MAX; i += 2)
			phi[i] = i/2;

		for(int i = 3; i <= MAX; i += 2){

			if(phi[i] == 0){

				phi[i] = i-1;

				for(int j = i << 1; j <= MAX; j+=i){

					if(phi[j] == 0)
						phi[j] = j;
					phi[j] = phi[j]/i * (i - 1);
				}
			}
		}


		for(int i = 0; i <= MAX; i++)
			S[i] = phi[i];

		for(int i = 2; i < MAX; i++){

			for(int j = 2; j*i <= MAX; j++)
				S[i*j] += j*phi[i];
		}

		S[1] = 0;
		for(int i = 2; i <= MAX; i++)
			S[i] = S[i-1]+ S[i];
	}

	public static void main(String [] args)throws IOException{

		// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			preCompute();
			while(true){

				int n = Integer.parseInt(br.readLine());
				if(n == 0)	break;

				sb.append(S[n]).append("\n");
			}
			System.out.println(sb.toString());

		// }catch(Exception e){

		// 	return ;
		// }
	}
}