import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
public class Arrival{

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int n = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int arr[] = new int[n+1];
			for(int i = 0; i < n; i++){

				arr[i+1] = Integer.parseInt(s[i]);
			}
			int maxIndex,minIndex;

			maxIndex = 1;
			minIndex = n;
			for(int i = 2; i <= n; i++){

				if(arr[maxIndex] < arr[i])
					maxIndex = i;
			}

			for(int i = n-1; i >= 1; i--){

				if(arr[minIndex] > arr[i])
					minIndex = i;
			}
			int a = Math.abs(maxIndex-1);
			int b = Math.abs(minIndex-n);
			int ans = a+b;
			if(maxIndex > minIndex){

				System.out.println(ans-1);
			}
			else
				System.out.println(ans);


		}catch(Exception e){

			return ;
		}
	}
}