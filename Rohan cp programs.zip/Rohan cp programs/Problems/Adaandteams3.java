import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
import java.lang.Math.*;
class Main{

	static int MOD = 7 + (int)(10e9);
        static long fact[];
        static long ifact[];
        static int MAX = (int)(10e6);

        private static void precompute(){
                fact = new long[MAX + 1];
                ifact = new long[MAX + 1];
                fact[0] = ifact[0] = 1;
                for(int i = 1; i <= MAX; i++){
                    fact[i] = (i* fact[i-1]) % MOD;
                    ifact[i] = fastpower(fact[i], MOD - 2);
                }
        }

        private static long fastpower(long a, long b){
            long result = 1;
            while( b > 0){

                if((b&1) == 1)
                    result = (result * a) % MOD;
                a = (a * a) % MOD;
                b >>= 1;
            }
            return result;
        }

        private static long nCk(int n, int r){
            return fact[n] * ifact[r] % MOD * ifact[n - r] % MOD;
        }

	public static void main(String [] args){
		precompute();
		Scanner input = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();
		while(input.hasNextLine()){
			String s = input.nextLine();
			String inparr[] = s.split(" ");
			// out.print(aa[0]+" "+aa[1]+" "+aa[2]+" "+aa[3]);
			if(s.isEmpty())
				break;
			 int N, A, B, D;
            N = Integer.parseInt(inparr[0]);
            A = Integer.parseInt(inparr[1]);
            B = Integer.parseInt(inparr[2]);
            D = Integer.parseInt(inparr[3]);
			long ans = nCk(N, A) * fastpower(nCk(B, D) , A) % MOD;
			long a1 = nCk(N, A);
			long a2 = nCk(B, D);
			System.out.println(a1+" "+a2);
            sb.append(ans).append("\n");
		}
		// System.out.println("Rohan");
		System.out.print(sb);
	}
}
/*
#include <bits/stdc++.h>

typedef long long ll;

using namespace std;

int const N = 1e6 + 1;
int const MOD = 1e9 + 7;
int n, a, b, d, fact[N], ifact[N];

int fst(int b, int p) {
  if(p == 0)
    return 1;
  
  int res = 1ll * fst(b, p >> 1) % MOD;
  res = 1ll * res * res % MOD;
  
  if(p & 1)
    res = 1ll * res * b % MOD;
  
  return res;
}

int nCk(int n, i
nt k) {
  return 1ll * fact[n] * ifact[k] % MOD * ifact[n - k] % MOD;
}

int main() {
  fact[0] = ifact[0] = 1;
  for(int i = 1; i < N; ++i)
    fact[i] = 1ll * fact[i - 1] * i % MOD, ifact[i] = fst(fact[i], MOD - 2);
  
  while(scanf("%d %d %d %d", &n, &a, &b, &d) != EOF) {
    printf("%d\n", 1ll * nCk(n, a) * fst(nCk(b, d), a) % MOD);
  }
  
  return 0;
}


*/