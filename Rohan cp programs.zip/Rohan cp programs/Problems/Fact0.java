import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.BigInteger;
class Fact0{

	private static StringBuilder get_factorize(long num){

		long count = 0;
		StringBuilder sb = new StringBuilder();

		// using Wheel factorization method..

		while((num&1) != 1){
			count++;
			num >>= 2;
		}

		if(count != 0){
			sb.append(2).append("^").append(count).append(" ");
		}

		for(int i = 3; i*i <= num; i += 2){

			count = 0;
			while(num%i == 0){
				count++;
				num /=i;
			}
			if(count != 0){
				sb.append(i).append("^").append(count).append(" ");
			}
		}
		if(num > 1){

			sb.append(num).append("^").append(1).append(" ");
		}
		return sb;

	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb = new StringBuilder();
			while(true){

				long num = Long.parseLong(br.readLine());
				if(num == 0)	break;
				sb.append(get_factorize(num)).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}