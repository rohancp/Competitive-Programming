import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class PandaandChainReaction2{

	static int mod = 3 + (int)Math.pow(10, 6);

	private static long[] getFactorialArray(){

		long fact[] = new long[1000005];
		fact[0] = 1;
		for(int i = 1; i <= mod; i++){
			
			fact[i] = (fact[i-1] *i) % mod;
		}
		return fact;
	}


	private static int getAnswer(long N, long X, long fact[]){

		if( N >= mod)return 0;
		return (int)((X * fact[(int)N]) % mod);
	}
	public static void main(String [] args)throws IOException{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int tc = Integer.parseInt(br.readLine());
		long fact[] = getFactorialArray();
		StringBuilder sb = new StringBuilder();
		while(tc-- > 0){
			String s[] = br.readLine().split(" ");
			long N = Long.parseLong(s[0]);
			long X = Long.parseLong(s[1]);
			sb.append(getAnswer(N, X, fact)+"\n");
		}
		System.out.println(sb.toString());
	}
}