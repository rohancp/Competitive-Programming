/* i have use binomial coefficients beacause they provide ready formulas for certain frequent counting problems.


		\
		 \
		  \
	-------)  There are (n+k-1) ways to choose k elements from a set of n elements if repetitions are allowed..
		  /				(k    )
		 /
		/  	


*/
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Josepharray{

	private static long fact[];
	private static int MOD = 7 + (int)Math.pow(10, 9);
	private static int prime_factrz[];
	private static int size = (int)Math.pow(10, 6);
	private static int count[];
	private static void getFactorial(){
		fact = new long[size+1];
		fact[0] = fact[1] = 1;
		for(int i = 2; i <= size; i++)
			fact[i] = (fact[i-1] * i)%MOD;

	}
	private static void primefactorization(){

		prime_factrz = new int[size+1];

		for(int i = 2; i <= size; i++){

			if(prime_factrz[i] == 0){
				prime_factrz[i] = i;
				for(int j = i+i; j <= size; j += i)
					prime_factrz[j] = i;
			}
		}
	}

	private static long modularExp(long x, long n){

		if(n == 0)	return 1L;
		if(n%2 == 0)
			return modularExp((x*x)%MOD, n/2);
		return ((x%MOD)*modularExp((x*x)%MOD, (n-1)/2))%MOD;
	}

	private static long binomialCoefficeints(int n, int k){

		return (fact[n]%MOD * modularExp((fact[k]%MOD * fact[n-k]%MOD), MOD-2)%MOD)%MOD;
	}
	public static void main(String [] args)throws IOException{

		try{
			getFactorial();
			primefactorization();
			count = new int[size+1];
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int n = Integer.parseInt(s[0]);
			int k = Integer.parseInt(s[1]);
			s = br.readLine().split(" ");
			for(String a : s){
				int e = Integer.parseInt(a);
				while(e != 1){
					count[prime_factrz[e]]++;
					e = e/prime_factrz[e];
				}
			}
			long ans = 1;
			for(int i = 2; i <= size; i++){
				ans = (ans * (binomialCoefficeints(count[i]+k-1, k-1))%MOD)%MOD;
			}
			System.out.println(ans);

		}catch(Exception e){
			return ;
		}

	}
}