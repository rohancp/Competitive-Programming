import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
class Handshakes{


	public static void main(String []args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				long a = Long.parseLong(br.readLine());
				long ans = ((a*a)-a)/2;
				sb.append(ans+"\n");
				// System.out.println(ans);
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}