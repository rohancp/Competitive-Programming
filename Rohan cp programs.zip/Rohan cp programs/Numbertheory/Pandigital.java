import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
class Pandigital{

	private static int digit[];
	private static int size = (int)Math.pow(10, 6);

	// swap...

	public static String swap(String a, int i, int j) 
    { 
        char temp; 
        char[] charArray = a.toCharArray(); 
        temp = charArray[i] ; 
        charArray[i] = charArray[j]; 
        charArray[j] = temp; 
        return String.valueOf(charArray); 
    }

    // get all permutation of given String...

	private  void permute(String str, int l, int r) 
    { 
        if (l == r) {
            // System.out.println(str); 
            digit[Integer.parseInt(str)] = 1;
            return;
        }
        else
        { 
            for (int i = l; i <= r; i++) 
            { 
                str = swap(str,l,i); 
                permute(str, l+1, r); 
                str = swap(str,l,i); 
            } 
        } 
    }
	private  void Permutation(){

		digit = new int[size+1];
		Arrays.fill(digit, 0);
		String s = "";
		for(int i = 1; i <= 6; i ++){
			s = s+""+i+"";
			permute(s, 0, i - 1);
		}

		for(int i = 2; i <= size; i++){

			digit[i] += digit[i-1];
		}
	}
	public static void main(String [] args)throws IOException{

		try{
			Pandigital ob = new Pandigital();
			ob.Permutation();
			// System.exit(0);
			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int Queries = Integer.parseInt(br.readLine());
			while(Queries-- > 0){

				String s[] = br.readLine().split(" ");
				int L = Math.min(Integer.parseInt(s[0]),Integer.parseInt(s[1]));
				int R = Math.max(Integer.parseInt(s[0]),Integer.parseInt(s[1]));
				sb.append(digit[R] - digit[L-1]+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}