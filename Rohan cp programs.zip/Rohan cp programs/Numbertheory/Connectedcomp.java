import java.util.*;
import java.io.*;
import java.lang.*;
class Connectedcomp{

	private static int mod = (int)(1e9) + 7;
	private static long fact[];
	private static int size = (int)(1e5)+1;
	private static void build(){

		fact = new long[size];
		fact[0] = 1;
		for(int i = 1; i < size; i++){
			fact[i] = (i * fact[i-1])%mod;
		}
	}

	private static long modularexp(long x, long n){

		if(n == 0)	return 1L;

		if(n%2 == 0)
			return modularexp((x*x)%mod, n/2);
		return (x * modularexp((x*x)%mod,(n-1)/2))%mod;
	}

	private static long result(int k, int n){

		if( k == n)return 1L;
		if (Math.min(n, k) < 0) return 0;
    	if (k > n) return 0;

    	return (fact[n] * modularexp((fact[k] * fact[n - k]) % mod, mod - 2)) % mod;
	}
	public static void main(String [] args)throws IOException{


		try{
			build();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				String s[] = br.readLine().split(" ");
				int n = 2 + Integer.parseInt(s[0]);
				int m = 2 + Integer.parseInt(s[1]);
				int c = Integer.parseInt(s[2]);
				long result = (result(c - 1, n - m - 1) * result(c, m - 1)) % mod;
				sb.append(result).append("\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}