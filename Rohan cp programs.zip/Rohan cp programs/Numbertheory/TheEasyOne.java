import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class TheEasyOne{

	static int MOD = 7 + (int)Math.pow(10, 9);
	private static long[] factorial(){

		long dpArray[] = new long[1000001];
		dpArray[1] = 1;
		for(int i = 2; i <= 1000000; i++)
			dpArray[i] = (dpArray[i-1] * i)%MOD;

		return dpArray;
	}

	private static long modularExp(long x, long n){

		long result = 1;
		while( n > 0){

			if((n & 1) == 1)
				result = (result * x)%MOD;
			x = (x * x)%MOD;
			n >>=1;
		}
		return result;
	}
	public static void main(String []args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			long dp[] = factorial();
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				String num = br.readLine();
				long ans;
				int length = num.length();
				int count[] = new int[10];
				for(int i = 0; i < length; i++)
					count[num.charAt(i) - '0']++;
				ans = dp[length];
				for(int i = 0; i < 10; i++){
					if(count[i] > 1)
					ans = (ans * modularExp(dp[count[i]], MOD-2))%MOD;
				}
				sb.append(ans);
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}



/*





#include<iostream>
#include<cstring>
#define ll long long
#define mod 1000000007
using namespace std;

ll power(ll a,ll b){
ll res =1;
while(b>0){
if(b&1){
res = (res*a)%mod;
}
a = (a*a)%mod;
b = b>>1;
}

return res;
}
ll inv(ll n){
ll m = mod-2;
return power(n,m);
}

ll factorial(int n,ll dp[]){
if(dp[n]!=0){
return dp[n];
}

dp[n] = (n*factorial(n-1,dp))%mod;
return dp[n];
}
int main(){
int t;
cin>>t;
ll dp[1000007]={0};
dp[0]=dp[1]=1;
while(t--){
char s[100007];
cin>>s;
ll n = strlen(s);

ll c[10]={0};
for(ll i=0;i<n;i++){
c[s[i]-'0']++;
}
ll ans =factorial(n,dp);
for(int i=0;i<10;i++){
if(c[i]>1){
ans = (ans*inv(factorial(c[i],dp)))%mod;
}
}
cout<<ans<<endl;
}
}








*/