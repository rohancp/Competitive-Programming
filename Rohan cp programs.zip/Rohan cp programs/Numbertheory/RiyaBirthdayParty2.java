import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
class RiyaBirthdayParty2{

	static int mod = 7 +(int)Math.pow(10, 9);

	

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				long num = Long.parseLong(br.readLine());
				num %= mod;
				long ans = (num * num)%mod;
				ans = (ans*2)%mod;
				ans = (ans-num+mod)%mod;
				sb.append(ans+"\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}