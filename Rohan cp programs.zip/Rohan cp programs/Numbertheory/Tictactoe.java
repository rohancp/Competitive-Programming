import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Tictactoe{

	static int MOD = 7 + (int)Math.pow(10,9);


	private static long modularexp(long x, int n){

		if(n == 0)	return 1L;

		if(n %2 == 0){
			return modularexp((x*x)%MOD, n/2);
		}
		return (x*modularexp((x*x) %MOD, (n-1)/2))%MOD;
	}

	private static long getMaxanswer(long num, long six_inverse){

		long max_answer = (num * (num-1))%MOD;
		max_answer = (max_answer * ((2 * num) -1))%MOD;
		max_answer = (max_answer * six_inverse)%MOD;
		return max_answer;
	}
	private static long getMinanswer(long num){

			long minanswer = (num-1)/2;
			minanswer = (minanswer*minanswer)% MOD;
			minanswer = (minanswer * num) % MOD;
			return minanswer;

	}
		public static void main(String []args)throws IOException{

			try{

				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				int tc = Integer.parseInt(br.readLine());
				StringBuilder sb = new StringBuilder();
					long six_inverse = modularexp(6, MOD-2);
				while(tc-- > 0){
					long num = Integer.parseInt(br.readLine());
					long max_ans, min_ans;
					min_ans = getMinanswer(num);
					max_ans = getMaxanswer(num, six_inverse);
					sb.append(min_ans+" "+max_ans+"\n");
				}
				System.out.print(sb.toString());
			}catch(Exception e){
				return ;
			}
		}

}