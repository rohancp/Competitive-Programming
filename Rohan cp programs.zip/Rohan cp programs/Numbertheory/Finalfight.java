import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
class Finalfight{

	private static int MOD = (9)+(int)Math.pow(10, 9);
	private static long fact[];
	private static int size = 2*(int)Math.pow(10, 5);
	private static void factorial(){

		fact = new long[size+1];
		fact[0] = fact[1] = 1L;
		for(int i =2 ; i <= size; i++)
			fact[i] = (fact[i-1] * i)%MOD;
	}


	private static long _modularexp(long x, long n){

		if(n == 0 ) return 1L;
		if(n%2 == 0){
			return _modularexp((x*x)%MOD, n/2);
		}
		return (x * _modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}
	private static long moduloinverse(long x, long n){

		return _modularexp(x, n-2);
	}
	private static long catalannumber(int n){

		long num = fact[2*n];
		long den = (fact[n+1] * fact[n])%MOD;
		return (num * moduloinverse(den, MOD))%MOD;
	}
	public static void main(String [] args)throws IOException{

		try{
			factorial();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			long ans = catalannumber(N);
			System.out.println(ans);
		}catch(Exception e){
			return ;
		}
	}
}