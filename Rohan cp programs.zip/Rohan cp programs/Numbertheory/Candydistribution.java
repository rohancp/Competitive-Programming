import java.io.*;
import java.util.*;
import java.lang.*;
class Candydistribution{

	private static int mod = 7 + (int)Math.pow(10, 9);

	private static long modularexp(long x, long n){

		if(n == 0)	return 1L;

		if(n%2 == 0)
			return modularexp((x*x)%mod, n/2);
		return ((x%mod)*(modularexp((x*x)%mod, (n-1)/2))%mod)%mod;
	}

	private static long distribution(long n){

		long a = modularexp(2, n);
		long b = modularexp(3, n);
		long c = (a*a)%mod;
		b = (2*b)%mod;
		long ans = ((c - b + a)+mod)%mod;
		return ans;
	}


	public static void main(String [] args)throws IOException {


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				long n = Long.parseLong(br.readLine());
				long result = distribution(n);
				sb.append(result).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}

	}
}