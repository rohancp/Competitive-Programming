import java.io.*;
import java.util.*;
import java.lang.*;
class Archery2{

	private static long _gcd(long A, long B){

		if(B == 0)	return A;
		return _gcd(B, A%B);
	}

	private static long gettarget(long arr[], int N){

		long result = arr[0];
		for(int i = 1; i < N; i++)
			result = (result*arr[i])/_gcd(result, arr[i]);
		return result;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				long arr[] = new long[N];
				String s[] = br.readLine().split(" ");
				for(int i = 0; i < N; i++)
					arr[i] = Long.parseLong(s[i]);
				long result = gettarget(arr, N);
				sb.append(result).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}