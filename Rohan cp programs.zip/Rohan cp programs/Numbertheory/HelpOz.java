import java.util.Arrays;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class HelpOz{


	private static int mergeSort(int arr[], int s, int l, int k){

		if(s == l)	return arr[s] % k;

		int mid = (s + l) /2;
		int ans1 = mergeSort(arr, s, mid, k);
		if(ans1 == -1)	return ans1;
		int ans2 = mergeSort(arr, mid+1, l, k);
		if(ans2 == -1)	return ans2;
		if(ans1 != ans2)return -1;
		return ans2;
	}
	private static void get_k_value(int arr[], int size){

		// int first_min,second_min;
		// first_min = Math.min(arr[0], arr[1]);
		// second_min = Math.max(arr[0], arr[1]);
		String s = "";
		// for(int i = 2; i < size; i++){

		// 	if(first_min > arr[i]){
		// 		second_min = first_min;
		// 		first_min = arr[i];
		// 	}
		// 	if(first_min < arr[i] && arr[i] < second_min){
		// 		second_min = arr[i];
		// 	}
		// }

		Arrays.sort(arr);
		int second_min = Integer.MAX_VALUE;
		for(int i = 1; i < size; i++){
			if(second_min > (arr[i] - arr[i-1])){

				second_min = arr[i] - arr[i-1];
			}
		}
		int k = 2;
		while( k <= second_min){

			// boolean flag = true;

			// for(int i = 1; i < size; i++){

			// 	if((arr[i-1] % k) != (arr[i] % k)){
			// 		flag = false;
			// 		break;
			// 	}
			// }
			if(mergeSort(arr, 0, size-1, k) != -1)
			s += k+" ";
			k++;
		}
		System.out.println(s);
	}
		public static void main(String []args)throws IOException{

			try{

					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					int m = Integer.parseInt(br.readLine());
					int arr[] = new int[m];
					for(int i = 0; i < m; i++){
						arr[i] = Integer.parseInt(br.readLine());
					}
					get_k_value(arr, m);
			}
			catch(Exception e){
				return ;
			}
		}

}