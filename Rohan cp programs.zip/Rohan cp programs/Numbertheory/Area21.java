import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Area21{

	private static long phi[];
	private static int size = (int)Math.pow(10,6);
	private static int arr[];
	private static void EulerTotient(){

		phi = new long[size+1];
		for(int i = 1; i <= size; i++)
			phi[i] = i;

		for(int i = 2; i <= size; i++){

			if(phi[i] == i){
				phi[i]--;
				for(int j = 2*i; j <= size; j += i){
					phi[j] = (phi[j]*(i-1))/i;
				}
			}
		}
	}

	public static void main(String []args)throws IOException{

		try{
			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int N = Integer.parseInt(s[0]);
			int Q = Integer.parseInt(s[1]);
			arr = new int[N+1];
			s = br.readLine().split(" ");
			EulerTotient();
			for(int i = 1; i <=N; i++){
				int a = Integer.parseInt(s[i-1]);
				if(phi[a] == a-1)
					arr[i] = 1;
				else
					arr[i] = 0;
			}
			for(int i = 2; i <= N; i++)
				arr[i] += arr[i-1];
			while(Q-- > 0){
				s = br.readLine().split(" ");
				int L = Integer.parseInt(s[0]);
				int R = Integer.parseInt(s[1]);
				sb.append(arr[R]-arr[L-1]+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}

	}
}