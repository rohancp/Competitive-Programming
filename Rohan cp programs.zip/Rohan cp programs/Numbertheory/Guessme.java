import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Guessme{

		public static void main(String []a) throws IOException{
			try{

				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				int Quer = Integer.parseInt(br.readLine());
				StringBuilder sb = new StringBuilder();
				while(Quer-- > 0){

					int num = Integer.parseInt(br.readLine());
					int iter = num/2;
					int count = 0;
					for(; iter >= 1; iter--){
						if(num % iter == 0)
							count += iter;
					}
					sb.append(count+"\n");
				}
				System.out.println(sb.toString());
			}catch(Exception e){
				return ;
			}
		}
}