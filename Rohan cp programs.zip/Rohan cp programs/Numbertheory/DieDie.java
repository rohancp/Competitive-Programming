import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
class DieDie{

	private static int MOD = 7 + (int)Math.pow(10, 9);

	private static long modularexp(long x, long n){

		if(n == 0)	return 1L;

		if(n%2 == 0)
			return modularexp((x*x)%MOD, n/2);
		return (x * modularexp((x*x)%MOD,(n-1)/2))%MOD;
	}

	private static long ans(long N){

		long result = modularexp(2, N-1);
		result = modularexp(result, MOD-2);
		return result;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				long N = Long.parseLong(br.readLine());
				sb.append(ans(N)+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}