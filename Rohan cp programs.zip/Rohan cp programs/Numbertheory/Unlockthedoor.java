import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
class Unlockthedoor{

	private static int MOD = (7) + (int)Math.pow(10, 9);
	private static int size = (int)Math.pow(10, 5);
	// private static long fact[];
	// private static void factorial(){

	// 	fact = new long[size+1];
	// 	fact[0] = fact[1] = 1;
	// 	for(int i =2; i <= size; i++)
	// 		fact[i] = (fact[i-1] * i)%MOD;
	// }

	public static void main(String []args)throws IOException{

		// try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			// factorial();
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				String s[] = br.readLine().split(" ");
				int n = Integer.parseInt(s[0]);
				int k = Integer.parseInt(s[1]);
				long ans = 1;
				if(n == 1)
					ans = k;
				else{
					for(int i = 1; i <= n; i++){
						ans = (ans * k)%MOD;
						k--;
					}
				}
				sb.append(ans+"\n");
			}
			System.out.println(sb.toString());

		// }catch(Exception e)
		// {
		// 	return ;
		// }

	}
}