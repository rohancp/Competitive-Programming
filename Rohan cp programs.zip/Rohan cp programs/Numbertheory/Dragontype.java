import java.util.*;
import java.io.*;
import java.lang.*;
class Dragontype{

	private static long fermettheorem(long x, long n, int p){

		if(n == 0)return 1;
		if(n %2 == 0){
			return fermettheorem((x*x)%p, n/2, p);
		}
		return (x*fermettheorem((x*x)%p, (n-1)/2, p))%p;
	}

	private static long ModInverse(long i, int p){

		return fermettheorem(i, p-2, p);
	}

	public static void main(String[]args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s[] = br.readLine().split(" ");
			int N = Integer.parseInt(s[0]);
			int P = Integer.parseInt(s[1]);
			s = br.readLine().split(" ");
			int dp[] = new int[P];
			for(int i = 0; i < N; i++){

				long val = Long.parseLong(s[i]);
				dp[(int)val%P]++;
			}
			int count = 0;
			for(int i = 1; i < P; i++){

				if(dp[i] == 0)
					continue;
				long modinv = ModInverse(i, P);
				if(i != modinv){
					count += Math.max(dp[i], dp[(int)modinv]);
				}
				dp[i] = dp[(int)modinv] = 0;
			}
			System.out.println(count);

		}catch(Exception e){
			return ;
		}
	}
}