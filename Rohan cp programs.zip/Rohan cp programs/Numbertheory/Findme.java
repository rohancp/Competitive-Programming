import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Findme{

	public static void main(String [] args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String inp[] = br.readLine().split(" ");
			long N = Long.parseLong(inp[0]);
			long A = Long.parseLong(inp[1]);
			long B = Long.parseLong(inp[2]);
			System.out.println(N-A-B);
		}catch(Exception e){
			return ;
		}
	}
}