import java.io.*;
import java.util.*;
import java.lang.*;
class Archery{


	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				int arr[] = new int[N];
				int max = -1;
				for(int i = 0; i < N; i++){
					arr[i] = Integer.parseInt(s[i]);
					if(max < arr[i])
						max = arr[i];
				}
				// System.out.println(max);
				boolean flag = false;
				int kala = max;
				while(!flag){

					int count = 0;
					for(int i = 0; i < N; i++){
						if(max%arr[i] == 0)
							count++;
					}
					max += kala;
					// System.out.println(max);
					if(count == N)
						flag = true;
				}
				// System.out.println(flag);
				System.out.println(max-kala);

			}

		}catch(Exception e){

			return ;
		}
	}
}