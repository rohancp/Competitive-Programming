import java.util.*;
import java.io.*;
import java.lang.*;
class Trailing{


	public static void main(String [] args)throws IOException {

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
			long n = Long.parseLong(br.readLine());
				long count = 0;
				while(n >= 5){
					count += n/5;
					n /= 5;
				}
				// System.out.println(count);
				sb.append(count).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}