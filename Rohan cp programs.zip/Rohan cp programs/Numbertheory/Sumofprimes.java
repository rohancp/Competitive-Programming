import java.util.*;
import java.io.*;
import java.lang.*;
class Sumofprimes{

	private static int size = (int)Math.pow(10, 6);
	private static boolean isprime[];
	private static long Summation[];

	private static void sieve(){

		isprime = new boolean[size+1];
		Summation = new long[size+1];
		Arrays.fill(isprime, true);
		isprime[0] = isprime[1] = false;
		for(int i = 2; i*i <= size; i++){

			if(isprime[i]){

				for(int j = i*i; j <= size; j += i)
					isprime[j] = false;
			}
		}
		for(int i = 2; i <= size; i++){

			if(isprime[i]){
				Summation[i] = Summation[i-1] + i;
				continue;
			}
			Summation[i] = Summation[i-1];
		}
	}

	public static void main(String [] args)throws IOException{

		try{
			sieve();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(N-- > 0){

				String s[] = br.readLine().split(" ");
				int l, r;
				l = Integer.parseInt(s[0]);
				r = Integer.parseInt(s[1]);
				sb.append(Summation[r] - Summation[l-1]).append("\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}