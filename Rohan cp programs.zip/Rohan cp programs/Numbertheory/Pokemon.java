import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
class Pokemon{


	private static boolean[] sieve(){

		boolean isprime[] = new boolean[1000001];
		Arrays.fill(isprime, true);
		isprime[0] = isprime[1] = false;
		for(int i = 2; (i*i) <= 1000000; i++){

			if(isprime[i]){
				for(int j = i*i; j <= 1000000; j += i){
					isprime[j] = false;
				}
			}
		}
		return isprime;
	}

	private static int max = -1;
	private static int getfactors(int num){
		int count = 0;
		int i;
		for( i = 1; (i*i) < num; i++){
			if(num %i == 0)
				count += 2;
		}
		if((i*i) == num)
			count++;
		return count;
	}
	
	private static int[] find_factors(int n){
		int fact[] = new int[n+1];
		boolean isprime[] = sieve();
		for(int i = 1; i <= n; i++){
			if(isprime[i])
				fact[i] = 2;
				else{
					fact[i] = getfactors(i);
				}
			
			max = Math.max(fact[i], max);
		}
		return fact;
	}
	private static long[] getrange(int factors[]){

		long range[] = new long[max+1];
		for(int i = 1; i < factors.length; i++){
			range[factors[i]] = range[factors[i]] + 1;
		}
		for(int i = 2; i <= max; i++){
			range[i] += range[i-1];
		}
		return range;

	}
	public static void main(String []args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String inp[] = br.readLine().split(" ");
			int tc = Integer.parseInt(inp[0]);
			int n = Integer.parseInt(inp[1]);
			StringBuilder sb = new StringBuilder();
			int factors[] = find_factors(n);
			long range[] = getrange(factors);
			while(tc-- > 0){
				int k = Integer.parseInt(br.readLine());
				// System.out.println(factors[k]);
				sb.append(range[factors[k]-1]+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}