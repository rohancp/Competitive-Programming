import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class LoveTraingle{

	private static long getSeriesNumber(long num){

	
		StringBuilder sb = new StringBuilder();
		while(num > 9){
			sb.append(num%9);
			num /= 9;
		}
		long sum;
		sum = num;
		String ss = sb.toString();
		// System.out.println(ss);
		// int i = 0;
		while(ss.length() != 0){

			num = Long.parseLong(""+ss.charAt(ss.length()-1));
			sum = num + (10*sum);
			ss = ss.substring(0,ss.length()-1);
			// System.out.println(sum+" "+ss);
		// 	if(i == 1)
		// 	System.exit(0);
		// i++;
		}
		return sum;
	}

		public static void main(String []args){

			try{
				Scanner input = new Scanner(System.in);
				// String test_input = input.nextLine();
				StringBuilder sb = new StringBuilder();
				// System.out.println(test_input);
				while(input.hasNext() == true){
					String ss = input.nextLine();
					long num = Long.parseLong(ss);
					System.out.println(getSeriesNumber(num));
				}
				// System.out.println(sb.toString());
				input.close();
			}
			catch(Exception e){
				return ;
			}
		}
}