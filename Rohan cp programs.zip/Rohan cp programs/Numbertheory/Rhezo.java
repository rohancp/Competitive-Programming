import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Rhezo{

	private static int MOD = 7 + (int)Math.pow(10, 9);
	private static long modularexp(long x, long n){

		if(n == 0)return 1L;
		if(n%2 == 0){
			return modularexp((x*x)%MOD, n/2);
		}
		return (x * modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}
	public static void main(String [] args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			long A = Long.parseLong(br.readLine());
			String s = br.readLine();
			long B = 0;
			for(int i = 0; i < s.length(); i++){

				B = ((B*10) + (s.charAt(i)-48))%(MOD-1);
			}
			System.out.println(modularexp(A, B)); 

		}catch(Exception e){
			return ;
		}
	}
}