import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Luckystringjackpot{


	private static long getAnswer(long N){

		long level = 0;
		long length_of_lucky_string = 0;
		long number_of_nodes = 1;
		while( length_of_lucky_string < N){

			level += 1;
			number_of_nodes = number_of_nodes * 2;
			length_of_lucky_string += (number_of_nodes*level);
		}
		long ans = N - (length_of_lucky_string-(number_of_nodes * level));
		if(ans >= ((2*level)-1))
			return (2*level)-1;
		return ans;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				long N = Long.parseLong(br.readLine());
				long result = getAnswer(N);
				sb.append(result+"\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}

	}
}