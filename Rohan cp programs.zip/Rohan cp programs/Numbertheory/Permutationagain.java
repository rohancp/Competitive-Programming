import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Permutationagain{

	private static long[] getDP_table(){

		long dp[] = new long[100001];
		dp[1] = dp[2] = 1;
		for(int i = 3; i <= 100000; i++){

			//even..
			if((i&1) == 0){
				dp[i] = i+dp[i-1];
				continue;
			}
			dp[i] = (i-1) + dp[i-1];
		}
		return dp;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			long dp[] = getDP_table();
			while(tc-- > 0){
				int N = Integer.parseInt(br.readLine());
				sb.append(dp[N]+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}