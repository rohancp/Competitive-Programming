import java.util.*;
import java.io.*;
import java.lang.*;
class Countofintegers{

	private static int size = (int)Math.pow(10, 6);
	private static long sieve[];
	private static void Sieve(){

		sieve = new long[size+1];
		for(int i = 1; i <= size; i++)
			sieve[i] = i;
		for(int i = 2; i*i <= size; i++){

			if(sieve[i] == i){
				sieve[i]--;
				for(int j = 2 * i; j <= size; j += i){
					sieve[j] = ((sieve[j]*i) - sieve[j])/i;
				}
			}
		}
	}

	private static long divisors(long num){

		long count = 0;
		for(int i = 1; i <= (long)Math.sqrt(num); i++){

			if(num %i == 0){

				if(i*i == num)
					count++;
				else
					count += 2;
			}
		}
		return count;
	}
	public static void main(String [] args)throws IOException{


		try{
			Sieve();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				long N = Long.parseLong(br.readLine());
				sb.append(N-divisors(N)- sieve[(int)N]+1).append("\n");
			}	
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}