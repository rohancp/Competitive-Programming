import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
class Mogulovesnumbers{

	static int N = (int)Math.pow(10, 6);

	private static int[] getSieve(){

		int isprime[] = new int[N+1];
		Arrays.fill(isprime, 1);
		isprime[0] = isprime[1] = 0;
		for(int i = 2; (i*i) <= N; i++){

			if(isprime[i] == 1){

				for(int j = i*i; j <= N; j += i){
					isprime[j] = 0;
				}
			}
		}

		for(int i = 1; i <= N; i++){
			isprime[i] += isprime[i-1];
		}
		return isprime;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int Queries = Integer.parseInt(br.readLine());
			int isprime[] = getSieve();
			StringBuilder sb = new StringBuilder();
			while(Queries-- > 0){
				String inp[] = br.readLine().split(" ");
				int num1 = Integer.parseInt(inp[0]);
				int num2 = Integer.parseInt(inp[1]);
				int L = Math.min(num1, num2);
				int R = Math.max(num1, num2);
				int count = isprime[R] - isprime[L-1];
				sb.append(count+"\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}