import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Mystery{


	private static int getResult(int num){

		/*int iter = num/2;
		int count = 0;
		while(iter != 0){
			if(num % iter == 0)	count++;
			iter--;
		}
		return count+1;*/

		// optimize version is...
		int count = 0;
		int n = (int)Math.sqrt(num);
		for(int i = 1; i <= n; i++){

			if(num % i == 0){

				if(num/i == i){
					count+=1;continue;
				}
				count += 2;
			}
		}
		return count;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int Quer = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(Quer-- > 0){

				int num = Integer.parseInt(br.readLine());
				sb.append(getResult(num)+"\n");
			}
			System.out.println(sb.toString());
		}
		catch(Exception e){
			return ;
		}
	}
}