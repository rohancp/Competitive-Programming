import java.io.*;
import java.lang.*;
import java.util.*;
class Nearestprimes{

	private static int size = (int)Math.pow(10, 6);
	private static boolean isprime[];
	private static int prefixprime[];
	private static int suffixprime[];
	private static void seive(){

		isprime = new boolean[size+1];
		Arrays.fill(isprime, true);

		for(int i = 2; i*i <= size; i++){

			if(isprime[i]){

				for(int j = i*i; j <= size; j+=i)
					isprime[j] = false;
			}
		}

		prefixprime = new int[size+1];
		suffixprime = new int[size+1];
		prefixprime[1] = 1;
		prefixprime[2] = 2;
		int val = 2;
		for(int i = 3; i <= size; i++){
			if(isprime[i]){
				prefixprime[i] = i;
				val = i;
			}
			else{
				prefixprime[i] = val;
			}
		}
		 val = 1000003;
		for(int i = size; i >= 2; i--){
			if(isprime[i]){
				suffixprime[i] = i;
				val = i;
			}
			else{
				suffixprime[i] = val;
			}
		}

	}
	private static int getAns(int N){

		// if(Math.abs(N-prefixprime[N]) == Math.abs(N - suffixprime[N]))
		// 	return prefixprime[N];
		if(Math.abs(N-prefixprime[N]) <= Math.abs(N - suffixprime[N])){
			return prefixprime[N];
		}
		return suffixprime[N];
	}

	public static void main(String [] args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			seive();
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				sb.append(getAns(N)+"\n");

			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}