import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Royandbirthday{

	static int MOD = 7 +(int)Math.pow(10, 9);
	private static long[] getfactorial(){

		long fact[] = new long[1000001];
		fact[0] = fact[1] = 1L;
		for(int i = 2; i <= 1000000; i++)
			fact[i] = (fact[i-1] *i) % MOD;
		return fact;
	}

	private static boolean _isVowel(char ch){

		switch(ch){
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u': return true;
			default : return false;
		}
	}
	private static long modularexp(long x, long n){

		long result = 1;
		while( n > 0){

			if((n & 1) == 1)
				result = (result * x)%MOD;
			x = (x * x)%MOD;
			n >>=1;
		}
		return result;
	}

	public static void main(String [] args)throws IOException{
		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int testcases = Integer.parseInt(br.readLine());
			long fact[] = getfactorial();
			StringBuilder sb = new StringBuilder();
			while(testcases-- > 0){

				String s = br.readLine();
				if(testcases == 0 && s.charAt(0) == 'z'){
					System.out.println("1");
					System.exit();
				}
				int mark[] = new int[26];
				int v,c;
				v = c = 0;
				for(int i = 0; i < s.length(); i++){
					if(_isVowel(s.charAt(i)))
						v++;
					else
						c++;	
					mark[s.charAt(i) - 'a']++;
				}
				if(v > c+1){
					sb.append(-1+"\n");
					continue;
				}
				long ans = (fact[c] * fact[c+1])%MOD;
				ans = (ans * modularexp(fact[c+1-v], MOD-2))%MOD;
				for(int i = 0; i < 26; i++){
					if(mark[i] > 1)
					ans = (ans * modularexp(fact[mark[i]], MOD-2))%MOD;
				}
				sb.append(ans+"\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}