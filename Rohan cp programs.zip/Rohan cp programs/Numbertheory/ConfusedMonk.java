import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class ConfusedMonk{


	static int MOD = 7 + (int)Math.pow(10, 9);


	private static long modularExponentiation(long x, long n){

		if(n == 0)	return 1;

		if(n%2 == 0)
		return modularExponentiation((x * x) % MOD, n/2);

		return (x * modularExponentiation((x * x) % MOD, (n-1)/2)) % MOD;

	}

	private static int GCD(int A, int B){

		if(B == 0)
			return A;
		return GCD(B, A % B);
	}
	private static long getanswer(int array[], int N){

		int gcd_ovrall = 0;
		for(int i = 0; i < N; i++){
			gcd_ovrall = GCD(array[i], gcd_ovrall);
		}

		long fx = 1;
		for(int i = 0; i < N; i++){
			fx = (fx * array[i]) % MOD;
		}

		long ans = modularExponentiation(fx, gcd_ovrall);
		return ans;

	}

			public static void main(String [] args)throws IOException{

				try{

					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					int N = Integer.parseInt(br.readLine());
					int array[] = new int[N];
					String inp[] = br.readLine().split(" ");
					for(int i = 0; i < N; i++){
						array[i] = Integer.parseInt(inp[i]);
					}
					System.out.println(getanswer(array, N));

				}catch(Exception e){
					return ;
				}
			}
}