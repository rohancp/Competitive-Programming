import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Permutationagain2{

	public static void main(String [] args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				long num = Long.parseLong(br.readLine());
				if(num <=2){
					sb.append(1+"\n");
					continue;
				}
				if((num&2) == 0){
					long term = (num-2)/2;
					term = (term*(term+1))*2;
					term = term + (num-1);
					sb.append(term+"\n");
					continue;
				}

				long m = (num/2);
				m = ((m)*(1+(num-2)))/2;
				m *=2;
				m--;
				m = m+(num-1);
				sb.append(m+"\n");
			}
			System.out.println(sb.toString());
		}
		catch(Exception e){
			return ;
		}
	}
}