import java.util.Scanner;
class Triplet{

	int x;
	int y;
	int gcd;
}
class ExtendedEucild{

	private static Triplet extendedEuclid(int a, int b){

		if(b == 0){
			Triplet ans = new Triplet();
			ans.gcd = a;
			ans.x = 1;
			ans.y = 0;
			return ans;
		}
		Triplet ans = new Triplet();
		Triplet smallans = extendedEuclid(b, a%b);
		ans.x = smallans.y;
		ans.y = smallans.x - (a/b)*smallans.y;
		ans.gcd = smallans.gcd;
		return ans;
	}

	public static void main(String [] args){

		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		Triplet ans = extendedEuclid(a, b);
		System.out.println(ans.gcd);
		System.out.println(ans.x+" "+ans.y);

	}
}