import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
class Deadpoolset{

	private static int MOD = 7 +(int)Math.pow(10, 9);
	private static int size = (int)Math.pow(10, 6);

	private static long getResult(long dparray[]){


		for(int i = 2; i <= size; i++){
// System.out.println(i+" "+dparray[i]);
			if(dparray[i] != 0){
				// System.out.println(i);
			for(int j = 2; ((j*i) <= size) && (j <= i); j++){

				if(dparray[j*i] !=0){

					long a = 0;
					if(j == i)
						 a = ((dparray[j]%MOD) * (dparray[i]%MOD))%MOD;	
					else
					 a = ((dparray[j]%MOD) * (dparray[i]%MOD) *(2L))%MOD;
					dparray[j*i] = ((dparray[j*i]%MOD) + a)%MOD;
				}

			}
		}
		}
		long result = 0;
		// System.out.println(dparray[2]+" "+dparray[4]+" "+dparray[8]+" "+dparray[10]);
		for(int i = 2; i <= size; i++){

				result = (result %MOD + dparray[i]%MOD)%MOD;
		}
		return result;
	}
	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			long dparray[] = new long[size+1];
			Arrays.fill(dparray, 0L);
			// Maintain dp table....
			for(int i = 0; i < N; i++){
				int a = Integer.parseInt(br.readLine());
				if(a == 1)	continue;
				dparray[a] = 1L;
			}
			// System.out.println(dparray[2]+" "+dparray[4]+" "+dparray[8]+" "+dparray[10]);
		long result = getResult(dparray);
		System.out.println(result);

		}catch(Exception e){
			return ;
		}
	}
}