import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
class Beautifulprimes{


	private static int MOD = 7 + (int)Math.pow(10, 9);

	private static long modularexp(long x, long n){

		if(n == 0)	return 1L;

		if(n%2 == 0)
			return modularexp((x*x)%MOD, n/2);
		return ((x%MOD) * modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int x = Integer.parseInt(br.readLine());
				int pi[] = new int[x];
				long ai[] = new long[x];
				String s[] = br.readLine().split(" ");
				String s2[] = br.readLine().split(" ");
				long ans = 1L;
				for(int i = 0; i < x; i++){
					pi[i] = Integer.parseInt(s[i]);
					ai[i] = Long.parseLong(s2[i]);
					long a = modularexp(pi[i], ai[i]+1)-pi[i];
					if(a < 0) a +=MOD;
					ans = ((ans%MOD) * (((a%MOD) * modularexp(pi[i]-1, MOD-2))%MOD))%MOD;
				}
				sb.append(ans+"\n");
			}
			System.out.print(sb.toString());

		}catch(Exception e){

			return ;
		}
	}
}