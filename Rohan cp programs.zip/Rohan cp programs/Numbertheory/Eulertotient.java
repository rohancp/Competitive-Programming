import java.util.Scanner;
class Eulertotient{

	private static int size = 1000000;
	private static int phi[];
	private static void Sieve(){

		phi = new int[1000001];
		for(int i = 1; i <= size; i++)
			phi[i] = i;
		for(int i = 2; i <= size; i++){

			if(phi[i] == i){

				phi[i]--;
				for(int j = i+i; j <= size; j+=i){

					phi[j] = ((phi[j]*i)-phi[j])/i;
				}
			}
		}
	}

	public static void main(String [] args){

		Scanner  input = new Scanner(System.in);
		int N = input.nextInt();
		Sieve();
		System.out.println(phi[N]);

	}
}