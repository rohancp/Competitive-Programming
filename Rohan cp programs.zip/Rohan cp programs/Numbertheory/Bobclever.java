import java.util.*;
import java.io.*;
import java.lang.*;
class Bobclever{

	private static int size = (int)Math.pow(10, 6);
	private static int prime[];
	private static void sieve(){

		prime = new int[size+1];
		prime[0] = prime[1] = 0;
		for(int i = 2; i*i <= size; i++){

			if(prime[i] == 0){
				prime[i] = i;
				for(int j = i*i; j <= size; j += i)
				{
					if(prime[j] == 0)
						prime[j] = i;
				}
			}
		}

	}

	private static long div(LinkedHashMap<Integer, Integer> map, int num){

		long count = 0;
		while(num > 1){

				int a = num/prime[num];
				// System.out.println(prime[num]);
				if(a != prime[num]){
					if(map.containsKey(prime[num])){
						count += map.get(prime[num]);
					}
				}
				num = a;
		}
		if(map.containsKey(num)){

			count += map.get(num);
		}
		// System.out.println("Ff");
		return count;
	}

	private static long getanswer(LinkedHashMap<Integer, Integer> map, int arr[],int N){


		long count = 0;
		for(int i = 0; i < N; i++){

			if(prime[arr[i]] != arr[i]){

				// System.out.print(arr[i]);
				count += div(map, arr[i]);
			}
		}

		for(Map.Entry<Integer, Integer> set : map.entrySet()){

			if(map.get(set.getKey()) > 1){
				int val = map.get(set.getKey());
				count += ((val * (val-1))/2);
			}
		}
		return count;
	}

	public static void main(String [] args)throws IOException {


		try{
			sieve();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				int N = Integer.parseInt(br.readLine());
				String s[] = br.readLine().split(" ");
				int arr[] = new int[N];
				LinkedHashMap<Integer, Integer> map = new LinkedHashMap<Integer, Integer>();
				for(int i = 0; i < N; i++){
					arr[i] = Integer.parseInt(s[i]);
					if(map.containsKey(arr[i])){
						map.put(arr[i], map.get(arr[i])+1);
					}else{
						map.put(arr[i], 1);
					}
				}
				// System.out.println("rr");
				long res = getanswer(map, arr, N);
				sb.append(res).append("\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){

			return ;
		}
	}
}