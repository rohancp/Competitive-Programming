import java.util.*;
import java.io.*;
import java.lang.*;
class Bbmath{

	private static long mod = 7 + (long)Math.pow(10, 9);
	private static boolean isprime[];
	private static int size = (int)Math.pow(10, 6);
	private static void Sieve(){

		isprime = new boolean[size+1];
		Arrays.fill(isprime, true);
		isprime[0] = isprime[1] = false;
		for(int i = 2; i*i <= size; i++){

			if(isprime[i]){
				for(int j = i*i; j <= size; j += i)
					isprime[j] = false;
			}
		}

	}

	private static void print(long arr[], int N){
		for(int i = 1; i <= N; i++){
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	private static long modularexp(long x, long n){

		long result = 1;
		while( n > 0){

			if(n%2 == 1){

				result = ((result%mod)*(x%mod))%mod;
			}
			x = ((x%mod)*(x%mod))%mod;
			n /= 2;
		}
		return result;
	}
	private static long calculate(long arr[], int N){

		long primesubsets[] = new long[N+1];
		long compsubsets[] = new long[N+1];
		int val = (int)arr[1];
		boolean flag_val;
		flag_val = isprime[val];
		if(flag_val){
			primesubsets[1] = 1;
		}else{
			compsubsets[1] = 1;
		}

		for(int i = 2; i <= N; i++){

			val = (int)arr[i];
			flag_val = isprime[val];

			for(int j = i-1; j >=1; j--){

				if(primesubsets[j] != 0){

					if(flag_val){
						primesubsets[j+1] += primesubsets[j];
					}else{
						primesubsets[j] += primesubsets[j];
					}
				}
				if(compsubsets[j] != 0){

					if(flag_val){

						primesubsets[1] += compsubsets[j];

					}else{

						compsubsets[j+1] += compsubsets[j];

					}
				}

			}
			if(flag_val){

				primesubsets[1] += 1;
			}else{

				compsubsets[1] += 1;
			}
		}

		long result = 1;
		for(int i = 1; i <=N; i++){

			if(primesubsets[i] != 0){

				result = ((result%mod) * (modularexp(i+2, primesubsets[i])%mod))%mod;

			}

			if(compsubsets[i] != 0){

				result = ((result%mod) * (modularexp(2, compsubsets[i])%mod))%mod;

			}
		}
		// print(primesubsets, N);
		// print(compsubsets, N);
		return (2*result)%mod;
	}
	public static void main(String [] args)throws IOException {

		try{

			Sieve();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){

				int N = Integer.parseInt(br.readLine());
				long arr[] = new long[N+1];
				String s[] = br.readLine().split(" ");
				for(int i = 0; i < N; i++){
					arr[i+1] = Long.parseLong(s[i]);
				}
				long result = calculate(arr, N);
				sb.append(result).append("\n");
			}
				System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}