import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Pokemon2{

	private static int sieve[];
	private static int factors[];
	private static long range[];
	private static void Sieve(int n){

		sieve = new int[n+1];
		for(int i = 1; i <= n; i++)
			sieve[i] = i;
		for(int i = 2; (i*i) <= n; i++){

			if(sieve[i] == i){
				for(int j = i*i; j <= n; j += i){

					if(sieve[j] == j)
						sieve[j] = i;
				}
			}
		}
	}

	private static int getfactor(int num){

		if(num == 1)return 1;
		if(sieve[num] == num)	return 2;

		int result = 1;
		int count = 1;
		int prev;
		prev = sieve[num];
		num = num/sieve[num];
		while(num > 1){
			if(sieve[num] != prev){
				result = result * (1+count);
				count = 0;
			}
			prev = sieve[num];
			num /= sieve[num];
			count++;
		}
		result = result * (1 + count);
		return result;
	}


	private static void print(long arr[]){

		for(int i = 1; i < arr.length; i++)
			System.out.println(arr[i]);
	}
	private static void Factors(int n){
		factors = new int[n+1];
		Sieve(n);
		int max = -1;
		for(int i = 1; i <= n; i++){

			factors[i] = getfactor(i);
			max = Math.max(factors[i], max);
		}
		// print(factors);
		range = new long[max+1];
		for(int i = 1; i <= n; i++){
			range[factors[i]]++;
		}
		// print(range);
		for(int i = 2; i <= max; i++){
			range[i] += range[i-1];
		}
		// print(range);

	}
	public static void main(String []args)throws IOException{

		try{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s[] = br.readLine().split(" ");
		int tc = Integer.parseInt(s[0]);
		int n = Integer.parseInt(s[1]);
		Factors(n);
		StringBuilder sb = new StringBuilder();
		while(tc-- > 0){

			int k = Integer.parseInt(br.readLine());
			sb.append(range[factors[k]-1]+"\n");
		}
		System.out.println(sb.toString());
	}catch(Exception e){
		return ;
	}
	}
}