import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
class PandaandChainReaction{


	static int mod = 3 + (int)Math.pow(10, 6);

		private static int getAnswer(long N, long X){



			int fact[] = new int[1000004];
			Arrays.fill(fact, 1);
			for(int i = 1; i <= mod; i++){
				long a = fact[i-1] * i;
				fact[i] = (int)(a  % mod);
			}
			if(N > mod)return 0;

			return (int)(fact[(int)N] * X)%mod;


			// /*if(N == 0 || N == 1) return (int)(X % mod);
			// if(N == 2){
			// 	 int a = (int)(X % mod);
			// 	 int b = (int)(N % mod);
			// 	 long ab = a*b;
			// 	 return (int)(ab %mod);
			// }
			// int ans = getAnswer(N-3, X);
			// int K = (int)(N % mod);
			// long a;
			// a =  (int)((N-1)%mod) * (int)((N-2)%mod);
			// int b = (int)(a % mod);
			// a = K * ans * b;
			// return (int)(a % mod);
			// */ 

			// int result = (int) (X % mod);
			// long K = 3;
			// while( N > K){
			// 	int a = (int)( K % mod);
			// 	int b = (int) ((K - 2) % mod);
			// 	int c = (int) ((K - 1) % mod);
			// 	long d = (b * c);
			// 	b = (int)(d % mod);
			// 	d = (a * result * b);
			// 	result = (int)(d % mod);
			// 	K += 3;
			// }

			// if( K-3  != N){

			// 	K  = K - 3 + 1;
			// 	for(; K <= N ; K++){

			// 		long a = (int) (K %mod) *(result);
			// 		result = (int) (a % mod);
			// 	}
			// }
			// return result;
		}

		public static void main(String []args)throws IOException{

			try{

				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				int tc = Integer.parseInt(br.readLine());
				StringBuilder sb = new StringBuilder();
				while(tc-- > 0){
					String s[] = br.readLine().split(" ");
					long N = Long.parseLong(s[0]);
					long X = Long.parseLong(s[1]);
					sb.append(getAnswer(N, X)+"\n");
				}
				System.out.print(sb.toString());

			}catch(Exception e){
				return ;
			}
		}
}