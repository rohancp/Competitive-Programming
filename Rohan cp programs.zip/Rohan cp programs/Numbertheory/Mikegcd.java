import java.util.*;
import java.io.*;
import java.lang.*;
class Mikegcd{


	private static int size = (int)(2e5+1);
	private static int arr[];
	private static ArrayList<Integer> [] alist;

	private static void mark(int n){
		int i = 1, ele;

		while( ((ele = n*i)) < size){
			arr[ele] = 1;
			alist[ele].add(n);
			i++;
		}
	}

	private static void build(){

		arr = new int[size];
		alist = new ArrayList[size];
		for(int i = 1; i < size; i++)
			alist[i] = new ArrayList<Integer>();
		for(int i = 2; i < size; i++){

			if(arr[i] == 0){

				mark(i);
			}
		}
	}

	public static void main(String [] args)throws IOException{


		try{
			build();
			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int N = Integer.parseInt(br.readLine());
			String s[] = br.readLine().split(" ");
			int a[] = new int[N+1];
			for(int i =1; i <= N; i++){
				a[i] = Integer.parseInt(s[i-1]);
			}

			int result[] = new int[N+1];
			int pos[] = new int[size];
			Arrays.fill(pos, -1);
			Arrays.fill(result, -1);
			for(int i =1; i <= N; i++){

				int max = -1;
				for(int x : alist[a[i]]){

					if(pos[x] > max)
						max = pos[x];
				}
				if(max != -1){

					result[i] = max;
				}
				for(int x : alist[a[i]]){
					pos[x] = i;
				}
			}
			// for(int mm : result){
			// 	System.out.print(mm+" ");
			// }
			// System.out.println();
			Arrays.fill(pos, Integer.MAX_VALUE);
			for(int i = N; i >= 1; i--){

				int min = Integer.MAX_VALUE;

				for(int x : alist[a[i]]){

					if(pos[x] < min){
						min = pos[x];
					}
				}

				if(min < Integer.MAX_VALUE){
					// System.out.println(min);
					if(result[i] == -1)
						result[i] = min;

					else if(Math.abs(min - i) < Math.abs(i - result[i]))
						result[i] = min;
				}
				for(int x : alist[a[i]]){
					pos[x] = i;
				}
				// for(int ii =1 ; ii <= N; ii++)
				// 	System.out.print(result[ii]+" ");
				// System.out.println();
			}
			for(int i = 1; i <= N; i++){
				sb.append(result[i]).append(" ");
			}
			System.out.println(sb.toString());
			

		}catch(Exception e){
			return ;
		}
	}
}