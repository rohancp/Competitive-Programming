import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Ashuprime{

	private static int size = (int)Math.pow(10, 6);
	private static int isprime[];
	private static int count[];
	private static void sieve(){
		isprime = new int[size+1];
		count = new int[size+1];
		for(int i = 2; i*i <= size; i++){
			
			if(isprime[i] == 0){
				
				for(int j = i*i ; j <= size; j += i){
					if(isprime[j] == 0){
						isprime[j] = i;
						count[i]++;
					}
				}
				
			}
		}
	}

	public static void main(String [] args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			sieve();
			while(tc-- > 0){

				int p = Integer.parseInt(br.readLine());
				sb.append(count[p]+1+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception exp){
			return ;
		}

	}
}