import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.Scanner;
class Vivatime{

	private static long _gcd(long a, long b){

		if(b==0)return a;
		return _gcd(b, a%b);
	}

	public static void main(String[] args)throws IOException{

		try{
			StringBuilder sb = new StringBuilder();
			Scanner input = new Scanner(System.in);
			// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = input.nextInt();
			while(tc-- > 0){
				int n = input.nextInt();
				// String s[] = br.readLine().split(" ");
				long gcd = input.nextLong();
				for(int i = 1; i < n; i++){
					long a = input.nextLong();
					gcd = _gcd(a, gcd);
				}
				int Q = input.nextInt();
				while(Q-- > 0){
					// s = br.readLine().split(" ");
					long l = input.nextLong();
					long r = input.nextLong();
					sb.append((long)(r/gcd) - (l-1)/gcd+"\n");
				}
			}
			System.out.println(sb.toString());
		}catch(Exception E){
			return ;
		}
	}
}