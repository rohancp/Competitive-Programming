import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.*;
import java.lang.*;
class AtoB{

	private static int MOD = 7 + (int)Math.pow(10, 9);

	private static long modularexp(long x, long n){

		if( n== 0)return 1L;

		if(n %2 == 0){
			return modularexp((x*x)%MOD, n/2);
		}
		return ((x%MOD) * modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}

	public static void main(String [] args)throws IOException{

		// try{

			// BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		boolean check[] = new boolean[1000001];
		Arrays.fill(check, false);
            Scanner input = new Scanner(System.in);
			int n = input.nextInt();
			// String s[] = br.readLine().split(" ");
			// int Q = Integer.parseInt(br.readLine());
			long arr[] = new long [n+1];
			long total_multp = 1;
			int countzero = 0;
			for(int i = 1; i <= n; i++){

				long a = input.nextLong();
				if(a == 0){
					check[i] = true;
					countzero++;
					arr[i] = 0;
					continue;
				}
				arr[i] = a;
				total_multp = (total_multp * a)%MOD;
			}
			StringBuilder sb = new StringBuilder();
            int Q = input.nextInt();
			while(Q-- > 0){

				// s = br.readLine().split(" ");
				int type = input.nextInt();
				if(type == 0){

					int id = input.nextInt();
					int value = input.nextInt();
					if(check[id]){
						if(value != 0){

							check[id] = false;
							countzero--;
							arr[id] = value;
							total_multp = (total_multp * value)%MOD;
						}
					}else{
						total_multp = ((total_multp%MOD) * (modularexp(arr[id], MOD-2))%MOD)%MOD;
						if(value == 0){
							check[id] = true;
							countzero++;
							arr[id] = 0;
							continue;
						}
						total_multp = (total_multp * value)%MOD;
						arr[id] = value;
					}
					// long sm = ((total_multp%MOD) * (modularexp(arr[index],MOD-2)%MOD))%MOD;
					// arr[index] = value;
					// total_multp = (sm * value)%MOD;
				}
				else{
					int id = input.nextInt();
					if((countzero == 1) && (check[id] == true))
						sb.append(total_multp+"\n");
					else if(countzero !=0 )
						sb.append(0+"\n");
					else{
					long ans = ((total_multp%MOD) * (modularexp(arr[id], MOD-2)%MOD))%MOD;
					sb.append(ans+"\n");}
				}
			}
            // System.out.println("Aaa");
			System.out.println(sb.toString());

		// }catch(Exception e){
		// 	return ;
		// }

	}
}