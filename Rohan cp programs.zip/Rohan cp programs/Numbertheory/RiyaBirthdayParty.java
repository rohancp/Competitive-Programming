import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Vector;
class RiyaBirthdayParty{

	static int mod = 7 +(int)Math.pow(10, 9);

	private static Vector getSequence(){

		Vector<Long> vec = new Vector<Long>();
		vec.add(0L);
		vec.add(1L);
		vec.add(6L);
		for(int i = 2; i < mod; i++){
			long value = (2 * vec.get(i) - vec.get(i-1) + 4)%mod;
			vec.add(value);
		}
		return vec;
		
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			Vector<Long> getSeq = getSequence();
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				long num = Long.parseLong(br.readLine());
				if(num > mod){
					sb.append(0+"\n");
					continue;
				}
				sb.append(getSeq.get((int)num)+"\n");
			}
			System.out.println(sb.toString());
		}catch(Exception e){
			return ;
		}
	}
}