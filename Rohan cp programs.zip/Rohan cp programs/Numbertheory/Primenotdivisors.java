import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Primenotdivisors{

	private static long getFactors(long n){

		long count = 0;
		long pf = 0;
		long result = 1;
		while((n&1) == 0){
			count++;
			n >>= 1;
		}
		if(count > 0){
			result = result * (count+1);
			pf +=1;
		}
		for(long i = 3; i <= (long)Math.sqrt(n); i += 2){
			count = 0;
			while( n%i == 0){
				count++;
				n = n/i;
			}
			if(count > 0){
				result = result * (count+1);
				pf +=1;
			}
		}
		if( n > 2){
			result = result * (2L);
			pf +=1;
		}
		return result - pf;
	}
	public static void main(String []args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(tc-- > 0){
				long N = Long.parseLong(br.readLine());
				sb.append(getFactors(N)+"\n");
			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}
	}
}