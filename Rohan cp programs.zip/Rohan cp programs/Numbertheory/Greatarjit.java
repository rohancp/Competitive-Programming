import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Greatarjit{

	private static int MOD = 7 + (int)Math.pow(10, 9);
	// here c = 500000004 is 2 ^ MOD-2...
	private static int c = 500000004;

	private static long modularexp(long x, long n){

		if( n == 0)return 1L;

		if(n %2 == 0){
			return modularexp((x*x)%MOD, n/2);
		}
		return (x*modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}

	public static void main(String [] args)throws IOException{

		try{
			StringBuilder sb = new StringBuilder();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int tc = Integer.parseInt(br.readLine());
			while(tc-- > 0){
				int N = Integer.parseInt(br.readLine());
				long arr[] = new long [N];
				String s[] = br.readLine().split(" ");
				for(int i = 0; i < N; i++)
					arr[i] = Long.parseLong(s[i]);
				long result = 0;
				for(int i = 1; i < N; i++){
					arr[i-1] = ((arr[i]%MOD) * (modularexp(arr[i-1], MOD-2)%MOD))%MOD;
					
				}
				for(int i = 0 ; i < N-1; i++){
					long a = (((arr[i]%MOD)* ((arr[i]+1)%MOD))%MOD * c)%MOD;
					result = ((result%MOD) + (a%MOD))%MOD;
				}
				result = (((result%MOD)*((result+1)%MOD))%MOD * c)%MOD;
				sb.append(result+"\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){
			return ;
		}

	}
}