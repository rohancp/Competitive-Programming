import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Calculatethepower{

	static int MOD = 7 + (int)Math.pow(10, 9);
	private static long modularexp(long x, long n){

		if(n == 0)return 1L;
		if(n%2 == 0)
		return modularexp((x * x)%MOD, n/2);
		return (x * modularexp((x*x)%MOD, (n-1)/2))%MOD;
	}

	public static void main(String [] args)throws IOException{

		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String inp[] = br.readLine().split(" ");
			System.out.println(modularexp(Long.parseLong(inp[0]), Long.parseLong(inp[1])));

		}catch(Exception e){
			return ;
		}
	}
}