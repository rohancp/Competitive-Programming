import java.util.*;
import java.io.*;
import java.lang.*;
class Annoying{

	private static int getdivisors(int N){

		int count = 0;
		for(int i = 1; i <= (int)Math.sqrt(N); i++){

			if(N%i == 0){

				if(i*i == N){
					count++;break;
				}
				count++;
				count++;
			}
		}
		return count;
	}
	public static void main(String [] args)throws IOException{


		try{

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int number_of_app = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			while(number_of_app-- > 0){

				String name = br.readLine();
				name = name.toUpperCase();
				int sum = 0;
				for(int i = 0; i < name.length(); i++){
					sum += name.charAt(i) - 'A' + 1;
				}
				int number_of_divisors = getdivisors(sum);
				// System.out.println(number_of_divisors);
				if(number_of_divisors >= name.length())
					sb.append("IN\n");
				else
					sb.append("OUT\n");

			}
			System.out.println(sb.toString());

		}catch(Exception e){

			return ;
		}

	}
}