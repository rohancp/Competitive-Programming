import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
class Basic{

	private static int x,y;
	private static int binaryExp(int A, int B, int M){

		if(B == 0)	return 1;

		else if(B%2 == 0){
			long a = (A%M)*(A%M);
			A = (int)(a%M);
			return binaryExp(A, B/2, M)%M;
		}

		long aa = (A%M) * (A%M);
		int g = (int)(aa%M);
		int ans = binaryExp(g, (B-1)/2, M);
		aa = (A%M) * (ans%M);
		g = (int)(aa%M);
		return g;
	}

	private static void extended_Euclid_Algo(int A, int B){

		if(B == 0){

			x = 1;
			y = 0;
			return ;
		}
		extended_Euclid_Algo(B,A%B);
		int temp = x;
		x = y;
		y = temp - (y *(A/B));
	}
	private static int Inverse(int C, int M){

		extended_Euclid_Algo(C, M);
		return (x%M+M)%M;
	}

	private static int getAns(int A, int B, int C, int M){

		int ans1 = binaryExp(A, B, 1000000000+7);
		// System.out.println(ans1);
		// System.exit(0);
		int ans2 = Inverse(C, M);
		// System.out.println(ans2);
		// System.exit(0);
		long a = ans1 * ans2;
		int result = (int)(a%M);
		return result;
	}
	public static void main(String [] args)throws IOException{

		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String inp[] = br.readLine().split(" ");
			int ans = getAns(Integer.parseInt(inp[0]), Integer.parseInt(inp[1]), Integer.parseInt(inp[2]), Integer.parseInt(inp[3]));
			System.out.println(ans);
		}
		catch(Exception e){
			return ;
		}
	}
}